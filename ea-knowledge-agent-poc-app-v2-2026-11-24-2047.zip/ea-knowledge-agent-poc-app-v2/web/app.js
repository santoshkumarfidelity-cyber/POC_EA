/* EA POC UI — modular single file: api client, state, per-page
   renderers, event bindings. All API strings are escaped before HTML. */
"use strict";

const esc = (s) => String(s ?? "").replace(/[&<>"']/g,
  c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;",
          "'": "&#39;" }[c]));

/* Local files (file://) can't be opened from an http page, so they go
   through the server, which re-checks permission; other links are kept.
   A click asks the server to open the file in its desktop app (Word,
   Acrobat…); the href (browser view/download) is the fallback. */
function sourceLink(id, url) {
  if (!String(url || "").startsWith("file:")) {
    return `<a href="${esc(url)}" target="_blank" rel="noopener">${esc(url)}</a>`;
  }
  let name = url;
  try { name = decodeURIComponent(url); } catch (e) { /* keep raw */ }
  name = name.split(/[\\/]/).pop();
  const href = `/api/artifacts/${encodeURIComponent(id)}/file?persona=` +
    encodeURIComponent(state.persona);
  return `<a href="${esc(href)}" target="_blank" rel="noopener"
    class="open-file" data-id="${esc(id)}">Open ${esc(name)}</a>`;
}

document.addEventListener("click", async e => {
  const link = e.target.closest("a.open-file");
  if (!link) return;
  e.preventDefault();
  try {
    await api.post(`/api/artifacts/${encodeURIComponent(link.dataset.id)}/open`,
      { persona: state.persona });
  } catch (err) {
    window.open(link.href, "_blank", "noopener");
  }
});

const api = {
  async decode(r) {
    const text = await r.text();
    let data;
    try {
      data = text ? JSON.parse(text) : {};
    } catch {
      const unavailable = r.status === 502 || r.status === 503;
      throw new Error(unavailable
        ? "The POC server is unavailable. Refresh after it restarts."
        : `The server returned an unexpected ${r.status} response.`);
    }
    if (r.status === 401 && data.error?.code === "signed_out") {
      window.location.href = "/auth/login";      // Entra sign-in
      throw new Error("Signing you in…");
    }
    if (!r.ok) throw new Error(data.error?.message || r.statusText);
    return data;
  },
  // v2 POC: the User/Admin switch rides along on every request.
  headers(extra = {}) {
    return state.adminView ? { ...extra, "X-POC-View": "admin" } : extra;
  },
  async get(path) {
    const r = await fetch(path, { headers: this.headers() });
    return this.decode(r);
  },
  async post(path, body) {
    const r = await fetch(path, {
      method: "POST",
      headers: this.headers({ "Content-Type": "application/json" }),
      body: JSON.stringify(body) });
    return this.decode(r);
  },
};

const state = {
  persona: localStorage.getItem("persona") || "consumer",
  adminView: localStorage.getItem("view") === "admin",
  discoverForEveryone: false,
  conversationId: null,
  selectedTags: new Set(),
};

const PROVIDERS = {
  vertex: "Vertex AI (LLM, grounded on retrieved documents)",
  claude: "Claude (LLM, grounded on retrieved documents)",
  local: "built-in extractive summary (no LLM configured)",
  "local-fallback": "built-in summary (LLM call failed)",
};

const EXAMPLES = [
  "Show the latest Insurance technology strategy",
  "Find the current ARB submission template",
  "What is the approved API strategy?",
  "What is our policy on quantum computing hardware?",
];

const TRANSITIONS = {
  DRAFT: { target: "REVIEW", label: "Submit for review",
           personas: ["contributor", "owner", "admin"] },
  REVIEW: { target: "APPROVED", label: "Approve",
            personas: ["approver", "admin"] },
  APPROVED: { target: "SUPERSEDED", label: "Supersede",
              personas: ["owner", "approver", "admin"] },
  SUPERSEDED: { target: "ARCHIVED", label: "Archive",
                personas: ["curator", "admin"] },
};

function bytesToBase64(bytes) {
  let binary = "";
  const size = 0x8000;
  for (let i = 0; i < bytes.length; i += size) {
    binary += String.fromCharCode(...bytes.subarray(i, i + size));
  }
  return btoa(binary);
}

/* ----------------------------------------------------------- chrome */
async function initChrome() {
  const sel = document.getElementById("persona");
  const me = await api.get("/api/me");      // 401 -> Microsoft sign-in
  state.entra = me.auth_mode === "entra";
  const integ = await api.get("/api/integrations");
  const phase = integ.phase || 1;
  state.phase1 = phase < 2;
  if (phase < 2) {
    // Phase 1: single internal viewer; hide governance/audit/quality UI.
    document.querySelectorAll("[data-min-phase]").forEach(el => {
      if (Number(el.dataset.minPhase) > phase) el.remove();
    });
    document.querySelectorAll(".page").forEach(el => {
      if (["contribute", "govern", "reports"].some(
          n => el.id === "page-" + n)) el.remove();
    });
    state.persona = "consumer";
    localStorage.setItem("persona", "consumer");
  }
  const { personas } = await api.get("/api/personas");
  sel.innerHTML = personas.map(p =>
    `<option value="${esc(p.id)}">${esc(p.display_name)}</option>`).join("");
  sel.value = state.persona;
  sel.addEventListener("change", () => {
    state.persona = sel.value;
    localStorage.setItem("persona", sel.value);
    state.conversationId = null;
    renderPage(currentPage());
    if (!document.getElementById("discover-panel").hidden) renderDiscover();
  });
  if (phase < 2) {
    sel.hidden = true;
    document.querySelector(".persona-label").textContent = "Internal Viewer";
    document.getElementById("view-toggle").hidden = state.entra;
  }
  if (state.entra) {
    // Entra sign-in: the server knows who you are and whether you are an
    // admin (EA_ADMINS); no persona or User/Admin switch.
    state.adminView = me.admin;
    sel.hidden = true;
    document.querySelector(".persona-label").hidden = true;
    const name = document.getElementById("user-name");
    name.textContent = me.name + (me.admin ? " · Admin" : "");
    name.hidden = false;
    document.getElementById("sign-out").hidden = false;
  }
  await loadAppSettings();
  const cl = document.getElementById("int-claude");
  const llm = integ.vertex_configured
    ? "Vertex AI · " + integ.llm_model
    : integ.claude_configured ? "Claude configured" : "Local synthesis";
  cl.textContent = llm;
  cl.classList.toggle("on", integ.vertex_configured
                            || integ.claude_configured);
  const sp = document.getElementById("int-sp");
  sp.textContent = integ.sharepoint_configured ? "Graph configured"
                                               : "SharePoint mock";
  sp.classList.toggle("on", integ.sharepoint_configured);
  drawMotif();
}

/* ------------------------------------------------- v2 POC admin view */
/* Phase 1 only: a User/Admin switch (a demo switch, not sign-in). Discover
   is admin-only unless an admin turns on "Discover visible to users" in
   the Ask sidebar. The server checks the same rule. */
async function loadAppSettings() {
  const s = await api.get("/api/app-settings");
  state.discoverForEveryone = s.discover_for_everyone;
  applyView();
}

function applyView() {
  const admin = state.phase1 && state.adminView;
  document.querySelectorAll("#view-toggle button").forEach(b =>
    b.setAttribute("aria-pressed",
      String((b.dataset.mode === "admin") === state.adminView)));
  document.getElementById("admin-panel").hidden = !admin;
  document.getElementById("opt-discover").checked = state.discoverForEveryone;
  const discover = !state.phase1 || admin || state.discoverForEveryone;
  document.querySelectorAll('.tab[data-page="discover"], ' +
    '[data-goto="discover"]').forEach(el => el.hidden = !discover);
  if (!discover) closeDiscover();
}

async function setView(mode) {
  state.adminView = mode === "admin";
  localStorage.setItem("view", mode);
  await loadAppSettings();
}

async function setDiscoverForEveryone(on) {
  try {
    const s = await api.post("/api/app-settings",
      { discover_for_everyone: on });
    state.discoverForEveryone = s.discover_for_everyone;
  } catch (err) {
    alert("Could not save the setting: " + err.message);
  }
  applyView();
}

function drawMotif() {
  const svg = document.getElementById("motif");
  const dots = [], lines = [];
  let seed = 7;
  const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  for (let i = 0; i < 14; i++)
    dots.push([20 + rnd() * 300, 15 + rnd() * 190]);
  for (let i = 0; i < dots.length - 4; i += 2)
    lines.push(`<line x1="${dots[i][0]}" y1="${dots[i][1]}"
      x2="${dots[i + 3][0]}" y2="${dots[i + 3][1]}"
      stroke="#6F8191" stroke-width="0.6"/>`);
  for (const [x, y] of dots)
    lines.push(`<circle cx="${x}" cy="${y}" r="${2 + rnd() * 2}"
      fill="none" stroke="#31C6D4" stroke-width="1"/>`);
  svg.innerHTML = lines.join("");
}

function currentPage() {
  return document.querySelector(".tab.active").dataset.page;
}

function renderPage(name) {
  ({ ask: renderAsk,
     contribute: () => {}, govern: renderGovern,
     reports: renderReports })[name]?.();
}

/* ----------------------------------------------------------- Ask */
/* v2: a chat. The sidebar lists this persona's chats; a chat keeps its
   history, so follow-up questions are answered in context. */
async function renderAsk() {
  await loadChats();
  if (state.conversationId) await openChat(state.conversationId);
  else showEmptyChat();
}

function showEmptyChat() {
  const thread = document.getElementById("thread");
  thread.innerHTML = `
    <div class="chat-empty">
      <h1>Ask the governed corpus</h1>
      <p class="lede">Start with a question, then ask follow-ups about the
        answer. Each answer cites the single best approved source.</p>
      <div id="chips">${EXAMPLES.map(e =>
        `<button class="chip" type="button">${esc(e)}</button>`).join("")}</div>
    </div>`;
  thread.querySelectorAll(".chip").forEach(c =>
    c.addEventListener("click", () => {
      document.getElementById("q").value = c.textContent;
      ask();
    }));
}

async function loadChats() {
  const { chats } = await api.get(
    `/api/chats?persona=${encodeURIComponent(state.persona)}`);
  const list = document.getElementById("chat-list");
  list.innerHTML = chats.map(c => `
    <div class="chat-row${c.id === state.conversationId ? " active" : ""}"
      data-id="${esc(c.id)}">
      <button type="button" class="chat-item" title="${esc(c.title)}">${
        esc(c.title)}</button>
      <button type="button" class="chat-act" data-act="rename"
        title="Rename" aria-label="Rename chat">✎</button>
      <button type="button" class="chat-act" data-act="delete"
        title="Delete" aria-label="Delete chat">×</button>
    </div>`).join("") ||
    `<p class="side-empty">No chats yet.</p>`;
}

/* One click handler for the whole list: open, rename or delete. */
function onChatListClick(e) {
  const row = e.target.closest(".chat-row");
  if (!row || e.target.closest("input")) return;
  const act = e.target.closest(".chat-act")?.dataset.act;
  if (act === "rename") renameChat(row);
  else if (act === "delete") deleteChat(row.dataset.id);
  else openChat(row.dataset.id);
}

/* Rename in place: Enter (or clicking away) saves, Escape cancels. */
function renameChat(row) {
  const old = row.querySelector(".chat-item").textContent.trim();
  const input = document.createElement("input");
  input.className = "chat-rename";
  input.value = old;
  input.maxLength = 80;
  input.setAttribute("aria-label", "Chat title");
  row.replaceChildren(input);
  input.focus();
  input.select();
  let finished = false;
  const finish = async save => {
    if (finished) return;
    finished = true;
    const title = input.value.trim();
    if (save && title && title !== old) {
      try {
        await api.post(`/api/chats/${encodeURIComponent(row.dataset.id)}` +
          "/rename", { persona: state.persona, title });
      } catch (err) { alert("Could not rename the chat: " + err.message); }
    }
    loadChats();
  };
  input.addEventListener("keydown", e => {
    if (e.key === "Enter") { e.preventDefault(); finish(true); }
    if (e.key === "Escape") finish(false);
  });
  input.addEventListener("blur", () => finish(true));
}

async function deleteChat(id) {
  if (!confirm("Delete this chat and all its messages? " +
               "This cannot be undone.")) return;
  try {
    await api.post(`/api/chats/${encodeURIComponent(id)}/delete`,
      { persona: state.persona });
  } catch (err) {
    alert("Could not delete the chat: " + err.message);
    return;
  }
  if (id === state.conversationId) newChat();
  loadChats();
}

async function openChat(id) {
  const thread = document.getElementById("thread");
  try {
    const { messages } = await api.get(`/api/chats/${encodeURIComponent(id)}` +
      `?persona=${encodeURIComponent(state.persona)}`);
    state.conversationId = id;
    thread.innerHTML = messages.map(m => m.role === "user"
      ? userHtml(m.content)
      : assistantHtml(m.content, m.status, m.provider, m.citation,
                      m.duration_ms, m.id, m.source_count)).join("");
    document.querySelectorAll(".chat-row").forEach(r =>
      r.classList.toggle("active", r.dataset.id === id));
    thread.scrollTop = thread.scrollHeight;
  } catch (e) {     // e.g. the chat belongs to another persona
    state.conversationId = null;
    showEmptyChat();
  }
}

function newChat() {
  state.conversationId = null;
  document.querySelectorAll(".chat-row").forEach(r =>
    r.classList.remove("active"));
  showEmptyChat();
  document.getElementById("q").focus();
}

function userHtml(text) {
  return `<div class="msg msg-user"><div class="bubble">${esc(text)}</div></div>`;
}

/* How long the answer took, from the question reaching the server to the
   answer being saved: "0.8 s", "3.2 s", "1 min 5 s". Answers saved before
   durations were recorded show nothing. */
function tookLabel(ms) {
  if (ms == null || ms === "" || isNaN(ms)) return "";
  const s = ms / 1000;
  const text = s < 0.1 ? "under 0.1 s"
    : s < 60 ? `${s < 10 ? s.toFixed(1) : Math.round(s)} s`
    : `${Math.floor(s / 60)} min ${Math.round(s % 60)} s`;
  return `<span class="took" title="Time from your question to the answer">` +
    `Answered in ${esc(text)}</span> · `;
}

const ICON_COPY = `<svg viewBox="0 0 24 24" width="15" height="15"
  aria-hidden="true"><rect x="8" y="8" width="12" height="12" rx="2"
  fill="none" stroke="currentColor" stroke-width="2"/><path d="M16 8V6a2
  2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2" fill="none"
  stroke="currentColor" stroke-width="2"/></svg>`;
const ICON_DOWNLOAD = `<svg viewBox="0 0 24 24" width="15" height="15"
  aria-hidden="true"><path d="M12 4v11m0 0-4-4m4 4 4-4M5 19h14"
  fill="none" stroke="currentColor" stroke-width="2"
  stroke-linecap="round" stroke-linejoin="round"/></svg>`;

/* v2: Copy and "Download sources" under each answer. */
function answerActions(citation, messageId, sourceCount) {
  const src = citation ? `Source: ${citation.title} v${citation.version}` +
    (citation.source_url ? ` (${citation.source_url})` : "") : "";
  const zip = messageId && sourceCount ? `
    <button type="button" class="act act-zip" data-message="${esc(
      messageId)}" title="Download the cited document and the other top
      matches (that you may see) in one ZIP">${ICON_DOWNLOAD}
      <span>Download sources (${esc(sourceCount)})</span></button>` : "";
  return `<div class="msg-actions">
    <button type="button" class="act act-copy" data-source="${esc(src)}"
      title="Copy the answer">${ICON_COPY}<span>Copy</span></button>${zip}
  </div>`;
}

async function copyAnswer(btn) {
  const msg = btn.closest(".msg-bot");
  const text = msg.querySelector(".a").innerText.trim() +
    (btn.dataset.source ? "\n\n" + btn.dataset.source : "");
  try {
    await navigator.clipboard.writeText(text);
  } catch {         // older browsers / blocked clipboard API
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    document.execCommand("copy");
    ta.remove();
  }
  const label = btn.querySelector("span");
  label.textContent = "Copied";
  setTimeout(() => { label.textContent = "Copy"; }, 1500);
}

async function downloadSources(btn) {
  const label = btn.querySelector("span"), was = label.textContent;
  label.textContent = "Preparing ZIP…";
  btn.disabled = true;
  try {
    const r = await fetch(`/api/chats/${encodeURIComponent(
      state.conversationId)}/messages/${encodeURIComponent(
      btn.dataset.message)}/sources.zip?persona=${encodeURIComponent(
      state.persona)}`, { headers: api.headers() });
    if (!r.ok) await api.decode(r);          // throws the server's message
    const blob = await r.blob();
    const name = /filename="([^"]+)"/.exec(
      r.headers.get("Content-Disposition") || "")?.[1] || "sources.zip";
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = name;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 10000);
  } catch (e) {
    alert("Could not download the sources: " + e.message);
  } finally {
    label.textContent = was;
    btn.disabled = false;
  }
}

function assistantHtml(text, status, provider, citation, ms, messageId,
                       sourceCount) {
  const { html } = renderAnswer(text, citation ? [citation] : []);
  const source = citation ? `
    <div class="cite">
      <div class="src-label">Source</div>
      <div class="t"><a href="#" class="cite-link" data-view="${esc(
        citation.artifact_id)}">${esc(citation.title)}</a> · v${esc(
        citation.version)}</div>
      <div class="e">${esc(citation.excerpt)}</div>
      ${sourceLink(citation.artifact_id, citation.source_url)}
    </div>` : "";
  const pill = status && status !== "grounded"
    ? `<span class="status-pill status-insufficient_evidence">NO GROUNDED ANSWER</span>`
    : "";
  return `<div class="msg msg-bot">${pill}<div class="a">${html}</div>
    ${source}${answerActions(citation, messageId, sourceCount)}
    <div class="meta">${tookLabel(ms)}${esc(
      PROVIDERS[provider] || provider || "")}</div></div>`;
}

async function ask() {
  const input = document.getElementById("q");
  const q = input.value.trim();
  if (!q) return;
  const thread = document.getElementById("thread");
  const btn = document.getElementById("ask-btn");
  if (thread.querySelector(".chat-empty")) thread.innerHTML = "";
  thread.insertAdjacentHTML("beforeend", userHtml(q) +
    `<div class="msg msg-bot pending"><em>Searching approved content…</em></div>`);
  const node = thread.lastElementChild;
  thread.scrollTop = thread.scrollHeight;
  input.value = "";
  input.style.height = "";
  btn.disabled = true;
  try {
    // v2: the answer appears as the LLM writes it. The final "done"
    // event is the checked answer with its source; it replaces the draft.
    const r = await fetch("/api/agent/query/stream", {
      method: "POST",
      headers: api.headers({ "Content-Type": "application/json" }),
      body: JSON.stringify({ persona: state.persona, question: q,
                             conversation_id: state.conversationId }) });
    if (!r.ok || !r.body) await api.decode(r);   // throws the server's error
    const reader = r.body.getReader(), dec = new TextDecoder();
    let buf = "", draft = "", a = null;
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let nl;
      while ((nl = buf.indexOf("\n")) >= 0) {
        const ev = JSON.parse(buf.slice(0, nl));
        buf = buf.slice(nl + 1);
        if (ev.type === "delta") draft += ev.text;
        else if (ev.type === "reset") draft = "";
        else if (ev.type === "done") a = ev;
        else if (ev.type === "error") throw new Error(ev.message);
        if (ev.type === "delta" || ev.type === "reset") showDraft(node, draft);
      }
    }
    if (!a) throw new Error("The answer was cut off. Please try again.");
    if (node.isConnected) {     // still on this chat (not switched away)
      state.conversationId = a.conversation_id;
      node.outerHTML = assistantHtml(a.answer, a.status, a.provider,
                                     a.citations[0], a.duration_ms,
                                     a.message_id, a.source_count);
    }
    await loadChats();
  } catch (e) {
    node.classList.remove("pending");
    node.textContent = "Error: " + e.message;
  } finally {
    btn.disabled = false;
    thread.scrollTop = thread.scrollHeight;
    input.focus();
  }
}

/* The answer so far, while it streams in; the thread stays scrolled to
   the bottom unless the reader has scrolled up. */
function showDraft(node, draft) {
  const thread = document.getElementById("thread");
  const atEnd = thread.scrollHeight - thread.scrollTop
    - thread.clientHeight < 40;
  node.classList.remove("pending");
  node.classList.add("streaming");
  node.innerHTML = draft
    ? `<div class="a">${renderAnswer(draft, []).html}</div>`
    : "<em>Writing the answer…</em>";
  if (atEnd) thread.scrollTop = thread.scrollHeight;
}

/* Answer text -> safe HTML. Everything is escaped first; then **bold**,
   bullet lines and paragraphs are formatted, and citation markers
   ([1], [1, 2], [1][2]) become links named after the cited document.
   Returns the html and the indexes of the citations it used. */
function renderAnswer(text, cites) {
  const used = new Set();
  const link = n => {
    const c = cites[n - 1];
    if (!c) return "";
    used.add(n - 1);
    return `<a href="#" class="cite-link" data-view="${esc(c.artifact_id)}"
      title="${esc(c.title)} v${esc(c.version)}">${esc(c.title)}</a>`;
  };
  const inline = s => esc(s)
    .replace(/(\d)\]\s*\[(?=\d)/g, "$1, ")
    .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
    .replace(/\s*\[(\d+(?:\s*,\s*\d+)*)\]/g, (m, nums) => {
      const links = nums.split(",").map(n => link(+n)).filter(Boolean);
      return links.length ? ` <span class="cites">(${links.join(", ")})</span>` : m;
    });
  let html = "", para = [], items = [];
  const flush = () => {
    if (para.length) html += `<p>${para.map(inline).join(" ")}</p>`;
    if (items.length) html += `<ul>${items.map(i =>
      `<li>${inline(i)}</li>`).join("")}</ul>`;
    para = []; items = [];
  };
  for (const raw of String(text || "").split("\n")) {
    const line = raw.trim();
    const bullet = line.match(/^(?:[-*•]|\d+[.)])\s+(.*)/);
    if (!line) flush();
    else if (bullet) { if (para.length) flush(); items.push(bullet[1]); }
    else { if (items.length) flush(); para.push(line); }
  }
  flush();
  return { html, used };
}

document.addEventListener("click", e => {
  const l = e.target.closest("a.cite-link");
  if (!l) return;
  e.preventDefault();
  openArtifact(l.dataset.view);
});

/* ------------------------------------------------------- Discover */
/* v2: Discover opens as a panel over the right of the chat, so the chat
   (and the page behind it) stays as it was; × or Esc closes it. */
function openDiscover() {
  const panel = document.getElementById("discover-panel");
  if (!panel) {   // an old cached index.html with a new app.js
    alert("The page is out of date. Press Ctrl+F5 to reload it.");
    return;
  }
  panel.hidden = false;
  document.getElementById("discover-tab").hidden = true;
  document.body.classList.add("discover-open");
  setDiscoverExpanded(discoverExpanded());
  renderDiscover().catch(e => {
    document.getElementById("results").innerHTML =
      `<p class="msg err">${esc(e.message)}</p>`;
  });
  document.getElementById("dq").focus();
}

function closeDiscover() {
  document.getElementById("discover-panel").hidden = true;
  document.getElementById("discover-tab").hidden = true;
  document.body.classList.remove("discover-open");
}

/* Collapse: the panel steps aside to a small tab on the right edge and
   comes back as it was (search, filters, scroll), without reloading. */
function collapseDiscover() {
  document.getElementById("discover-panel").hidden = true;
  document.body.classList.remove("discover-open");
  document.getElementById("discover-tab").hidden = false;
}

function reopenDiscover() {
  document.getElementById("discover-tab").hidden = true;
  document.getElementById("discover-panel").hidden = false;
  document.body.classList.add("discover-open");
}

/* Discover opens full page by default; Restore makes it a side panel
   next to the chat, Expand brings full page back. Remembered in this
   browser (a new key, so older "side panel" choices don't apply). */
function discoverExpanded() {
  try { return localStorage.getItem("discoverLayout") !== "side"; }
  catch { return true; }
}

function setDiscoverExpanded(on) {
  document.body.classList.toggle("discover-expanded", on);
  const b = document.getElementById("discover-expand");
  b.textContent = on ? "Restore" : "Expand";
  b.title = on ? "Back to a side panel" : "Fill the window";
  b.setAttribute("aria-pressed", String(on));
  try { localStorage.setItem("discoverLayout", on ? "full" : "side"); }
  catch { /* private window: not remembered */ }
}

async function renderDiscover() {
  const { tags } = await api.get(
    `/api/tags?persona=${state.persona}`);
  const tagrow = document.getElementById("tagrow");
  tagrow.innerHTML = tags.map(t =>
    `<button class="tag${state.selectedTags.has(t.tag) ? " sel" : ""}"
      data-tag="${esc(t.tag)}">${esc(t.tag)} · ${t.count}</button>`)
    .join("");
  tagrow.querySelectorAll(".tag").forEach(b =>
    b.addEventListener("click", () => {
      const t = b.dataset.tag;
      state.selectedTags.has(t) ? state.selectedTags.delete(t)
                                : state.selectedTags.add(t);
      loadArtifacts();
    }));
  await loadArtifacts();
}

async function loadArtifacts() {
  const p = new URLSearchParams({
    persona: state.persona,
    query: document.getElementById("dq").value,
    status: document.getElementById("dstatus")?.value || "",
    audience: document.getElementById("daudience")?.value || "",
    sort: document.getElementById("dsort").value,
    tags: [...state.selectedTags].join(","),
  });
  const { artifacts } = await api.get(`/api/artifacts?${p}`);
  document.getElementById("results").innerHTML = artifacts.map(a => `
    <div class="acard" data-id="${esc(a.id)}">
      <h3>${esc(a.title)}</h3>
      <div class="sub">
        <span class="pill pill-${esc(a.lifecycle_status)}">${esc(
          a.lifecycle_status)}</span>
        ${a.is_current_approved ? '<span class="pill pill-cur">CURRENT APPROVED</span>' : ""}
        v${esc(a.version)} · ${esc(a.audience)}${a.version_count > 1
          ? ` · ${a.version_count} versions` : ""}
      </div>
      <div class="sub">Owner: ${esc(a.owner || "—")} · uploaded
        ${esc((a.uploaded_at || "").slice(0, 10))}</div>
      <div class="taglist">${a.tags.map(esc).join(" · ")}</div>
    </div>`).join("") ||
    "<p class='lede'>No artifacts visible for this persona/filter.</p>";
  document.querySelectorAll(".acard").forEach(c =>
    c.addEventListener("click", () => openArtifact(c.dataset.id)));
}

async function openArtifact(id) {
  try {
    await renderArtifact(id);
  } catch (e) {   // show the reason instead of failing silently
    document.getElementById("drawer-body").innerHTML = `
      <h2>Could not open this document</h2>
      <p class="msg err">${esc(e.message)}</p>
      <p class="sub">Restart the app and press Ctrl+F5 to reload the page.
        If this stays, send this message to the POC team.</p>`;
    document.getElementById("drawer").hidden = false;
  }
}

async function renderArtifact(id) {
  const { artifact: a } = await api.get(
    `/api/artifacts/${id}?persona=${state.persona}`);
  const { versions } = await api.get(
    `/api/artifacts/${id}/versions?persona=${state.persona}`);
  const hist = (a.lifecycle_events || []).map(e =>
    `<div class="vrow">${esc(e.at.slice(0, 10))} ·
      ${esc(e.from_status || "—")} → <strong>${esc(e.to_status)}</strong>
      by ${esc(e.actor_persona)}${e.note ? " · " + esc(e.note) : ""}</div>`
  ).join("");
  const current = versions.find(v => v.is_current_approved);
  const vers = versions.map((v, i) =>
    `<div class="vrow${v.id === a.id ? " vsel" : ""}">
      <strong>v${esc(v.version)}</strong>
      <span class="pill pill-${esc(v.lifecycle_status)}">${esc(
        v.lifecycle_status)}</span>
      ${v.is_current_approved ? '<span class="pill pill-cur">CURRENT</span>' : ""}
      ${esc((v.uploaded_at || "").slice(0, 10))}
      <span class="vlinks">
        ${v.id === a.id ? "<em>viewing</em>" :
          `<a href="#" data-view="${esc(v.id)}">View</a>`}
        ${i < versions.length - 1
          ? `<a href="#" data-diff="${esc(v.id)}">What changed</a>` : ""}
      </span></div>`).join("");
  const older = !a.is_current_approved ? `
    <div class="vbanner">You are viewing an older version
      (${esc(a.lifecycle_status)}).${current ? ` Current is
      <a href="#" data-view="${esc(current.id)}">v${esc(current.version)}</a>.`
      : ""} Its saved text is shown; the original file now holds the
      newest version.</div>` : "";
  document.getElementById("drawer-body").innerHTML = `
    ${older}
    <h2>${esc(a.title)}</h2>
    <p class="sub">v${esc(a.version)} · ${esc(a.segment)} ·
      ${esc(a.domain)} · ${esc(a.content_type)} · ${esc(a.audience)}</p>
    <p>${esc(a.description)}</p>
    <p style="margin:12px 0">${esc((a.content_text || "").slice(0, 800))}</p>
    ${a.is_current_approved ? `<p>${sourceLink(a.id, a.source_url)}</p>` : ""}
    <h3 style="margin-top:18px">Versions (${versions.length})</h3>${vers}
    <div id="vchanges"></div>
    ${state.phase1 ? "" : `<h3 style="margin-top:18px">Lifecycle history</h3>${hist}`}`;
  const body = document.getElementById("drawer-body");
  body.querySelectorAll("[data-view]").forEach(l =>
    l.addEventListener("click", e => {
      e.preventDefault(); openArtifact(l.dataset.view); }));
  body.querySelectorAll("[data-diff]").forEach(l =>
    l.addEventListener("click", e => {
      e.preventDefault(); showChanges(l.dataset.diff); }));
  document.getElementById("drawer").hidden = false;
}

async function showChanges(id) {
  const box = document.getElementById("vchanges");
  let c;
  try {
    c = await api.get(
      `/api/artifacts/${id}/changes?persona=${state.persona}`);
  } catch (e) {
    box.innerHTML = `<p class="msg err">Could not load the changes:
      ${esc(e.message)}</p>`;
    return;
  }
  if (!c.from) {
    box.innerHTML = `<p class="sub">${esc(c.note)}</p>`;
    return;
  }
  const sign = { add: "+ ", del: "− ", same: "  ", gap: "" };
  const lines = c.lines.map(l =>
    `<div class="d-${l.op}">${sign[l.op]}${esc(l.text) || "&nbsp;"}</div>`
  ).join("");
  box.innerHTML = `
    <h3 style="margin-top:18px">What changed: v${esc(c.from.version)} →
      v${esc(c.to.version)}</h3>
    <p class="sub"><span class="d-add">+${c.added} lines added</span> ·
      <span class="d-del">−${c.removed} lines removed</span></p>
    ${c.note ? `<p class="sub">${esc(c.note)}</p>` : ""}
    <div class="diff">${lines}</div>
    ${c.truncated ? '<p class="sub">Showing the first part of the changes.</p>' : ""}`;
  box.scrollIntoView({ behavior: "smooth", block: "start" });
}

/* ------------------------------------------------------ Contribute */
function bindContribute() {
  document.getElementById("contrib").addEventListener("submit",
    async (ev) => {
      ev.preventDefault();
      const f = ev.target, msg = document.getElementById("contrib-msg");
      msg.className = "msg"; msg.textContent = "";
      const fd = new FormData(f);
      const payload = {
        persona: state.persona,
        title: fd.get("title"), owner: fd.get("owner"),
        version: fd.get("version"), segment: fd.get("segment"),
        domain: fd.get("domain"), content_type: fd.get("content_type"),
        audience: fd.get("audience"), review_date: fd.get("review_date"),
        source_url: fd.get("source_url"),
        tags: fd.get("tags").split(",").map(s => s.trim()).filter(Boolean),
        allowed_groups: fd.get("allowed_groups").split(",")
          .map(s => s.trim()).filter(Boolean),
        description: fd.get("description"), content: fd.get("content"),
      };
      const file = f.file.files[0];
      if (file) {
        if (file.size > 3.5 * 1024 * 1024) {
          msg.className = "msg err";
          msg.textContent = "File exceeds the 3.5 MB demo limit; " +
            "register it as a link or paste its text instead.";
          return;
        }
        const buf = await file.arrayBuffer();
        payload.filename = file.name;
        payload.file_base64 = bytesToBase64(new Uint8Array(buf));
      }
      try {
        const r = await api.post("/api/artifacts", payload);
        msg.classList.add("ok");
        msg.textContent = "Created DRAFT artifact " +
          r.artifact_id.slice(0, 8) +
          (r.warnings?.length ? " — " + r.warnings.join(" ") : "");
        f.reset();
      } catch (e) {
        msg.classList.add("err");
        msg.textContent = e.message;
      }
    });
}

/* --------------------------------------------------------- Govern */
async function renderGovern() {
  const lede = document.getElementById("govern-lede");
  if (state.persona === "consumer") {
    lede.textContent = "Consumers have read-only access. Lifecycle " +
      "actions require contributor, owner, approver, curator or admin " +
      "personas.";
  } else {
    lede.textContent = "Lifecycle queue for the " + state.persona +
      " persona. Buttons appear only where your role can transition.";
  }
  const { artifacts } = await api.get(
    `/api/artifacts?persona=${state.persona}&sort=updated_desc`);
  const items = artifacts.length ? artifacts : [];
  const { artifacts: superseded } = await api.get(
    `/api/artifacts?persona=${state.persona}&status=SUPERSEDED`);
  const all = [...items, ...superseded];
  document.getElementById("govern-list").innerHTML = all.map(a => {
    const step = TRANSITIONS[a.lifecycle_status];
    return `<div class="grow">
      <div class="info">
        <strong>${esc(a.title)}</strong> · v${esc(a.version)}
        <span class="pill pill-${esc(a.lifecycle_status)}">${esc(
          a.lifecycle_status)}</span>
        <div class="sub">owner ${esc(a.owner || "—")} · review
          ${esc(a.review_date || "—")}</div>
      </div>
      ${step && step.personas.includes(state.persona)
        ? `<button class="gbtn" data-id="${esc(a.id)}"
           data-target="${step.target}">${step.label}</button>`
        : '<span class="sub">No action for this persona</span>'}
    </div>`;
  }).join("") || "<p class='lede'>No artifacts in scope.</p>";
  document.querySelectorAll(".gbtn").forEach(b =>
    b.addEventListener("click", async () => {
      try {
        await api.post(`/api/artifacts/${b.dataset.id}/transition`, {
          persona: state.persona, target_status: b.dataset.target,
          note: "demo transition" });
        renderGovern();
      } catch (e) { alert(e.message); }
    }));
}

/* -------------------------------------------------------- Reports */
async function renderReports() {
  const r = await api.get(
    `/api/reports/quality?persona=${state.persona}`);
  document.getElementById("report-note").textContent = r.details_visible
    ? "Item-level remediation detail is visible to curator/admin personas."
    : "Aggregate counts only — item-level detail requires curator or " +
      "admin. Unauthorized content is never listed.";
  const labels = {
    review_overdue: "Review overdue / stale", unowned: "Unowned",
    superseded: "Superseded retained",
    duplicate_candidates: "Duplicate candidates",
    broken_links: "Broken links" };
  document.getElementById("report-cards").innerHTML =
    Object.entries(r.counts).map(([k, v]) => `
      <div class="acard"><h3>${v}</h3>
        <div class="sub">${labels[k] || k}</div></div>`).join("");
  let html = "";
  if (r.items) {
    for (const [k, arr] of Object.entries(r.items)) {
      if (!arr.length) continue;
      html += `<h3 style="margin:22px 0 8px">${labels[k] || k}</h3>` +
        arr.map(i => `<div class="vrow">${esc(i.title || i.url ||
          i.content_hash || i.id)}${i.version ? " · v" + esc(i.version)
          : ""}${i.review_date ? " · due " + esc(i.review_date) : ""}
          </div>`).join("");
    }
  }
  document.getElementById("report-items").innerHTML = html;
}

/* ----------------------------------------------------------- init */
document.querySelectorAll(".tab").forEach(t =>
  t.addEventListener("click", () => {
    if (t.dataset.page === "discover") return openDiscover();  // a panel
    document.querySelectorAll(".tab").forEach(x =>
      x.classList.remove("active"));
    document.querySelectorAll(".page").forEach(x =>
      x.classList.remove("active"));
    t.classList.add("active");
    document.getElementById("page-" + t.dataset.page)
      .classList.add("active");
    document.body.classList.toggle("chat-mode", t.dataset.page === "ask");
    renderPage(t.dataset.page);
  }));

document.getElementById("ask-form").addEventListener("submit", e => {
  e.preventDefault(); ask(); });
document.getElementById("new-chat").addEventListener("click", newChat);
document.querySelectorAll("#view-toggle button").forEach(b =>
  b.addEventListener("click", () => setView(b.dataset.mode)));
document.getElementById("opt-discover").addEventListener("change",
  e => setDiscoverForEveryone(e.target.checked));
document.getElementById("chat-list").addEventListener("click",
  onChatListClick);
// The chat sidebar's links to the other pages (the rail is hidden there).
document.querySelectorAll(".side-link, .discover-btn").forEach(b =>
  b.addEventListener("click", () => document.querySelector(
    `.tab[data-page="${b.dataset.goto}"]`)?.click()));
document.getElementById("q").addEventListener("keydown", e => {
  // Enter sends; Shift+Enter starts a new line.
  if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); ask(); } });
document.getElementById("q").addEventListener("input", e => {
  e.target.style.height = "";
  e.target.style.height = Math.min(e.target.scrollHeight, 160) + "px"; });
["dq", "dstatus", "daudience", "dsort"].forEach(id =>
  document.getElementById(id)?.addEventListener("input", loadArtifacts));
document.getElementById("discover-close").addEventListener("click",
  closeDiscover);
document.getElementById("discover-collapse").addEventListener("click",
  collapseDiscover);
document.getElementById("discover-tab").addEventListener("click",
  reopenDiscover);
document.getElementById("discover-expand").addEventListener("click", () =>
  setDiscoverExpanded(!document.body.classList.contains(
    "discover-expanded")));
document.getElementById("thread").addEventListener("click", e => {
  const copy = e.target.closest(".act-copy");
  if (copy) return copyAnswer(copy);
  const zip = e.target.closest(".act-zip");
  if (zip) return downloadSources(zip);
});
document.addEventListener("keydown", e => {
  // Esc closes the document drawer first, then the Discover panel.
  if (e.key !== "Escape" || e.target.classList?.contains("chat-rename"))
    return;
  const drawer = document.getElementById("drawer");
  if (!drawer.hidden) drawer.hidden = true;
  else closeDiscover();
});
document.getElementById("drawer-close").addEventListener("click",
  () => document.getElementById("drawer").hidden = true);
document.getElementById("drawer").addEventListener("click", e => {
  if (e.target.id === "drawer") e.target.hidden = true; });

if (document.getElementById("contrib")) bindContribute();
initChrome().then(() => renderAsk()).catch(e => {
  document.getElementById("main").innerHTML = `
    <section class="page active">
      <h1>POC service unavailable</h1>
      <p class="lede">${esc(e.message)}</p>
      <p class="lede">Refresh this page after the local server is running.</p>
    </section>`;
});
