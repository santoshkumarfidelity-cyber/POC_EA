"""v2: Entra ID sign-in and SharePoint-by-URL, against a fake Microsoft
(no network). Synthetic data only."""

import base64
import http.client
import json
import os
import tempfile
import threading
import time
import unittest
import urllib.parse
from unittest import mock

from ea_knowledge_agent.config import Settings
from ea_knowledge_agent.database import connect, initialize
from ea_knowledge_agent.entra import EntraAuth, SignInError
from ea_knowledge_agent.ingest import DocumentIngestor
from ea_knowledge_agent.sharepoint_connector import SharePointConnector

TENANT = "11111111-2222-3333-4444-555555555555"
CLIENT = "app-client-id"
ENV = {"AUTH_MODE": "entra", "ENTRA_TENANT_ID": TENANT,
       "ENTRA_CLIENT_ID": CLIENT, "ENTRA_CLIENT_SECRET": "test-secret",
       "ENTRA_GROUP_MAP": "grp-ea=EA_ALL; grp-ea=EA_INSURANCE; "
                          "grp-admin=EA_ADMINS",
       "ENTRA_DEFAULT_GROUPS": "", "ENTRA_REDIRECT_URI": "",
       "POC_PHASE": "1", "DISCOVER_FOR_EVERYONE": "",
       "VERTEX_PROJECT": "", "VERTEX_MODEL": "", "ANTHROPIC_API_KEY": "",
       "VERTEX_EMBED_MODEL": ""}


def _settings(**kw):
    base = dict(auth_mode="entra", entra_tenant_id=TENANT,
                entra_client_id=CLIENT, entra_client_secret="test-secret",
                entra_group_map=(("grp-ea", "EA_ALL"),
                                 ("grp-admin", "EA_ADMINS")))
    base.update(kw)
    return Settings(**base)


def _id_token(**claims):
    now = time.time()
    body = {"iss": f"https://login.microsoftonline.com/{TENANT}/v2.0",
            "aud": CLIENT, "tid": TENANT, "exp": now + 3600, "nbf": now - 5,
            "oid": "user-oid-1", "name": "Test User",
            "preferred_username": "test.user@example.test",
            "groups": ["grp-ea"]}
    body.update(claims)
    enc = lambda d: base64.urlsafe_b64encode(
        json.dumps(d).encode()).rstrip(b"=").decode()
    return f"{enc({'alg': 'RS256'})}.{enc(body)}.sig"


class IdTokenTests(unittest.TestCase):
    def setUp(self):
        self.auth = EntraAuth(_settings())

    def test_a_good_token_passes(self):
        c = self.auth.check_id_token(_id_token(nonce="n1"), "n1")
        self.assertEqual(c["oid"], "user-oid-1")

    def test_each_check_refuses_a_bad_token(self):
        for bad in ({"aud": "other-app"},
                    {"iss": "https://login.microsoftonline.com/"
                            "99999999-2222-3333-4444-555555555555/v2.0"},
                    {"tid": "99999999-2222-3333-4444-555555555555"},
                    {"exp": time.time() - 3600},
                    {"nonce": "wrong"}, {"oid": ""}):
            with self.subTest(bad=bad):
                tok = _id_token(**{"nonce": "n1", **bad})
                with self.assertRaises(SignInError):
                    self.auth.check_id_token(tok, "n1")

    def test_group_overage_is_explained(self):
        tok = _id_token(nonce="n1", _claim_names={"groups": "src1"})
        payload = json.loads(base64.urlsafe_b64decode(
            tok.split(".")[1] + "=="))
        payload.pop("groups")
        enc = base64.urlsafe_b64encode(json.dumps(payload).encode()) \
            .rstrip(b"=").decode()
        with self.assertRaisesRegex(SignInError, "too many groups"):
            self.auth.check_id_token(f"x.{enc}.y", "n1")

    def test_groups_and_roles_map_to_app_groups(self):
        auth = EntraAuth(_settings(
            entra_group_map=(("GRP-EA", "EA_ALL"), ("EA.Admin", "EA_ADMINS"),
                             ("grp-ea", "EA_ALL")),
            entra_default_groups=("EA_INSURANCE",)))
        self.assertEqual(auth.map_groups({"groups": ["grp-ea"],
                                          "roles": ["EA.Admin"]}),
                         ["EA_INSURANCE", "EA_ALL", "EA_ADMINS"])
        self.assertEqual(EntraAuth(_settings()).map_groups({}), [])

    def test_problem_reports_missing_settings(self):
        self.assertIn("ENTRA_CLIENT_SECRET", EntraAuth(_settings(
            entra_client_secret=None)).problem())
        self.assertIn("GUID", EntraAuth(_settings(
            entra_tenant_id="contoso.onmicrosoft.com")).problem())
        self.assertEqual(EntraAuth(_settings()).problem(), "")

    def test_redirect_uri_needs_localhost(self):
        auth = EntraAuth(_settings())
        self.assertEqual(auth.redirect_uri("localhost:8766"),
                         "http://localhost:8766/auth/callback")
        with self.assertRaises(SignInError):
            auth.redirect_uri("127.0.0.1:8766")


class SignInFlowTests(unittest.TestCase):
    """The browser's side of sign-in, through the real HTTP server."""

    def setUp(self):
        fd, self.path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        conn = connect(self.path)
        initialize(conn)
        DocumentIngestor(conn, Settings()).upsert(
            source_url="https://sp.example/Retention.txt",
            title="Data Retention Guidelines",
            data=b"Data Retention Guidelines.\nClaims records are kept for "
                 b"10 years after the claim closes.\n",
            filename="Retention.txt")
        conn.commit()
        conn.close()
        self.env = mock.patch.dict(os.environ, ENV)
        self.env.start()
        from ea_knowledge_agent.api import create_server
        self.server = create_server("127.0.0.1", 0, self.path,
                                    os.path.join(os.path.dirname(__file__),
                                                 os.pardir, "web"))
        threading.Thread(target=self.server.serve_forever,
                         daemon=True).start()
        self.port = self.server.server_address[1]
        self.token_requests = []

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.env.stop()
        os.unlink(self.path)

    def req(self, method, path, body=None, cookie="", headers=None):
        c = http.client.HTTPConnection("127.0.0.1", self.port, timeout=10)
        h = {"Host": f"localhost:{self.port}", **(headers or {})}
        if cookie:
            h["Cookie"] = cookie
        data = None
        if body is not None:
            data = json.dumps(body).encode()
            h["Content-Type"] = "application/json"
        c.request(method, path, body=data, headers=h)
        r = c.getresponse()
        out = (r.status, dict(r.getheaders()),
               r.msg.get_all("Set-Cookie") or [], r.read())
        c.close()
        return out

    def pending_nonce(self):
        conn = connect(self.path)
        row = conn.execute("SELECT nonce FROM auth_pending").fetchone()
        conn.close()
        return row[0] if row else ""

    def fake_microsoft(self, nonce="", **claims):
        """urlopen as Microsoft's token endpoint, answering with an ID
        token for this sign-in's nonce."""
        def fake(req, timeout=None, **kw):
            self.token_requests.append(
                (req.full_url, urllib.parse.parse_qs(req.data.decode())))
            resp = mock.MagicMock()
            resp.read.return_value = json.dumps({"id_token": _id_token(
                nonce=nonce, **claims)}).encode()
            resp.__enter__.return_value = resp
            return resp
        return fake

    def sign_in(self, **claims):
        st, h, cookies, _ = self.req("GET", "/auth/login")
        self.assertEqual(st, 302)
        loc = urllib.parse.urlparse(h["Location"])
        q = urllib.parse.parse_qs(loc.query)
        self.assertEqual(loc.netloc, "login.microsoftonline.com")
        self.assertEqual(q["code_challenge_method"], ["S256"])
        self.assertEqual(q["redirect_uri"],
                         [f"http://localhost:{self.port}/auth/callback"])
        state = q["state"][0]
        self.assertTrue(any(c.startswith(f"ea_login={state}")
                            for c in cookies))
        # the real fake: the token endpoint (Microsoft) is patched only
        # for the server's call; this client uses http.client.
        with mock.patch("urllib.request.urlopen",
                        self.fake_microsoft(self.pending_nonce(), **claims)):
            st, h, cookies, body = self.req(
                "GET", f"/auth/callback?code=abc&state={state}",
                cookie=f"ea_login={state}")
        session = next((c.split(";")[0] for c in cookies
                        if c.startswith("ea_session=") and
                        not c.startswith("ea_session=;")), "")
        return st, session, body

    def test_api_needs_sign_in(self):
        st, _, _, body = self.req("GET", "/api/me")
        self.assertEqual(st, 401)
        self.assertEqual(json.loads(body)["error"]["code"], "signed_out")
        st, _, _, _ = self.req("GET", "/api/health")
        self.assertEqual(st, 200)

    def test_sign_in_then_ask_in_your_own_chats(self):
        st, session, _ = self.sign_in()
        self.assertEqual(st, 302)
        self.assertTrue(session)
        url, form = self.token_requests[0]
        self.assertTrue(url.endswith(f"/{TENANT}/oauth2/v2.0/token"))
        self.assertEqual(form["grant_type"], ["authorization_code"])
        self.assertTrue(form["code_verifier"][0])
        st, _, _, body = self.req("GET", "/api/me", cookie=session)
        me = json.loads(body)
        self.assertEqual((st, me["auth_mode"], me["name"], me["admin"]),
                         (200, "entra", "Test User", False))
        # the persona the browser sends is ignored
        st, _, _, body = self.req("POST", "/api/agent/query", {
            "persona": "admin",
            "question": "How long are claims records kept?"},
            cookie=session)
        a = json.loads(body)
        self.assertEqual((st, a["status"]), (200, "grounded"))
        conn = connect(self.path)
        owner = conn.execute("SELECT persona FROM chats").fetchone()[0]
        conn.close()
        self.assertEqual(owner, "entra:user-oid-1")
        # the demo admin header doesn't make a user an admin
        st, _, _, _ = self.req("GET", "/api/artifacts?persona=admin",
                               cookie=session,
                               headers={"X-POC-View": "admin"})
        self.assertEqual(st, 403)
        # signing out ends the session
        st, _, cookies, _ = self.req("GET", "/auth/logout", cookie=session)
        self.assertEqual(st, 200)
        st, _, _, _ = self.req("GET", "/api/me", cookie=session)
        self.assertEqual(st, 401)

    def test_admin_group_makes_an_admin(self):
        st, session, _ = self.sign_in(groups=["grp-ea", "grp-admin"])
        st, _, _, body = self.req("GET", "/api/me", cookie=session)
        self.assertTrue(json.loads(body)["admin"])
        st, _, _, _ = self.req("GET", "/api/artifacts?persona=consumer",
                               cookie=session)
        self.assertEqual(st, 200)

    def test_user_without_an_ea_group_is_refused(self):
        st, session, body = self.sign_in(groups=["some-other-group"])
        self.assertEqual(st, 403)
        self.assertFalse(session)
        self.assertIn(b"not in an Entra group", body)

    def test_callback_from_another_browser_is_refused(self):
        st, h, _, _ = self.req("GET", "/auth/login")
        state = urllib.parse.parse_qs(urllib.parse.urlparse(
            h["Location"]).query)["state"][0]
        with mock.patch("urllib.request.urlopen",
                        self.fake_microsoft(self.pending_nonce())):
            st, _, _, body = self.req(
                "GET", f"/auth/callback?code=abc&state={state}",
                cookie="ea_login=someone-elses")
        self.assertEqual(st, 403)
        self.assertEqual(self.token_requests, [])   # code never redeemed

    def test_microsoft_error_is_shown(self):
        st, _, _, body = self.req(
            "GET", "/auth/callback?error=access_denied&error_description="
                   "User+cancelled")
        self.assertEqual(st, 403)
        self.assertIn(b"access_denied", body)

    def test_cross_site_post_is_refused(self):
        st, session, _ = self.sign_in()
        st, _, _, _ = self.req("POST", "/api/agent/query", {
            "question": "How long are claims records kept?"},
            cookie=session, headers={"Origin": "https://evil.example"})
        self.assertEqual(st, 403)


class SharePointByUrlTests(unittest.TestCase):
    def connector(self, **kw):
        base = dict(graph_tenant_id=TENANT, graph_client_id=CLIENT,
                    graph_client_secret="test-secret",
                    sharepoint_site_url="https://contoso.sharepoint.com/"
                                        "sites/EA POC",
                    sharepoint_library="Documents")
        base.update(kw)
        return SharePointConnector(Settings(**base))

    def test_site_and_library_are_found_by_name(self):
        sp, seen = self.connector(), []

        def fake_get(url):
            seen.append(url)
            if "/drives?" in url:
                return {"value": [
                    {"id": "d-other", "name": "Site Assets",
                     "webUrl": "https://contoso.sharepoint.com/sites/EA%20POC"
                               "/SiteAssets"},
                    {"id": "d-docs", "name": "Documents",
                     "webUrl": "https://contoso.sharepoint.com/sites/EA%20POC"
                               "/Shared%20Documents"}]}
            return {"id": "contoso.sharepoint.com,abc,def"}
        with mock.patch.object(sp, "_get", fake_get):
            self.assertTrue(sp.configured)
            self.assertEqual(sp.drive_id(), "d-docs")
        self.assertEqual(seen[0], "https://graph.microsoft.com/v1.0/sites/"
                                  "contoso.sharepoint.com:/sites/EA%20POC"
                                  "?$select=id")
        self.assertIn("/sites/contoso.sharepoint.com,abc,def/drives",
                      seen[1])

    def test_unknown_library_lists_the_real_ones(self):
        sp = self.connector(sharepoint_library="EA Docs")
        with mock.patch.object(sp, "_get", lambda url: {"value": [
                {"id": "d1", "name": "Documents", "webUrl": ""}]}
                if "/drives?" in url else {"id": "s1"}):
            with self.assertRaisesRegex(RuntimeError, "Documents"):
                sp.drive_id()

    def test_non_sharepoint_url_is_refused(self):
        sp = self.connector(sharepoint_site_url="https://evil.example/sites/x")
        with self.assertRaises(RuntimeError):
            sp.site_id()

    def test_folder_limits_the_sync(self):
        sp = self.connector(sharepoint_folder="EA/POC")
        item = lambda p: {"parentReference": {"path": p}}
        self.assertTrue(sp.in_folder(item("/drive/root:/EA/POC")))
        self.assertTrue(sp.in_folder(item("/drive/root:/EA/POC/Sub%20dir")))
        self.assertFalse(sp.in_folder(item("/drive/root:/EA/POCKET")))
        self.assertFalse(sp.in_folder(item("/drive/root:/HR")))
        self.assertTrue(self.connector().in_folder(item("/drive/root:/HR")))


if __name__ == "__main__":
    unittest.main()
