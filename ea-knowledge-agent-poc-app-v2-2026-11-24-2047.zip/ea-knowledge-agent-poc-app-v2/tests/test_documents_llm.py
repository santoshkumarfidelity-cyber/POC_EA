"""Tests for real-document ingestion (folder / SharePoint), chunk-level
retrieval and Vertex AI answer generation. No network: HTTP is stubbed."""

import io
import json
import os
import re
import tempfile
import unittest
from unittest import mock

from ea_knowledge_agent.agent import KnowledgeAgent
from ea_knowledge_agent.auth import get_persona
from ea_knowledge_agent.claude_client import ClaudeClient, build_evidence_text
from ea_knowledge_agent import config
from ea_knowledge_agent.config import Settings, read_env_file
from ea_knowledge_agent.database import connect, initialize
from ea_knowledge_agent.ingest import DocumentIngestor, file_uri, \
    local_path, sync_folder, sync_sharepoint
from ea_knowledge_agent.repository import KnowledgeRepository
from ea_knowledge_agent.retrieval import PermissionAwareRetriever
from ea_knowledge_agent.versions import diff_text
from ea_knowledge_agent.embeddings import index_missing
from ea_knowledge_agent.vertex_client import VertexClient, VertexEmbedder

from tests.test_acceptance import _docx_bytes, _pptx_bytes

VIEWER = get_persona("consumer")


def _settings(**kw):
    base = dict(vertex_project="proj", vertex_model="gemini-test",
                vertex_access_token="tok")
    base.update(kw)
    return Settings(**base)


class Fresh(unittest.TestCase):
    def setUp(self):
        fd, self.path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        self.conn = connect(self.path)
        initialize(self.conn)
        self.ing = DocumentIngestor(self.conn, Settings())

    def tearDown(self):
        self.conn.close()
        os.unlink(self.path)

    def add(self, title, text, url=None, **kw):
        return self.ing.upsert(
            source_url=url or f"https://sp.example/{title}.txt",
            title=title, data=text.encode(), filename=f"{title}.txt", **kw)


class IngestTests(Fresh):
    def test_added_doc_is_approved_current_and_visible(self):
        self.assertEqual(self.add("Cloud Standard", "Use zone redundancy.")[0],
                         "added")
        row = self.conn.execute(
            "SELECT lifecycle_status, is_current_approved FROM "
            "artifact_versions").fetchone()
        self.assertEqual((row[0], row[1]), ("APPROVED", 1))
        hits = PermissionAwareRetriever(self.conn).search(
            VIEWER, "zone redundancy")
        self.assertEqual(hits[0]["title"], "Cloud Standard")

    def test_resync_unchanged_then_changed_supersedes(self):
        self.add("Std", "version one text about encryption")
        self.assertEqual(self.add("Std", "version one text about encryption")[0],
                         "unchanged")
        self.assertEqual(self.add("Std", "version two about key rotation")[0],
                         "updated")
        st = [r[0] for r in self.conn.execute(
            "SELECT lifecycle_status FROM artifact_versions ORDER BY version")]
        self.assertEqual(st, ["SUPERSEDED", "APPROVED"])
        hits = PermissionAwareRetriever(self.conn).search(VIEWER,
                                                          "key rotation")
        self.assertEqual(len(hits), 1)
        self.assertEqual(hits[0]["version"], "2.0")

    def test_duplicate_content_under_other_url_is_skipped(self):
        self.add("A", "identical body text here", url="https://sp.example/a")
        self.assertEqual(self.add("B", "identical body text here",
                                  url="https://sp.example/b")[0], "duplicate")

    def test_missing_source_file_is_archived(self):
        self.add("Gone", "will be removed from source")
        self.assertEqual(self.ing.archive_missing(set()), 1)
        self.assertEqual(PermissionAwareRetriever(self.conn).search(
            VIEWER, "removed source"), [])

    def test_unsupported_and_empty_files_are_skipped(self):
        self.assertEqual(self.ing.upsert(
            source_url="https://sp/x.vsdx", title="x", data=b"1",
            filename="x.vsdx")[0], "skipped")
        self.assertEqual(self.ing.upsert(
            source_url="https://sp/y.txt", title="y", data=b"  ",
            filename="y.txt")[0], "skipped")

    def test_folder_names_become_domain_and_tags(self):
        self.add("Pattern", "api gateway pattern", folders=("Patterns", "API"))
        d = self.conn.execute("SELECT domain FROM artifact_families"
                              ).fetchone()[0]
        tags = {r[0] for r in self.conn.execute(
            "SELECT tag FROM artifact_tags")}
        self.assertEqual(d, "PATTERNS")
        self.assertTrue({"PATTERNS", "API", "TXT"} <= tags)

    def test_sync_folder_reads_txt_docx_pptx_and_archives_removed(self):
        with tempfile.TemporaryDirectory() as d:
            os.makedirs(os.path.join(d, "Strategy"))
            for rel, data in (
                    ("Strategy/s.txt",
                     b"Platform strategy: adopt event driven integration."),
                    ("p.docx",
                     _docx_bytes("Data retention policy is seven years.")),
                    ("o.pptx",
                     _pptx_bytes("Onboarding roadmap for new architects"))):
                with open(os.path.join(d, rel), "wb") as fh:
                    fh.write(data)
            st = sync_folder(self.ing, d)
            self.assertEqual(st["added"], 3)
            self.assertEqual(sync_folder(self.ing, d)["unchanged"], 3)
            os.remove(os.path.join(d, "p.docx"))
            self.assertEqual(sync_folder(self.ing, d)["archived"], 1)


class FakeSharePoint:
    def __init__(self, files):
        self.files = files            # id -> (name, bytes)
        self.fail = set()

    def list_files(self):
        return [{"id": i, "name": n, "webUrl": f"https://sp.example/{n}",
                 "file": {}, "parentReference": {
                     "driveId": "d", "path": "/drives/d/root:/Standards"},
                 "lastModifiedBy": {"user": {"displayName": "Ana Ng"}},
                 "lastModifiedDateTime": "2026-10-01T00:00:00Z"}
                for i, (n, _) in self.files.items()]

    def download_item(self, drive_id, item_id):
        if item_id in self.fail:
            raise RuntimeError("download failed")
        return self.files[item_id][1]


class SourceFileTests(Fresh):
    """The original file of a synced document opens through the server."""

    def setUp(self):
        super().setUp()
        self.dir = tempfile.mkdtemp()
        with open(os.path.join(self.dir, "Retention Rules.txt"), "wb") as f:
            f.write(b"Claims records are kept for ten years.")
        sync_folder(self.ing, self.dir)
        self.vid = self.conn.execute(
            "SELECT id FROM artifact_versions").fetchone()[0]
        self.conn.commit()
        import threading
        from ea_knowledge_agent.api import create_server
        self.server = create_server("127.0.0.1", 0, self.path,
                                    os.path.join(os.path.dirname(
                                        __file__), os.pardir, "web"))
        threading.Thread(target=self.server.serve_forever,
                         daemon=True).start()
        self.base = f"http://127.0.0.1:{self.server.server_address[1]}"

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()

    def get(self, vid):
        import urllib.error
        import urllib.request
        try:
            with urllib.request.urlopen(
                    f"{self.base}/api/artifacts/{vid}/file?persona=consumer"
                    ) as r:
                return r.status, r.read()
        except urllib.error.HTTPError as e:
            return e.code, b""

    def test_synced_file_is_served(self):
        self.assertEqual(self.get(self.vid),
                         (200, b"Claims records are kept for ten years."))

    def test_non_synced_artifact_is_never_read_from_disk(self):
        # Contributed artifacts carry a user-typed source_url.
        self.conn.execute("UPDATE artifact_families SET contributor='owner'")
        self.conn.commit()
        self.assertEqual(self.get(self.vid)[0], 404)
        self.assertEqual(self.get("missing")[0], 404)

    def post_open(self, vid, ctype="application/json"):
        import urllib.error
        import urllib.request
        req = urllib.request.Request(
            f"{self.base}/api/artifacts/{vid}/open",
            data=b'{"persona": "consumer"}', method="POST",
            headers={"Content-Type": ctype})
        try:
            with urllib.request.urlopen(req) as r:
                return r.status, json.loads(r.read())
        except urllib.error.HTTPError as e:
            return e.code, {}

    def test_open_launches_the_desktop_app(self):
        with mock.patch("ea_knowledge_agent.api.subprocess.Popen") as popen, \
                mock.patch("ea_knowledge_agent.api.os.startfile",
                           create=True) as startfile:
            status, body = self.post_open(self.vid)
        self.assertEqual((status, body),
                         (200, {"opened": "Retention Rules.txt"}))
        launched = startfile.call_args or popen.call_args
        self.assertIn("Retention Rules.txt", str(launched))

    def test_open_refuses_non_json_and_non_synced(self):
        with mock.patch("ea_knowledge_agent.api.subprocess.Popen") as popen:
            self.assertEqual(self.post_open(self.vid, "text/plain")[0], 400)
            self.conn.execute(
                "UPDATE artifact_families SET contributor='owner'")
            self.conn.commit()
            self.assertEqual(self.post_open(self.vid)[0], 404)
        popen.assert_not_called()

    def test_older_version_file_is_not_served(self):
        with open(os.path.join(self.dir, "Retention Rules.txt"), "wb") as f:
            f.write(b"Claims records are kept for twelve years.")
        sync_folder(self.ing, self.dir)
        self.assertEqual(self.get(self.vid)[0], 404)       # now v1, old
        cur = self.conn.execute("SELECT id FROM artifact_versions WHERE "
                                "is_current_approved=1").fetchone()[0]
        self.assertEqual(self.get(cur)[1],
                         b"Claims records are kept for twelve years.")

    def test_changes_endpoint(self):
        import urllib.request
        with open(os.path.join(self.dir, "Retention Rules.txt"), "wb") as f:
            f.write(b"Claims records are kept for twelve years.")
        sync_folder(self.ing, self.dir)
        cur = self.conn.execute("SELECT id FROM artifact_versions WHERE "
                                "is_current_approved=1").fetchone()[0]
        with urllib.request.urlopen(f"{self.base}/api/artifacts/{cur}/"
                                    "changes?persona=consumer") as r:
            body = json.loads(r.read())
        self.assertEqual((body["from"]["version"], body["to"]["version"],
                          body["added"], body["removed"]),
                         ("1.0", "2.0", 1, 1))

    def test_file_uri_round_trip_and_legacy_windows_form(self):
        p = os.path.join(self.dir, "Retention Rules.txt")
        self.assertEqual(local_path(file_uri(p)), os.path.abspath(p))
        self.assertEqual(local_path("file://C%3A%5Cdocs%5Ca%20b.md"),
                         "C:\\docs\\a b.md")
        self.assertIsNone(local_path("https://sp.example/a.docx"))


class EnvFileTests(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.mkdtemp()
        self.path = os.path.join(self.dir, ".env")
        with open(self.path, "w") as f:
            f.write("# comment\n\nVERTEX_PROJECT=proj-1\n"
                    'export VERTEX_MODEL="gemini-x"\n'
                    "VERTEX_LOCATION=europe-west4  # region\n"
                    "ANTHROPIC_API_KEY=\n")

    def tearDown(self):
        os.remove(self.path)

    def test_parses_comments_quotes_export_and_skips_empty(self):
        self.assertEqual(read_env_file(self.path), {
            "VERTEX_PROJECT": "proj-1", "VERTEX_MODEL": "gemini-x",
            "VERTEX_LOCATION": "europe-west4"})
        self.assertEqual(read_env_file(self.path + ".missing"), {})

    def test_shell_variables_win_over_the_file(self):
        with mock.patch.object(config, "_APP_ROOT", self.dir), \
                mock.patch.dict(os.environ, {"VERTEX_MODEL": "from-shell"}):
            s = config.load_settings()
        self.assertEqual((s.vertex_project, s.vertex_model),
                         ("proj-1", "from-shell"))


class SharePointSyncTests(Fresh):
    def test_sync_maps_owner_folders_and_url(self):
        sp = FakeSharePoint({"1": ("Sec.txt", b"zero trust network rules")})
        st = sync_sharepoint(self.ing, sp)
        self.assertEqual(st["added"], 1)
        fam = self.conn.execute(
            "SELECT owner, domain FROM artifact_families").fetchone()
        self.assertEqual((fam[0], fam[1]), ("Ana Ng", "STANDARDS"))
        self.assertEqual(self.conn.execute(
            "SELECT source_url FROM artifact_versions").fetchone()[0],
            "https://sp.example/Sec.txt")

    def test_failed_download_blocks_archiving(self):
        sp = FakeSharePoint({"1": ("A.txt", b"alpha doc body"),
                             "2": ("B.txt", b"beta doc body")})
        sync_sharepoint(self.ing, sp)
        del sp.files["1"]                 # A removed at source
        sp.fail.add("2")                  # B temporarily fails
        st = sync_sharepoint(self.ing, sp)
        self.assertEqual((st["failed"], st["archived"]), (1, 0))
        sp.fail.clear()
        self.assertEqual(sync_sharepoint(self.ing, sp)["archived"], 1)


class ChunkRetrievalTests(Fresh):
    def test_answer_buried_deep_in_long_doc_is_returned_as_passage(self):
        filler = "General background paragraph about nothing. " * 120
        needle = "The disaster recovery RTO for tier one systems is four hours."
        self.add("Big Doc", filler + "\n" + needle + "\n" + filler)
        hit = PermissionAwareRetriever(self.conn).search(
            VIEWER, "What is the disaster recovery RTO for tier one?")[0]
        self.assertTrue(any("four hours" in p for p in hit["passages"]))
        self.assertIn("[1] Big Doc", build_evidence_text([hit]))
        self.assertIn("four hours", build_evidence_text([hit]))


def _vertex_response(text):
    body = json.dumps({"candidates": [{"content": {"parts": [
        {"text": text}]}}]}).encode()
    resp = mock.MagicMock()
    resp.read.return_value = body
    resp.__enter__.return_value = resp
    return resp


class VertexTests(Fresh):
    def setUp(self):
        super().setUp()
        self.add("DR Standard", "The disaster recovery RTO is four hours.")

    def agent(self, vertex):
        return KnowledgeAgent(self.conn, vertex=vertex)

    def test_not_configured_without_project_and_model(self):
        self.assertFalse(VertexClient(Settings()).configured)
        self.assertTrue(VertexClient(_settings()).configured)

    def test_request_shape_and_answer_used(self):
        seen = {}

        def fake(req, timeout=None, **kw):
            seen["url"] = req.full_url
            seen["auth"] = req.get_header("Authorization")
            seen["body"] = json.loads(req.data.decode())
            return _vertex_response("RTO is four hours [1].")
        with mock.patch("urllib.request.urlopen", fake):
            a = self.agent(VertexClient(_settings())).ask(
                VIEWER, "What is the disaster recovery RTO?")
        self.assertEqual((a.provider, a.status), ("vertex", "grounded"))
        self.assertEqual(a.answer, "RTO is four hours [1].")
        self.assertEqual(a.citations[0].title, "DR Standard")
        self.assertEqual(seen["auth"], "Bearer tok")
        self.assertIn("us-central1-aiplatform.googleapis.com/v1/projects/"
                      "proj/locations/us-central1/publishers/google/models/"
                      "gemini-test:generateContent", seen["url"])
        prompt = seen["body"]["contents"][0]["parts"][0]["text"]
        self.assertIn("[1] DR Standard", prompt)
        self.assertIn("four hours", prompt)

    def test_global_location_host(self):
        c = VertexClient(_settings(vertex_location="global"))
        self.assertTrue(c._url().startswith(
            "https://aiplatform.googleapis.com/v1/projects/proj/"
            "locations/global/"))

    def test_bad_project_value_is_rejected(self):
        c = VertexClient(_settings(vertex_project="x/../evil"))
        with self.assertRaises(RuntimeError):
            c._url()

    def test_llm_failure_falls_back_to_local_with_citations(self):
        def boom(req, timeout=None, **kw):
            raise OSError("down")
        with mock.patch("urllib.request.urlopen", boom):
            a = self.agent(VertexClient(_settings())).ask(
                VIEWER, "What is the disaster recovery RTO?")
        self.assertEqual((a.provider, a.status),
                         ("local-fallback", "grounded"))
        self.assertTrue(a.citations)

    def test_no_evidence_never_calls_llm(self):
        with mock.patch("urllib.request.urlopen") as m:
            a = self.agent(VertexClient(_settings())).ask(
                VIEWER, "Policy on quantum teleportation hardware?")
        self.assertEqual(a.status, "insufficient_evidence")
        m.assert_not_called()


class RetrievalDebugLogTests(Fresh):
    def setUp(self):
        super().setUp()
        self.add("DR Standard", "The disaster recovery RTO is four hours.")
        self.add("Lunch Menu", "Soup and salad on Mondays.")
        self.log = os.path.join(tempfile.mkdtemp(), "retrieval_debug.log")

    def ask(self, enabled):
        env = {"RETRIEVAL_DEBUG": "1" if enabled else "0",
               "RETRIEVAL_DEBUG_LOG": self.log, "VERTEX_PROJECT": "",
               "VERTEX_EMBED_MODEL": ""}
        with mock.patch.dict(os.environ, env):
            return KnowledgeAgent(self.conn).ask(
                VIEWER, "What is the disaster recovery RTO?")

    def events(self):
        out = []
        with open(self.log, encoding="utf-8") as fh:
            for line in fh:
                ts, req, name, body = line.rstrip("\n").split(" | ", 3)
                out.append((ts, req, name, json.loads(body)))
        return out

    def test_every_field_is_logged_under_one_request_id(self):
        a = self.ask(True)
        ev = self.events()
        self.assertEqual(len({req for _, req, _, _ in ev}), 1)
        self.assertTrue(all(ts.endswith("Z") for ts, *_ in ev))
        by = {}
        for _, _, name, body in ev:
            by.setdefault(name, []).append(body)
        req = by["request"][0]
        self.assertEqual(req["database"], os.path.realpath(self.path))
        self.assertEqual(req["question"], "What is the disaster recovery RTO?")
        self.assertEqual(req["groups"], list(VIEWER.groups))
        self.assertIn("artifact_acl_groups", by["sql"][0]["statement"])
        self.assertEqual(by["sql"][0]["params"], list(VIEWER.groups))
        self.assertEqual(by["candidates"][0]["count"], 2)
        self.assertIn("rto", by["query"][0]["tokens"])
        self.assertEqual(by["score"][0]["title"], "DR Standard")
        self.assertIn("overlap", by["score"][0]["parts"])
        self.assertEqual(by["excluded"][0]["title"], "Lunch Menu")
        self.assertIn("no question word", by["excluded"][0]["reason"])
        self.assertEqual([d["title"] for d in
                          by["final_documents"][0]["documents"]],
                         ["DR Standard"])
        self.assertEqual(by["answer"][0]["status"], a.status)
        self.assertIn("llm", by)
        with open(self.log, encoding="utf-8") as fh:
            self.assertNotIn("four hours", fh.read())   # no document text

    def test_off_by_default_writes_nothing(self):
        self.ask(False)
        self.assertFalse(os.path.exists(self.log))


class VersionHistoryTests(Fresh):
    URL = "https://sp.example/Policy.txt"

    def bump(self, n):
        for i in range(n):
            self.add("Policy", f"Policy text revision {i}\nshared line",
                     url=self.URL)

    def versions(self):
        return [r[0] for r in self.conn.execute(
            "SELECT version FROM artifact_versions ORDER BY rowid")]

    def test_only_five_versions_are_kept_and_numbers_never_repeat(self):
        self.bump(7)                                   # v1.0 .. v7.0
        self.assertEqual(self.versions(),
                         ["3.0", "4.0", "5.0", "6.0", "7.0"])
        self.bump(1)
        self.assertEqual(self.versions()[-1], "8.0")
        self.assertEqual(len(self.versions()), 5)
        orphans = self.conn.execute(
            """SELECT COUNT(*) FROM lifecycle_events WHERE version_id NOT IN
               (SELECT id FROM artifact_versions)""").fetchone()[0]
        self.assertEqual(orphans, 0)
        cur = self.conn.execute("SELECT version FROM artifact_versions "
                                "WHERE is_current_approved=1").fetchone()
        self.assertEqual(cur[0], "8.0")

    def test_max_versions_setting(self):
        self.ing = DocumentIngestor(self.conn, Settings(max_versions=2))
        self.bump(4)
        self.assertEqual(self.versions(), ["3.0", "4.0"])

    def test_changes_against_previous_version(self):
        self.add("Policy", "Intro\nKeep records 7 years\nOutro",
                 url=self.URL)
        self.add("Policy", "Intro\nKeep records 10 years\nOutro\nNew rule",
                 url=self.URL)
        repo = KnowledgeRepository(self.conn)
        cur, old = [r[0] for r in self.conn.execute(
            "SELECT id FROM artifact_versions ORDER BY rowid DESC")]
        c = repo.get_version_changes(VIEWER, cur)
        self.assertEqual((c["from"]["version"], c["to"]["version"]),
                         ("1.0", "2.0"))
        self.assertEqual((c["added"], c["removed"]), (2, 1))
        ops = {(l["op"], l["text"]) for l in c["lines"]}
        self.assertIn(("del", "Keep records 7 years"), ops)
        self.assertIn(("add", "Keep records 10 years"), ops)
        self.assertIn(("add", "New rule"), ops)
        self.assertIsNone(repo.get_version_changes(VIEWER, old)["from"])

    def test_changes_respect_acl(self):
        DocumentIngestor(self.conn, Settings(
            sync_allowed_groups=("EA_ADMINS",))).upsert(
            source_url="https://sp.example/s.txt", title="Secret",
            data=b"secret", filename="s.txt")
        vid = self.conn.execute("SELECT id FROM artifact_versions").fetchone()[0]
        repo = KnowledgeRepository(self.conn)
        self.assertIsNone(repo.get_version_changes(VIEWER, vid))
        self.assertIsNotNone(repo.get_version_changes(
            get_persona("admin"), vid))

    def test_discover_shows_version_count(self):
        self.bump(3)
        items = KnowledgeRepository(self.conn).list_artifacts(VIEWER)
        self.assertEqual([(i["version"], i["version_count"]) for i in items],
                         [("3.0", 3)])

    def test_diff_reports_identical_text(self):
        d = diff_text("same\ntext", "same\ntext")
        self.assertEqual((d["added"], d["removed"], d["identical_text"]),
                         (0, 0, True))


# Each concept is one dimension, so words with the same meaning embed
# alike and similarity is predictable.
_CONCEPTS = [{"keep", "retention", "retained", "retain", "kept"},
             {"files", "records", "data"},
             {"outage", "disaster", "recovery", "rto"},
             {"quantum", "teleportation"}]


class StubEmbedder:
    configured, model, min_similarity = True, "stub-embed", 0.6

    def __init__(self, fail=False):
        self.fail, self.calls = fail, []

    def embed(self, texts, task, title=""):
        self.calls.append((task, len(texts)))
        if self.fail:
            raise RuntimeError("embedding down")
        out = []
        for t in texts:
            words = re.findall(r"[a-z]+", t.lower())
            out.append([float(sum(w in c for w in words))
                        for c in _CONCEPTS] + [0.1])
        return out


class SemanticRetrievalTests(Fresh):
    def setUp(self):
        super().setUp()
        self.add("Records Policy",
                 "The retention period for records is seven years.")
        self.add("DR Standard", "The disaster recovery RTO is four hours.")
        self.emb = StubEmbedder()
        index_missing(self.conn, self.emb)

    def search(self, q, persona=VIEWER, emb=None):
        return PermissionAwareRetriever(self.conn, emb or self.emb).search(
            persona, q)

    def test_synonym_question_without_shared_words_finds_document(self):
        q = "How long do we keep files?"
        self.assertEqual(PermissionAwareRetriever(self.conn).search(
            VIEWER, q), [])                       # keyword-only misses it
        hits = self.search(q)
        self.assertEqual(hits[0]["title"], "Records Policy")
        self.assertIn("seven years", hits[0]["passages"][0])
        self.assertIn("seven years", hits[0]["excerpt"])
        self.assertGreater(hits[0]["similarity"], 0.9)

    def test_unrelated_question_still_abstains_without_llm(self):
        with mock.patch("urllib.request.urlopen") as m:
            a = KnowledgeAgent(self.conn, vertex=VertexClient(_settings()),
                               embedder=self.emb).ask(
                VIEWER, "Rules on quantum teleportation hardware?")
        self.assertEqual(a.status, "insufficient_evidence")
        m.assert_not_called()

    def test_restricted_document_is_never_a_semantic_match(self):
        DocumentIngestor(self.conn, Settings(
            sync_allowed_groups=("EA_ADMINS",))).upsert(
            source_url="https://sp.example/secret.txt", title="Secret Keep",
            data=b"Kept retained retention.", filename="secret.txt")
        index_missing(self.conn, self.emb)
        titles = [h["title"] for h in self.search("keep files")]
        self.assertNotIn("Secret Keep", titles)
        self.assertIn("Secret Keep", [h["title"] for h in self.search(
            "keep files", persona=get_persona("admin"))])

    def test_embedding_failure_falls_back_to_keyword_search(self):
        hits = self.search("disaster recovery RTO",
                           emb=StubEmbedder(fail=True))
        self.assertEqual(hits[0]["title"], "DR Standard")
        self.assertEqual(hits[0]["similarity"], 0.0)

    def test_index_skips_embedded_and_drops_superseded_versions(self):
        self.assertEqual(index_missing(self.conn, self.emb)["documents"], 0)
        self.add("Records Policy", "Records are retained for ten years.",
                 url="https://sp.example/Records Policy.txt")
        self.assertEqual(index_missing(self.conn, self.emb)["documents"], 1)
        texts = [r[0] for r in self.conn.execute(
            "SELECT chunk_text FROM artifact_chunks")]
        self.assertEqual(len(texts), 2)
        self.assertTrue(any("ten years" in t for t in texts))
        self.assertFalse(any("seven years" in t for t in texts))

    def test_index_stops_at_first_failure(self):
        self.add("New Doc", "Some new retention content.")
        stats = index_missing(self.conn, StubEmbedder(fail=True))
        self.assertEqual(stats["documents"], 0)
        self.assertIn("embedding down", stats["error"])


def _embed_response(n):
    body = json.dumps({"predictions": [
        {"embeddings": {"values": [0.6, 0.8]}}] * n}).encode()
    resp = mock.MagicMock()
    resp.read.return_value = body
    resp.__enter__.return_value = resp
    return resp


class DatabasePathTests(unittest.TestCase):
    def test_relative_db_path_means_the_project_folder(self):
        from ea_knowledge_agent.config import _APP_ROOT, app_path
        here = os.getcwd()
        tmp = tempfile.mkdtemp()
        try:
            os.chdir(tmp)       # start the command from another folder
            with mock.patch.dict(os.environ, {"POC_DB": "data/poc.db"}):
                got = config.load_settings().db_path
        finally:
            os.chdir(here)
        self.assertEqual(got, os.path.join(_APP_ROOT, "data/poc.db"))
        absolute = os.path.join(tmp, "x.db")
        self.assertEqual(app_path(absolute), absolute)

    def test_describe_db(self):
        from ea_knowledge_agent.database import describe_db
        fd, path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        os.remove(path)
        self.assertEqual(describe_db(path), "new, empty")
        conn = connect(path)
        initialize(conn)
        conn.close()
        self.assertEqual(describe_db(path), "0 current approved documents")
        os.remove(path)


class FolderSyncSafetyTests(Fresh):
    def test_missing_or_empty_folder_archives_nothing(self):
        from ea_knowledge_agent import sync
        from ea_knowledge_agent.ingest import sync_folder
        src = tempfile.mkdtemp()
        with open(os.path.join(src, "a.txt"), "w") as fh:
            fh.write("Claims records are kept for ten years.")
        ing = DocumentIngestor(self.conn, _settings())
        self.assertEqual(sync_folder(ing, src)["added"], 1)
        os.remove(os.path.join(src, "a.txt"))
        self.assertEqual(sync_folder(ing, src)["archived"], 0)
        with self.assertRaises(FileNotFoundError):
            sync_folder(ing, os.path.join(src, "typo"))
        self.conn.close()
        with mock.patch("sys.stderr", io.StringIO()), \
                mock.patch("sys.stdout", io.StringIO()):
            rc = sync.main(["--db", self.path, "--reset",
                            "--folder", os.path.join(src, "typo")])
        self.assertEqual(rc, 2)
        self.assertTrue(os.path.exists(self.path))   # --reset not applied
        self.conn = connect(self.path)


class VertexAnswerRequestTests(unittest.TestCase):
    def test_prompt_asks_for_an_explained_cited_answer(self):
        seen = []

        def fake(req, timeout=None, **kw):
            seen.append(json.loads(req.data.decode()))
            body = json.dumps({"candidates": [{"content": {"parts": [
                {"text": "Ten years [1]."}]}}]}).encode()
            resp = mock.MagicMock()
            resp.read.return_value = body
            resp.__enter__.return_value = resp
            return resp
        ev = [{"title": "Retention", "version": "1.0", "source_url": "u",
               "passages": [f"passage {i}" for i in range(5)]}]
        with mock.patch("urllib.request.urlopen", fake):
            out = VertexClient(_settings()).synthesize("How long?", ev)
        self.assertEqual(out, "Ten years [1].")
        sent = seen[0]
        prompt = sent["systemInstruction"]["parts"][0]["text"]
        self.assertIn("in your own words", prompt)
        self.assertIn("numbered [1]", prompt)
        # room for Gemini 2.5 thinking tokens plus the answer
        self.assertGreaterEqual(
            sent["generationConfig"]["maxOutputTokens"], 4096)
        self.assertIn("passage 4", sent["contents"][0]["parts"][0]["text"])


def _sse(events):
    """A fake streaming HTTP response: one `data:` line per event."""
    resp = mock.MagicMock()
    lines = [b": keep-alive\n"] + [
        f"data: {json.dumps(e)}\n".encode() for e in events]
    resp.__iter__.return_value = iter(lines)
    resp.__enter__.return_value = resp
    return resp


class StreamClientTests(unittest.TestCase):
    EV = [{"title": "Retention", "version": "1.0", "source_url": "u",
           "passages": ["Ten years."]}]

    def test_vertex_streams_text_parts(self):
        seen = []

        def fake(req, timeout=None, **kw):
            seen.append(req.full_url)
            return _sse([{"candidates": [{"content": {"parts": [
                {"text": "Ten "}]}}]},
                {"candidates": [{"content": {"parts": [
                    {"text": "years [1]."}]}}]}])
        with mock.patch("urllib.request.urlopen", fake):
            out = list(VertexClient(_settings()).stream("How long?", self.EV))
        self.assertEqual(out, ["Ten ", "years [1]."])
        self.assertTrue(seen[0].endswith(
            "models/gemini-test:streamGenerateContent?alt=sse"))

    def test_vertex_stream_failure_raises(self):
        def boom(req, timeout=None, **kw):
            raise OSError("down")
        with mock.patch("urllib.request.urlopen", boom):
            with self.assertRaises(RuntimeError):
                list(VertexClient(_settings()).stream("How long?", self.EV))

    def test_claude_streams_text_deltas(self):
        seen = []

        def fake(req, timeout=None, **kw):
            seen.append(json.loads(req.data.decode()))
            return _sse([
                {"type": "message_start"},
                {"type": "content_block_delta",
                 "delta": {"type": "text_delta", "text": "Ten "}},
                {"type": "content_block_delta",
                 "delta": {"type": "text_delta", "text": "years [1]."}},
                {"type": "message_stop"}])
        c = ClaudeClient(Settings(anthropic_api_key="k",
                                  claude_model="claude-test"))
        with mock.patch("urllib.request.urlopen", fake):
            out = list(c.stream("How long?", self.EV))
        self.assertEqual(out, ["Ten ", "years [1]."])
        self.assertTrue(seen[0]["stream"])


class VertexEmbedderTests(unittest.TestCase):
    def test_not_configured_without_embed_model(self):
        self.assertFalse(VertexEmbedder(_settings()).configured)
        self.assertTrue(VertexEmbedder(_settings(
            vertex_embed_model="text-embedding-005")).configured)

    def test_request_shape_and_batching(self):
        seen = []

        def fake(req, timeout=None, **kw):
            seen.append((req.full_url, json.loads(req.data.decode())))
            return _embed_response(len(seen[-1][1]["instances"]))
        e = VertexEmbedder(_settings(vertex_embed_model="text-embedding-005"))
        with mock.patch("urllib.request.urlopen", fake):
            vecs = e.embed([f"t{i}" for i in range(20)],
                           "RETRIEVAL_DOCUMENT", title="Doc")
        self.assertEqual(len(vecs), 20)
        self.assertEqual([len(b["instances"]) for _, b in seen], [16, 4])
        self.assertTrue(seen[0][0].endswith(
            "/publishers/google/models/text-embedding-005:predict"))
        self.assertEqual(seen[0][1]["instances"][0], {
            "content": "t0", "task_type": "RETRIEVAL_DOCUMENT",
            "title": "Doc"})

    def test_gemini_embedding_sends_one_text_per_request(self):
        sizes = []

        def fake(req, timeout=None, **kw):
            sizes.append(len(json.loads(req.data.decode())["instances"]))
            return _embed_response(1)
        e = VertexEmbedder(_settings(vertex_embed_model="gemini-embedding-001"))
        with mock.patch("urllib.request.urlopen", fake):
            e.embed(["a", "b", "c"], "RETRIEVAL_QUERY")
        self.assertEqual(sizes, [1, 1, 1])


if __name__ == "__main__":
    unittest.main()
