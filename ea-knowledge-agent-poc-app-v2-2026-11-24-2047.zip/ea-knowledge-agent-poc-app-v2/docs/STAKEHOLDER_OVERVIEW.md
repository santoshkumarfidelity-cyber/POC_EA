# EA Knowledge Agent POC: How It Works

*A short guide for stakeholders: where the data comes from, what is stored, how a question is answered, and where AI is used. All content in the POC is synthetic (the fictional "Harborline Insurance Group").*

---

## 1. In one paragraph

The EA Knowledge Agent answers questions about Enterprise Architecture content such as standards, strategies, roadmaps and guidelines. It reads documents from SharePoint or a folder, keeps only **approved, current** versions searchable, and answers each question **only from documents the user is allowed to see**. Every answer comes with links to its source documents. If the documents don't support an answer, the agent says so instead of guessing.

---

## 2. The big picture

```mermaid
flowchart LR
    SP["SharePoint<br/>or a local folder"] -->|1. Sync| ING["Ingestion<br/>read text, version, tag"]
    ING --> DB[("Knowledge database<br/>(SQLite)")]
    ING -.->|2. Text chunks| EMB["Vertex AI<br/>Embeddings"]
    EMB -.->|vectors| DB
    U["User in browser"] -->|3. Question| APP["Knowledge Agent"]
    APP -->|4. Permission-filtered search| DB
    APP -->|5. Question + best passages| LLM["Vertex AI<br/>Gemini"]
    LLM -->|6. Draft answer| APP
    APP -->|7. Answer + source links| U
```

There are two flows:

| Flow | When it runs | What it does |
|---|---|---|
| **Sync** (steps 1–2) | When an operator runs it | Brings documents into the database and prepares them for search |
| **Ask** (steps 3–7) | Every time a user asks a question | Finds the right documents and writes a cited answer |

---

## 3. Flow 1: Getting documents in (Sync)

```mermaid
flowchart TD
    A["Read each file<br/>Word, PowerPoint, Excel, PDF, text, images"] --> B{"Supported type and<br/>under the size limit?"}
    B -->|No| S["Skip and report why"]
    B -->|Yes| C["Extract the text"]
    C --> D{"Seen this file before?"}
    D -->|New| E["Save as version 1.0, APPROVED"]
    D -->|Same content| F["No change"]
    D -->|Content changed| G["Save as new version<br/>older one becomes SUPERSEDED"]
    E --> H["Add tags and access groups"]
    G --> H
    H --> I["Split text into passages<br/>and create vectors (Vertex AI)"]
    J["File removed from source"] --> K["Mark as ARCHIVED<br/>(no longer searchable)"]
```

**Key points**

- **Change detection.** Each file gets a fingerprint (a hash of its bytes). If the fingerprint changes, a new version is saved, and the previous version stays in the history.
- **Version history.** Up to 5 versions per document are kept, so users can see older versions and what changed between them.
- **Access groups.** Each document is tagged with the groups allowed to read it (for example `EA_ALL`, `EA_INSURANCE`).
- **Safe by default.**
  - Files over 200 MB are skipped.
  - A sync that partly fails, or points at a missing or empty folder, never archives anything.

---

## 4. What the database stores

The database is one file (`data/poc.db`). The main tables, in plain terms:

| Table | What it holds | Example |
|---|---|---|
| **artifact_families** | One row per document, the same across all its versions | "Data Retention Guidelines", owner, domain, audience |
| **artifact_versions** | One row per version, including its full extracted text | v2.0, APPROVED, current = yes, uploaded 2026-11-03 |
| **artifact_acl_groups** | Which groups may read each version | v2.0 → `EA_ALL`, `EA_INSURANCE` |
| **artifact_tags** | Searchable tags | `RETENTION`, `DATA`, `SYNCED` |
| **artifact_chunks** | Passages of about 900 characters, each with its vector (a list of numbers that captures meaning) | Chunk 3: "Claims records: 10 years after…" + 768 numbers |
| **artifact_fts** | Full-text index, kept up to date but not yet used for search (reserved for faster search at larger scale) | — |
| **lifecycle_events** | History of status changes | DRAFT → REVIEW → APPROVED, by whom, when |
| **conversations** | The latest question and status per chat | Used to continue a conversation |
| **audit_events** | Who asked, which answer status, which sources were cited | Stores a **fingerprint of the question, not the question text** |

```mermaid
erDiagram
    artifact_families ||--o{ artifact_versions : "has versions"
    artifact_versions ||--o{ artifact_acl_groups : "readable by"
    artifact_versions ||--o{ artifact_tags : "tagged"
    artifact_versions ||--o{ artifact_chunks : "split into"
    artifact_versions ||--o{ lifecycle_events : "status history"
```

**Document lifecycle**

```mermaid
stateDiagram-v2
    [*] --> DRAFT
    DRAFT --> REVIEW
    REVIEW --> APPROVED
    APPROVED --> SUPERSEDED: newer version approved
    APPROVED --> ARCHIVED: removed from source
```

Only **APPROVED and current** versions are used to answer questions.

---

## 5. Flow 2: Answering a question (Ask)

```mermaid
sequenceDiagram
    actor User
    participant App as Knowledge Agent
    participant DB as Database
    participant VX as Vertex AI
    User->>App: "When can old paperwork be thrown away?"
    App->>DB: 1. Get approved, current documents this user may see
    DB-->>App: Candidate documents (e.g. 14)
    App->>VX: 2. Turn the question into a vector
    VX-->>App: Question vector
    App->>App: 3. Score each document (keywords + meaning)
    App->>App: 4. Keep the top 4, drop weak or unsafe ones
    App->>VX: 5. Question + best passages (never whole documents)
    VX-->>App: Draft answer with [1], [2] markers
    App->>App: 6. Check the answer cites a source, or abstain
    App->>DB: 7. Save audit record and conversation
    App-->>User: Answer with links to the source documents
```

### Step 1: The permission check comes first

Before any searching or AI, the database returns only what this user is allowed to see. This is the actual query:

```sql
SELECT ...
FROM artifact_versions v
JOIN artifact_families f ON f.id = v.family_id
WHERE v.is_current_approved = 1
  AND v.lifecycle_status = 'APPROVED'
  AND v.id IN (SELECT version_id FROM artifact_acl_groups
               WHERE grp IN ('EA_ALL', 'EA_INSURANCE'))   -- the user's groups
```

Documents the user can't see never reach the scoring step or the AI, so they can't leak into an answer.

### Step 2–3: Finding the best documents (hybrid search)

Each candidate document gets a score from two kinds of search:

| | Keyword search | Vector (meaning) search |
|---|---|---|
| **How it matches** | Exact shared words | Similar meaning, even with different words |
| **Example** | "claims records" matches "Claims records" | "throw away old paperwork" matches "retention periods… deleted" |
| **Powered by** | The app itself | Vertex AI embeddings |

**How the score is built**

| Part | Points |
|---|---|
| Question words found in the document | +1 each |
| …in the title | +2 each |
| …in the tags | +1.5 each |
| Best-matching passage | up to +3 |
| Similarity in meaning | up to +6 |
| Current approved version | +1 |

A document needs at least **2.0** points to be used. The top 4 are kept.

If vector search isn't configured or Vertex AI is unavailable, the agent continues with keyword search only.

### Step 4: Filters before the AI sees anything

- **Unsafe content.** Documents containing instructions aimed at the AI ("ignore previous instructions…") are removed.
- **Weak matches.** Documents scoring under 35% of the best match are dropped.

### Step 5: Writing the answer

- Gemini (Vertex AI) receives the question plus the **best passages** of each selected document, up to about 16,000 characters in total. It never receives whole documents or documents the user can't see.
- It is instructed to:
  - answer the real question in its own words
  - use only these sources and cite each fact
  - say what's missing rather than guess
- If Vertex AI isn't available, Claude can be used instead. If neither is available, a built-in summary picks the most relevant paragraph.

### Step 6: Grounding check

- An answer without at least one cited source isn't shown. The agent replies that it can't give a defensible answer.
- In the browser, citation markers such as [1] become **links named after the document**. Clicking one opens the document, its versions, and the original file.

---

## 6. Where AI is used, and what it receives

| AI service | Used for | What is sent | What comes back |
|---|---|---|---|
| **Vertex AI embeddings** (e.g. `text-embedding-005`) | Understanding meaning | Document passages (during sync) and the question (during Ask) | Vectors, lists of numbers |
| **Vertex AI Gemini** | Writing the answer | The question and at most 4 documents' best passages | Answer text with citation markers |
| **Claude** (optional) | Backup answer writer | Same as Gemini | Same as Gemini |

- **Authentication.** It uses a Google access token from the developer's `gcloud` login or `.env`. Tokens are never logged or sent to the browser.
- **Transport.** All calls use HTTPS with full certificate verification.

---

## 7. Controls and safeguards

| Area | Control |
|---|---|
| **Access** | Permission filter in the database query, before search and AI |
| **Content quality** | Only APPROVED, current versions answer questions; drafts and old versions don't |
| **Accuracy** | Answers must cite sources; otherwise the agent abstains |
| **Prompt injection** | Document text is treated as data, and suspicious documents are removed |
| **Privacy** | The audit log stores a fingerprint of the question, not its text |
| **Secrets** | `.env` holds credentials and is never shared or committed |
| **Troubleshooting** | An optional debug log (`logs/retrieval_debug.log`), off by default, records each step of a search: the SQL, the scores, and why documents were left out |

---

## 8. Worked example

**Question (Consumer persona):** *"When can old paperwork be thrown away?"*

1. **Permission check:** 14 documents are visible to the `EA_ALL` and `EA_INSURANCE` groups.
2. **Keyword search:** no document shares a word with the question.
3. **Vector search:** *Data Retention Guidelines* is close in meaning, so it is kept.
4. **Gemini** reads its best passages and answers along these lines: *"Policy records can be deleted 7 years after the policy ends, and claims records 10 years after the claim closes… (Data Retention Guidelines)."*
5. **The user** clicks *Data Retention Guidelines* to open the source.
6. **Audit** records the user, the status (grounded) and the cited document ID.

---

## 9. Current POC limits and the path to production

| Today (POC) | Production direction |
|---|---|
| SQLite file on one machine | Cloud SQL or AlloyDB (PostgreSQL) with `pgvector` on GCP |
| Vectors compared one by one (fine for thousands of passages) | Indexed vector search (pgvector, or Vertex AI Vector Search) |
| Demo personas instead of real sign-in | Microsoft Entra ID sign-in and real group membership |
| Sync run by hand | Scheduled or change-triggered SharePoint sync |
| Keyword scoring treats common words equally | Weight rare words higher; tune the similarity threshold on real content |
| Synthetic content only | Real content after security and data-residency approval |

---

## 10. Glossary

| Term | Meaning |
|---|---|
| **Passage / chunk** | A piece of a document, about 900 characters long |
| **Vector / embedding** | A list of numbers that represents the meaning of a text; similar meanings give similar numbers |
| **Similarity** | How close two meanings are, from 0 (unrelated) to 1 (identical) |
| **Hybrid search** | Keyword search and vector search combined into one score |
| **Grounded answer** | An answer supported by, and citing, approved source documents |
| **Abstain** | The agent declines to answer because the sources don't support one |
| **ACL group** | An access group that decides who can read a document |
| **Persona** | A demo user role (Consumer, Contributor, Owner, Approver, Curator, Admin) |
