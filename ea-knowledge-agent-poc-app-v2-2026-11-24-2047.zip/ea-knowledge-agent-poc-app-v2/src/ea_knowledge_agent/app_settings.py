"""v2 POC: settings an admin changes in the app, kept in `app_settings`.
Until an admin changes one, the value from .env / Settings applies."""

from .config import load_settings

DISCOVER_FOR_EVERYONE = "discover_for_everyone"


def discover_for_everyone(conn) -> bool:
    row = conn.execute("SELECT value FROM app_settings WHERE key=?",
                       (DISCOVER_FOR_EVERYONE,)).fetchone()
    return load_settings().discover_for_everyone if row is None \
        else row[0] == "1"


def set_discover_for_everyone(conn, on: bool) -> None:
    conn.execute(
        "INSERT INTO app_settings (key, value) VALUES (?, ?) "
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (DISCOVER_FOR_EVERYONE, "1" if on else "0"))
    conn.commit()
