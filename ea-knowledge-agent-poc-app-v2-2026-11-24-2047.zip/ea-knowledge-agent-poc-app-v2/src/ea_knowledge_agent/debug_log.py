"""Retrieval debug log: one timestamped line per event, all lines of one
question sharing a request id, written to logs/retrieval_debug.log.

Off unless RETRIEVAL_DEBUG=1. It records the raw question, persona, SQL,
scores and LLM status so a test run can be explained after the fact; it
never records document text, passages or credentials. Line format:

  2026-11-09T10:15:02.123Z | req=3f9a1c2b7d4e | sql | {"statement": ...}
"""

import json
import logging
import logging.handlers
import os
import threading
import uuid
from datetime import datetime, timezone

from .config import app_path, load_settings

_LOGGER = logging.getLogger("ea_knowledge_agent.retrieval_debug")
_LOGGER.propagate = False          # never mixed into the server console
_lock = threading.Lock()
_open_path: str | None = None


def _logger_for(path: str) -> logging.Logger:
    global _open_path
    with _lock:
        if _open_path != path:
            for h in list(_LOGGER.handlers):
                _LOGGER.removeHandler(h)
                h.close()
            os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
            handler = logging.handlers.RotatingFileHandler(
                path, maxBytes=5 * 1024 * 1024, backupCount=3,
                encoding="utf-8")
            handler.setFormatter(logging.Formatter("%(message)s"))
            _LOGGER.addHandler(handler)
            _LOGGER.setLevel(logging.INFO)
            _open_path = path
    return _LOGGER


class Trace:
    """Collects the debug events of one request. Disabled traces do
    nothing, so callers never need to check."""

    def __init__(self, enabled: bool, path: str = ""):
        self.enabled = enabled
        self.request_id = uuid.uuid4().hex[:12]
        self._log = _logger_for(path) if enabled else None

    @classmethod
    def start(cls) -> "Trace":
        s = load_settings()
        return cls(s.retrieval_debug, app_path(s.retrieval_debug_log))

    def event(self, name: str, **fields) -> None:
        if not self.enabled:
            return
        ts = datetime.now(timezone.utc).isoformat(
            timespec="milliseconds").replace("+00:00", "Z")
        self._log.info("%s | req=%s | %s | %s", ts, self.request_id, name,
                       json.dumps(fields, ensure_ascii=False, default=str))


NO_TRACE = Trace(False)
