"""v2: Microsoft Entra ID sign-in (OpenID Connect, authorization code flow
with PKCE), used when AUTH_MODE=entra.

Flow: /auth/login stores a one-time state, nonce and PKCE verifier and
sends the browser to Microsoft; /auth/callback checks the state (also held
in a short-lived browser cookie, against login CSRF), exchanges the code
at Microsoft's token endpoint, checks the ID token and opens a session.

The ID token is received directly from the token endpoint over verified
HTTPS, so its claims are checked (issuer, audience, tenant, expiry, nonce)
instead of its signature, as OpenID Connect Core 3.1.3.7 allows. Tokens
are never stored or logged: the app keeps only the user's id, name,
sign-in name and mapped app groups, and stores sessions by the SHA-256 of
the cookie value. SSL verification is never turned off.

Access: the user's Entra group object IDs (and app role values) are
mapped to app groups with ENTRA_GROUP_MAP; ENTRA_DEFAULT_GROUPS are added
for everyone. A user with no app group is refused. EA_ADMINS makes the
user an admin (Discover settings)."""

import base64
import hashlib
import json
import re
import secrets
import time
import urllib.error
import urllib.parse
import urllib.request

from .config import load_settings
from .models import Persona
from .vertex_client import _ssl_context

LOGIN_HOST = "https://login.microsoftonline.com"
SESSION_COOKIE = "ea_session"
STATE_COOKIE = "ea_login"
ADMIN_GROUP = "EA_ADMINS"
_GUID = re.compile(r"[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}")
_PENDING_SECONDS = 600       # a sign-in must finish within 10 minutes
_CLOCK_SKEW = 120
_TIMEOUT = 15


class SignInError(Exception):
    """A sign-in problem with a message that is safe to show the user."""


def _b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()


def _b64url_decode(text: str) -> bytes:
    return base64.urlsafe_b64decode(text + "=" * (-len(text) % 4))


def _hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


class EntraAuth:
    def __init__(self, settings=None):
        self.s = settings or load_settings()

    @property
    def enabled(self) -> bool:
        return self.s.auth_mode == "entra"

    def problem(self) -> str:
        """Why sign-in can't work yet ('' when it can)."""
        s = self.s
        missing = [n for n, v in (("ENTRA_TENANT_ID", s.entra_tenant_id),
                                  ("ENTRA_CLIENT_ID", s.entra_client_id),
                                  ("ENTRA_CLIENT_SECRET",
                                   s.entra_client_secret)) if not v]
        if missing:
            return ("Entra sign-in is not configured: set "
                    + ", ".join(missing) + " in .env (or the GRAPH_ ones).")
        if not _GUID.fullmatch(s.entra_tenant_id):
            return ("ENTRA_TENANT_ID must be the tenant ID (a GUID, from "
                    "Entra admin center > Overview), not a domain name.")
        if not (s.entra_group_map or s.entra_default_groups):
            return ("No Entra group gives access: set ENTRA_GROUP_MAP "
                    "(and/or ENTRA_DEFAULT_GROUPS) in .env.")
        return ""

    def redirect_uri(self, host_header: str) -> str:
        """ENTRA_REDIRECT_URI, or http://<this host>/auth/callback when the
        app is opened on localhost (Entra allows http only there)."""
        if self.s.entra_redirect_uri:
            return self.s.entra_redirect_uri
        host = (host_header or "").strip()
        name = host.rsplit(":", 1)[0] if host.count(":") == 1 else host
        if name != "localhost":
            raise SignInError("Open the app at http://localhost:<port> to "
                              "sign in, or set ENTRA_REDIRECT_URI.")
        return f"http://{host}/auth/callback"

    # --------------------------------------------------------- sign-in
    def start(self, conn, redirect_uri: str) -> tuple[str, str]:
        """Returns (Microsoft sign-in URL, state for the browser cookie)."""
        if self.problem():
            raise SignInError(self.problem())
        state, nonce = secrets.token_urlsafe(32), secrets.token_urlsafe(32)
        verifier = secrets.token_urlsafe(64)
        challenge = _b64url(hashlib.sha256(verifier.encode()).digest())
        now = time.time()
        conn.execute("DELETE FROM auth_pending WHERE created_at < ?",
                     (now - _PENDING_SECONDS,))
        conn.execute("INSERT INTO auth_pending (state, nonce, verifier, "
                     "redirect_uri, created_at) VALUES (?,?,?,?,?)",
                     (state, nonce, verifier, redirect_uri, now))
        conn.commit()
        query = urllib.parse.urlencode({
            "client_id": self.s.entra_client_id,
            "response_type": "code",
            "redirect_uri": redirect_uri,
            "response_mode": "query",
            "scope": "openid profile email",
            "state": state, "nonce": nonce,
            "code_challenge": challenge, "code_challenge_method": "S256",
        })
        return (f"{LOGIN_HOST}/{self.s.entra_tenant_id}/oauth2/v2.0/"
                f"authorize?{query}", state)

    def finish(self, conn, params: dict, browser_state: str) -> str:
        """Handles Microsoft's redirect back; returns the new session's
        cookie value. Raises SignInError with a user-safe message."""
        if params.get("error"):
            desc = (params.get("error_description") or "")[:300]
            raise SignInError(f"Microsoft sign-in failed: "
                              f"{params['error']}. {desc}".strip())
        state, code = params.get("state", ""), params.get("code", "")
        row = conn.execute("SELECT nonce, verifier, redirect_uri, "
                           "created_at FROM auth_pending WHERE state=?",
                           (state,)).fetchone() if state else None
        if row:      # single use
            conn.execute("DELETE FROM auth_pending WHERE state=?", (state,))
            conn.commit()
        if not row or not code or not secrets.compare_digest(
                state, browser_state or "") or \
                time.time() - row[3] > _PENDING_SECONDS:
            raise SignInError("The sign-in expired or didn't start here. "
                              "Please sign in again.")
        tokens = self._redeem(code, row[1], row[2])
        claims = self.check_id_token(tokens.get("id_token", ""), row[0])
        groups = self.map_groups(claims)
        who = claims.get("preferred_username") or claims.get("email") or ""
        if not groups:
            raise SignInError(f"You are signed in as {who}, but you are not "
                              "in an Entra group that has access to this "
                              "app. Ask the POC admin to add you.")
        return Sessions(conn, self.s).create(
            claims["oid"], claims.get("name") or who, who, groups)

    def _redeem(self, code: str, verifier: str, redirect_uri: str) -> dict:
        body = urllib.parse.urlencode({
            "client_id": self.s.entra_client_id,
            "client_secret": self.s.entra_client_secret,
            "grant_type": "authorization_code", "code": code,
            "redirect_uri": redirect_uri, "code_verifier": verifier,
            "scope": "openid profile email",
        }).encode()
        req = urllib.request.Request(
            f"{LOGIN_HOST}/{self.s.entra_tenant_id}/oauth2/v2.0/token",
            data=body, method="POST",
            headers={"Content-Type": "application/x-www-form-urlencoded"})
        ctx = _ssl_context()
        try:
            with urllib.request.urlopen(req, timeout=_TIMEOUT,
                                        **({"context": ctx} if ctx else {})
                                        ) as resp:
                return json.loads(resp.read().decode())
        except urllib.error.HTTPError as exc:
            try:     # Microsoft's AADSTS code and text, never the secret
                err = json.loads(exc.read().decode())
                detail = (err.get("error_description") or "").split(
                    "\r\n")[0][:300]
            except Exception:
                detail = ""
            raise SignInError(f"Microsoft refused the sign-in "
                              f"(HTTP {exc.code}). {detail}") from exc
        except (urllib.error.URLError, OSError, ValueError) as exc:
            raise SignInError("Could not reach Microsoft to finish the "
                              "sign-in. Check the network or proxy.") from exc

    def check_id_token(self, id_token: str, nonce: str) -> dict:
        try:
            claims = json.loads(_b64url_decode(id_token.split(".")[1]))
        except Exception as exc:
            raise SignInError("Microsoft returned an unreadable ID "
                              "token.") from exc
        tenant, now = self.s.entra_tenant_id.lower(), time.time()
        checks = (
            (str(claims.get("iss", "")).lower()
             == f"{LOGIN_HOST}/{tenant}/v2.0", "issuer"),
            (claims.get("aud") == self.s.entra_client_id, "audience"),
            (str(claims.get("tid", "")).lower() == tenant, "tenant"),
            (float(claims.get("exp", 0)) > now - _CLOCK_SKEW, "expiry"),
            (float(claims.get("nbf", 0)) < now + _CLOCK_SKEW, "not-before"),
            (secrets.compare_digest(str(claims.get("nonce", "")), nonce),
             "nonce"),
            (bool(claims.get("oid")), "user id"),
        )
        bad = [what for ok, what in checks if not ok]
        if bad:
            raise SignInError("The ID token failed its checks ("
                              + ", ".join(bad) + "). Please sign in again.")
        if "groups" not in claims and "groups" in (
                claims.get("_claim_names") or {}):
            raise SignInError("You are in too many groups for Entra to list "
                              "them in the sign-in. In the app "
                              "registration's Token configuration, emit "
                              "only 'Groups assigned to the application', "
                              "or use app roles.")
        return claims

    def map_groups(self, claims: dict) -> list[str]:
        keys = {str(k).lower() for k in (claims.get("groups") or [])} | \
               {str(k).lower() for k in (claims.get("roles") or [])}
        out = list(self.s.entra_default_groups)
        out += [app for key, app in self.s.entra_group_map
                if key.lower() in keys]
        return list(dict.fromkeys(out))           # dedupe, keep order


class Sessions:
    def __init__(self, conn, settings=None):
        self.conn = conn
        self.s = settings or load_settings()

    def create(self, user_id, name, username, groups) -> str:
        token, now = secrets.token_urlsafe(32), time.time()
        self.conn.execute("DELETE FROM auth_sessions WHERE expires_at < ?",
                          (now,))
        self.conn.execute(
            "INSERT INTO auth_sessions (id_hash, user_id, name, username, "
            "groups_json, created_at, expires_at) VALUES (?,?,?,?,?,?,?)",
            (_hash(token), user_id, name, username, json.dumps(groups), now,
             now + max(self.s.session_hours, 1) * 3600))
        self.conn.commit()
        return token

    def get(self, token: str) -> dict | None:
        if not token:
            return None
        row = self.conn.execute(
            "SELECT user_id, name, username, groups_json FROM auth_sessions "
            "WHERE id_hash=? AND expires_at > ?",
            (_hash(token), time.time())).fetchone()
        if not row:
            return None
        return {"user_id": row[0], "name": row[1], "username": row[2],
                "groups": json.loads(row[3])}

    def delete(self, token: str) -> None:
        if token:
            self.conn.execute("DELETE FROM auth_sessions WHERE id_hash=?",
                              (_hash(token),))
            self.conn.commit()


def user_persona(user: dict) -> Persona:
    """The signed-in user as the app's Persona. Its id keys the user's own
    chats; its groups decide which documents they may see."""
    admin = ADMIN_GROUP in user["groups"]
    return Persona(id=f"entra:{user['user_id']}",
                   display_name=user["name"] or user["username"],
                   role="Administrator" if admin else "Signed-in user",
                   groups=tuple(user["groups"]))
