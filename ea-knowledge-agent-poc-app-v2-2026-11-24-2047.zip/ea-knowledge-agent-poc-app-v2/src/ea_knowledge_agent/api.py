"""HTTP API + static hosting via http.server. JSON errors are always
{error: {code, message}}; API responses are no-store; static pages get
basic CSP headers; directory traversal is rejected."""

import base64
import hashlib
import html
import io
import json
import mimetypes
import os
import posixpath
import re
import shutil
import subprocess
import sys
import urllib.parse
import zipfile
from http.cookies import CookieError, SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from .agent import KnowledgeAgent
from .app_settings import discover_for_everyone, set_discover_for_everyone
from .chats import ChatStore
from .auth import can_curate, get_persona, list_personas
from .claude_client import ClaudeClient
from .config import load_settings
from .entra import ADMIN_GROUP, SESSION_COOKIE, STATE_COOKIE, EntraAuth, \
    Sessions, SignInError, user_persona
from .database import connect, initialize
from .file_extraction import extract_text
from .ingest import CONTRIBUTOR, SUPPORTED, local_path
from .repository import KnowledgeRepository
from .seed import seed_if_empty
from .sharepoint_connector import SharePointConnector
from .vertex_client import VertexClient

_STATIC = {"/": "index.html", "/index.html": "index.html",
           "/styles.css": "styles.css", "/app.js": "app.js"}
_MIME = {".html": "text/html; charset=utf-8", ".css": "text/css",
         ".js": "text/javascript"}


class ApiError(Exception):
    def __init__(self, code: str, message: str, status: int = 400):
        super().__init__(message)
        self.code, self.message, self.status = code, message, status


def _safe_name(text: str) -> str:
    """A file name that is safe on Windows and in a header."""
    name = re.sub(r"[^A-Za-z0-9._ -]+", "_", text or "").strip(" ._")
    return name[:80] or "document"


def _unique(name: str, used: set) -> str:
    base, ext = os.path.splitext(name)
    out, n = name, 2
    while out.lower() in used:
        out, n = f"{base} ({n}){ext}", n + 1
    used.add(out.lower())
    return out


def _answer_json(answer) -> dict:
    return {"answer": answer.answer, "status": answer.status,
            "provider": answer.provider,
            "conversation_id": answer.conversation_id,
            "title": answer.title, "audit_id": answer.audit_id,
            "duration_ms": answer.duration_ms,
            "message_id": answer.message_id,
            "source_count": answer.source_count,
            "citations": [c.__dict__ for c in answer.citations]}


def make_handler(db_path: str, web_dir: str):
    class Handler(BaseHTTPRequestHandler):
        server_version = "EAKnowledgePOC/0.2"

        # -------------------------------------------------- plumbing
        def log_message(self, *a):  # quiet but keep errors
            pass

        def _send_json(self, obj, status=200):
            body = json.dumps(obj, default=str).encode()
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def _send_error(self, status, code, message):
            self._send_json({"error": {"code": code, "message": message}},
                            status)

        def _persona(self, params):
            if self._user:              # Entra sign-in: never the browser's
                return self._user
            pid = params.get("persona", ["consumer"])[0]
            if load_settings().phase < 2:
                pid = "consumer"  # Phase 1: internal viewer only
            try:
                return get_persona(pid)
            except ValueError:
                raise ApiError("bad_persona", "unknown persona", 400)

        def _admin_view(self) -> bool:
            """With Entra sign-in: the user is in EA_ADMINS. Demo mode
            (POC only): the User/Admin switch sends X-POC-View: admin."""
            if self._user:
                return ADMIN_GROUP in self._user.groups
            if EntraAuth().enabled:
                return False
            return self.headers.get("X-POC-View", "").lower() == "admin"

        def _require_discover(self, conn):
            """Phase 1: Discover is admin-only unless an admin opened it
            to everyone. (Phase 2 keeps its persona rules.)"""
            if load_settings().phase < 2 and not self._admin_view() and \
                    not discover_for_everyone(conn):
                raise ApiError("admin_only",
                               "Discover is available to admins only", 403)

        def _require_phase(self, phase):
            if EntraAuth().enabled:
                # Phase-2 screens still take the persona from the browser,
                # so they stay off with real sign-in in this POC.
                raise ApiError("not_available", "not available with Entra "
                               "sign-in in this POC", 404)
            if load_settings().phase < phase:
                raise ApiError("not_available",
                               f"not available until phase {phase}", 404)

        # --------------------------------------- v2: Entra ID sign-in
        _user = None     # the signed-in user's Persona (AUTH_MODE=entra)

        def _cookie(self, name: str) -> str:
            jar = SimpleCookie()
            try:
                jar.load(self.headers.get("Cookie", ""))
            except CookieError:
                return ""
            return jar[name].value if name in jar else ""

        def _signed_in(self, path: str):
            """The signed-in user's Persona; None in demo mode. With
            AUTH_MODE=entra every API call except /api/health needs a
            valid session (401 signed_out otherwise)."""
            if not EntraAuth().enabled or path == "/api/health":
                return None
            conn = connect(db_path)
            try:
                user = Sessions(conn).get(self._cookie(SESSION_COOKIE))
            finally:
                conn.close()
            if not user:
                raise ApiError("signed_out", "please sign in", 401)
            return user_persona(user)

        def _same_origin(self):
            """Refuse POSTs sent from another site's page (CSRF)."""
            origin = self.headers.get("Origin")
            if origin and urllib.parse.urlparse(origin).netloc != \
                    self.headers.get("Host", ""):
                raise ApiError("forbidden", "cross-site request refused", 403)

        def _set_cookie(self, name, value, max_age, path="/"):
            secure = "; Secure" if EntraAuth().s.entra_redirect_uri \
                .startswith("https:") else ""
            self.send_header("Set-Cookie", f"{name}={value}; Path={path}; "
                             f"Max-Age={max_age}; HttpOnly; SameSite=Lax"
                             f"{secure}")

        def _redirect(self, location, cookies=()):
            self.send_response(302)
            self.send_header("Location", location)
            self.send_header("Cache-Control", "no-store")
            for c in cookies:
                self._set_cookie(*c)
            self.send_header("Content-Length", "0")
            self.end_headers()

        def _message_page(self, status, title, text, signed_out=False):
            """A small HTML page for sign-in problems and sign-out."""
            body = (f"<!DOCTYPE html><meta charset='utf-8'><title>"
                    f"{html.escape(title)}</title><body style='font-family:"
                    f"system-ui;max-width:640px;margin:60px auto;padding:0 "
                    f"16px'><h1>{html.escape(title)}</h1><p>"
                    f"{html.escape(text)}</p><p><a href='/auth/login'>Sign "
                    f"in again</a></p></body>").encode()
            self.send_response(status)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            if signed_out:
                self._set_cookie(SESSION_COOKIE, "", 0)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def _auth_route(self, path, params):
            auth = EntraAuth()
            if not auth.enabled:            # demo mode: no sign-in
                return self._redirect("/")
            one = {k: v[0] for k, v in params.items()}
            conn = connect(db_path)
            try:
                if path == "/auth/login":
                    url, state = auth.start(
                        conn, auth.redirect_uri(self.headers.get("Host")))
                    return self._redirect(url, [(STATE_COOKIE, state, 600,
                                                 "/auth")])
                if path == "/auth/callback":
                    token = auth.finish(conn, one, self._cookie(STATE_COOKIE))
                    return self._redirect("/", [
                        (SESSION_COOKIE, token,
                         max(auth.s.session_hours, 1) * 3600),
                        (STATE_COOKIE, "", 0, "/auth")])
                if path == "/auth/logout":
                    Sessions(conn).delete(self._cookie(SESSION_COOKIE))
                    return self._message_page(
                        200, "Signed out", "You are signed out of the EA "
                        "Knowledge Agent. Close the browser to end your "
                        "Microsoft session too.", signed_out=True)
                return self._send_error(404, "not_found", "not found")
            except SignInError as e:
                return self._message_page(403, "Sign-in problem", str(e))
            finally:
                conn.close()

        def _repo(self):
            conn = connect(db_path)
            return KnowledgeRepository(conn), conn

        def _body(self):
            n = int(self.headers.get("Content-Length", 0) or 0)
            if n > 5 * 1024 * 1024:
                raise ApiError("too_large", "body exceeds 5MB", 413)
            raw = self.rfile.read(n) if n else b"{}"
            try:
                return json.loads(raw.decode("utf-8"))
            except (ValueError, UnicodeDecodeError):
                raise ApiError("bad_json", "request body must be JSON", 400)

        # -------------------------------------------------- routes
        def do_GET(self):
            parsed = urllib.parse.urlparse(self.path)
            params = urllib.parse.parse_qs(parsed.query)
            path = posixpath.normpath(urllib.parse.unquote(parsed.path))
            try:
                if path.startswith("/auth/"):
                    return self._auth_route(path, params)
                if path.startswith("/api/"):
                    self._user = self._signed_in(path)
                    return self._api_get(path, params)
                return self._static(path)
            except ApiError as e:
                return self._send_error(e.status, e.code, e.message)
            except PermissionError as e:
                return self._send_error(403, "forbidden", str(e))
            except Exception:
                return self._send_error(500, "internal",
                                        "unexpected server error")

        def _api_get(self, path, params):
            repo, conn = self._repo()
            try:
                if path == "/api/health":
                    return self._send_json({"status": "ok"})
                if path == "/api/me":           # v2: who is signed in
                    if not self._user:
                        return self._send_json({"auth_mode": "demo"})
                    u = self._user
                    return self._send_json({
                        "auth_mode": "entra", "name": u.display_name,
                        "role": u.role, "admin": self._admin_view()})
                if path == "/api/personas":
                    if self._user:
                        return self._send_json({"personas": [{
                            "id": self._user.id,
                            "display_name": self._user.display_name,
                            "role": self._user.role,
                            "groups": list(self._user.groups)}]})
                    if load_settings().phase < 2:
                        # Phase 1: a single internal viewer, approved
                        # current content only.
                        v = get_persona("consumer")
                        return self._send_json({"personas": [
                            {"id": v.id, "display_name": "Internal Viewer",
                             "role": "Internal Viewer",
                             "groups": list(v.groups)}]})
                    return self._send_json({"personas": [
                        {"id": p.id, "display_name": p.display_name,
                         "role": p.role, "groups": list(p.groups)}
                        for p in list_personas()]})
                if path == "/api/integrations":
                    return self._send_json({
                        "phase": load_settings().phase,
                        "claude_configured": ClaudeClient().configured,
                        "vertex_configured": VertexClient().configured,
                        "llm_model": (VertexClient().model
                                      if VertexClient().configured else ""),
                        "sharepoint_configured":
                            SharePointConnector().configured,
                        "mode": "llm" if (VertexClient().configured
                                          or ClaudeClient().configured)
                                else "local synthesis"})
                if path == "/api/app-settings":   # v2 POC admin settings
                    return self._send_json({
                        "admin_view": self._admin_view(),
                        "discover_for_everyone":
                            discover_for_everyone(conn)})
                if path == "/api/chats":       # v2: history sidebar
                    persona = self._persona(params)
                    if ChatStore(conn).purge(
                            load_settings().chat_retention_days):
                        conn.commit()
                    return self._send_json(
                        {"chats": ChatStore(conn).list_chats(persona.id)})
                if path.startswith("/api/chats/") and \
                        path.endswith("/sources.zip"):   # v2: all sources
                    parts = path.split("/")
                    persona = self._persona(params)
                    store = ChatStore(conn)
                    chat = store.get(persona.id, parts[3]) \
                        if len(parts) == 7 and parts[4] == "messages" else None
                    ids = store.source_ids(chat["id"], parts[5]) \
                        if chat else None
                    if not ids:
                        raise ApiError("not_found",
                                       "no sources for this answer", 404)
                    return self._send_sources_zip(repo, persona, ids,
                                                  chat["title"])
                if path.startswith("/api/chats/"):
                    persona = self._persona(params)
                    store = ChatStore(conn)
                    chat = store.get(persona.id, path.split("/")[3])
                    if not chat:
                        raise ApiError("not_found", "chat not found", 404)
                    return self._send_json(
                        {"chat": chat, "messages": store.messages(chat["id"])})
                if path == "/api/artifacts":
                    self._require_discover(conn)
                    persona = self._persona(params)
                    items = repo.list_artifacts(
                        persona,
                        query=params.get("query", [""])[0],
                        tags=tuple(t for t in params.get("tags", [""])[0]
                                   .split(",") if t),
                        status=params.get("status", [""])[0],
                        audience=params.get("audience", [""])[0],
                        sort=params.get("sort", ["uploaded_desc"])[0])
                    return self._send_json({"artifacts": items})
                if path == "/api/tags":
                    self._require_discover(conn)
                    persona = self._persona(params)
                    return self._send_json({"tags": repo.list_tags(persona)})
                if path == "/api/reports/quality":
                    self._require_phase(2)
                    persona = self._persona(params)
                    return self._send_json(repo.quality_report(persona))
                if path == "/api/audit/recent":
                    self._require_phase(2)
                    persona = self._persona(params)
                    if not can_curate(persona):
                        raise ApiError("forbidden",
                                       "audit log requires curator or admin",
                                       403)
                    return self._send_json(
                        {"events": repo.recent_audit(persona)})
                if path.startswith("/api/artifacts/"):
                    parts = path.split("/")
                    artifact_id = parts[3]
                    persona = self._persona(params)
                    if len(parts) == 5 and parts[4] == "file":
                        item = repo.get_artifact(persona, artifact_id)
                        if not item:
                            raise ApiError("not_found", "artifact not found",
                                           404)
                        return self._send_source_file(item)
                    if len(parts) == 5 and parts[4] == "changes":
                        changes = repo.get_version_changes(
                            persona, artifact_id,
                            (params.get("against") or [""])[0])
                        if changes is None:
                            raise ApiError("not_found", "artifact not found",
                                           404)
                        return self._send_json(changes)
                    if len(parts) == 5 and parts[4] == "versions":
                        item = repo.get_artifact(persona, artifact_id)
                        if not item:
                            raise ApiError("not_found", "artifact not found",
                                           404)
                        return self._send_json({
                            "versions": repo.get_family_versions(
                                persona, item["family_id"])})
                    item = repo.get_artifact(persona, artifact_id)
                    if not item:
                        raise ApiError("not_found", "artifact not found",
                                       404)
                    return self._send_json({"artifact": item})
                raise ApiError("not_found", "unknown endpoint", 404)
            finally:
                conn.close()

        def do_POST(self):
            parsed = urllib.parse.urlparse(self.path)
            path = posixpath.normpath(urllib.parse.unquote(parsed.path))
            try:
                if EntraAuth().enabled:
                    self._same_origin()
                self._user = self._signed_in(path)
                return self._api_post(path, self._body())
            except ApiError as e:
                return self._send_error(e.status, e.code, e.message)
            except PermissionError as e:
                return self._send_error(403, "forbidden", str(e))
            except ValueError as e:
                return self._send_error(400, "bad_request", str(e))
            except KeyError:
                return self._send_error(404, "not_found", "not found")
            except Exception:
                return self._send_error(500, "internal",
                                        "unexpected server error")

        def _api_post(self, path, body):
            repo, conn = self._repo()
            try:
                if path in ("/api/agent/query", "/api/agent/query/stream"):
                    pid = body.get("persona", "consumer")
                    if load_settings().phase < 2:
                        pid = "consumer"  # Phase 1: internal viewer only
                    persona = self._user or get_persona(pid)
                    if path.endswith("/stream"):     # v2: live answer
                        return self._stream_answer(
                            KnowledgeAgent(conn), persona, body)
                    answer = KnowledgeAgent(conn).ask(
                        persona, body.get("question", ""),
                        body.get("conversation_id"))
                    return self._send_json(_answer_json(answer))
                if path == "/api/app-settings":
                    if not self._admin_view():
                        raise ApiError("admin_only",
                                       "only an admin can change settings",
                                       403)
                    if "discover_for_everyone" in body:
                        set_discover_for_everyone(
                            conn, bool(body["discover_for_everyone"]))
                    return self._send_json({
                        "admin_view": True,
                        "discover_for_everyone":
                            discover_for_everyone(conn)})
                if path.startswith("/api/chats/") and \
                        path.endswith(("/rename", "/delete")):
                    persona = self._persona(
                        {"persona": [body.get("persona", "consumer")]})
                    store, chat_id = ChatStore(conn), path.split("/")[3]
                    ok = (store.rename(persona.id, chat_id,
                                       body.get("title", ""))
                          if path.endswith("/rename")
                          else store.delete(persona.id, chat_id))
                    if not ok:
                        raise ApiError("not_found", "chat not found", 404)
                    conn.commit()
                    return self._send_json({"ok": True,
                                            "chat": store.get(persona.id,
                                                              chat_id)})
                if path == "/api/artifacts":
                    self._require_phase(2)
                    persona = get_persona(body.get("persona", ""))
                    payload = dict(body)
                    payload.pop("_server_content_hash", None)
                    warnings = []
                    if payload.get("file_base64"):
                        try:
                            data = base64.b64decode(
                                payload.pop("file_base64"))
                        except Exception:
                            raise ApiError("bad_file",
                                           "file_base64 is not valid "
                                           "base64", 400)
                        payload["_server_content_hash"] = hashlib.sha256(
                            data).hexdigest()
                        filename = payload.pop("filename", "")
                        text, warnings = extract_text(filename, data)
                        if text:
                            payload["content"] = text
                            payload["extraction_status"] = "EXTRACTED"
                        else:
                            safe_name = re.sub(r"[^A-Za-z0-9._ -]", "_",
                                               filename) or "upload"
                            payload["content"] = (
                                f"[Extraction pending for {safe_name}; "
                                "body not indexed]")
                            payload["extraction_status"] = "PENDING"
                    result = repo.create_artifact(persona, payload)
                    result["warnings"] = warnings
                    return self._send_json(result, status=201)
                if path.startswith("/api/artifacts/") and \
                        path.endswith("/open"):
                    persona = self._persona(
                        {"persona": [body.get("persona", "consumer")]})
                    item = repo.get_artifact(persona, path.split("/")[3])
                    if not item:
                        raise ApiError("not_found", "artifact not found",
                                       404)
                    return self._open_locally(item)
                if path.startswith("/api/artifacts/") and \
                        path.endswith("/transition"):
                    self._require_phase(2)
                    artifact_id = path.split("/")[3]
                    persona = get_persona(body.get("persona", ""))
                    result = repo.transition_artifact(
                        persona, artifact_id,
                        body.get("target_status", ""),
                        body.get("note", ""))
                    return self._send_json(result)
                raise ApiError("not_found", "unknown endpoint", 404)
            finally:
                conn.close()

        def _stream_answer(self, agent, persona, body):
            """v2: the answer as newline-delimited JSON while the LLM
            writes it: {"type": "delta", "text"} pieces, {"type": "reset"}
            if a provider failed half-way, then one {"type": "done", ...}
            with the checked, saved answer (it replaces the draft, so an
            ungrounded draft is never the final word)."""
            question = (body.get("question") or "").strip()
            if not question:
                raise ValueError("question must not be empty")
            self.send_response(200)
            self.send_header("Content-Type", "application/x-ndjson")
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.close_connection = True      # the body ends when we close
            gone = []

            def emit(obj):
                if gone:
                    return
                try:
                    self.wfile.write(
                        (json.dumps(obj, default=str) + "\n").encode())
                    self.wfile.flush()
                except OSError:               # the browser went away;
                    gone.append(True)         # finish and save anyway

            def on_delta(text):
                emit({"type": "reset"} if text is None
                     else {"type": "delta", "text": text})
            try:
                answer = agent.ask(persona, question,
                                   body.get("conversation_id"),
                                   on_delta=on_delta)
                emit({"type": "done", **_answer_json(answer)})
            except Exception:
                emit({"type": "error",
                      "message": "unexpected server error"})

        def _send_sources_zip(self, repo, persona, ids, chat_title):
            """One ZIP with an answer's top documents (the cited one
            first). Each is checked against the user's access again now;
            the original file is used when this machine has it, else the
            text the app extracted. SOURCES.txt lists what is inside."""
            buf, used, lines, count = io.BytesIO(), set(), [], 0
            with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
                for rank, aid in enumerate(ids, 1):
                    item = repo.get_artifact(persona, aid)
                    if not item:
                        lines.append(f"{rank}. (no longer available to you)")
                        continue
                    try:
                        fpath = self._synced_file(item)
                        with open(fpath, "rb") as fh:
                            data = fh.read()
                        name, kind = os.path.basename(fpath), "original file"
                    except ApiError:
                        data = (item.get("content_text") or "").encode()
                        name = _safe_name(item["title"]) + ".txt"
                        kind = "text extracted by the app; the original " \
                               "file is not on this machine"
                    name = _unique(f"{rank:02d} {name}", used)
                    z.writestr(name, data)
                    count += 1
                    lines.append(
                        f"{rank}. {item['title']} v{item['version']}"
                        + (" (cited in the answer)" if rank == 1 else "")
                        + f"\n   file: {name} ({kind})"
                        + f"\n   source: {item.get('source_url') or '-'}")
                z.writestr("SOURCES.txt", (
                    f"Sources for: {chat_title}\n"
                    "The answer cites the first document; the others were "
                    "the next best matches.\n\n" + "\n".join(lines)
                    + "\n").encode())
            if not count:
                raise ApiError("not_found", "none of this answer's sources "
                               "are available to you", 404)
            body = buf.getvalue()
            fname = _safe_name(chat_title)[:60] or "answer"
            self.send_response(200)
            self.send_header("Content-Type", "application/zip")
            self.send_header("Content-Disposition",
                             f'attachment; filename="sources - {fname}.zip"')
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def _synced_file(self, item) -> str:
            """Path of a synced document's original file. Only files the
            folder sync indexed qualify: a contributed artifact's
            source_url is user-typed and must never become a local read."""
            if not item.get("is_current_approved"):
                # Sync keeps one file per source path, so it now holds
                # the newest version; older versions show stored text.
                raise ApiError("not_found", "older version: the original "
                               "file now holds the current version", 404)
            fpath = (local_path(item.get("source_url") or "")
                     if item.get("contributor") == CONTRIBUTOR else None)
            ext = os.path.splitext(fpath or "")[1].lower().lstrip(".")
            if not fpath or ext not in SUPPORTED or \
                    not os.path.isfile(fpath):
                raise ApiError("not_found", "original file is not available "
                               "on this machine", 404)
            return fpath

        def _open_locally(self, item):
            """Open the file in its default desktop app (Word, Acrobat…),
            like a double-click in Explorer. Only for a browser on this
            same machine, and only via a JSON POST, which other web sites
            cannot send without the browser asking this server first."""
            if self.client_address[0] not in ("127.0.0.1", "::1"):
                raise ApiError("forbidden", "files open only on the machine "
                               "running the POC", 403)
            if not (self.headers.get("Content-Type") or "").startswith(
                    "application/json"):
                raise ApiError("bad_request", "JSON request required", 400)
            fpath = self._synced_file(item)
            if sys.platform.startswith("win"):
                os.startfile(fpath)
            else:
                subprocess.Popen(["open" if sys.platform == "darwin"
                                  else "xdg-open", fpath])
            return self._send_json({"opened": os.path.basename(fpath)})

        def _send_source_file(self, item):
            """Stream a synced document's original file."""
            fpath = self._synced_file(item)
            name = os.path.basename(fpath)
            ext = os.path.splitext(name)[1].lower()
            ctype = ("text/plain; charset=utf-8" if ext in (".txt", ".md")
                     else mimetypes.guess_type(name)[0]
                     or "application/octet-stream")
            self.send_response(200)
            self.send_header("Content-Type", ctype)
            # PDF, images and text open in the browser; Office files are
            # downloaded and open in Word/PowerPoint/Excel.
            self.send_header("Content-Disposition", "inline; filename*=UTF-8''"
                             + urllib.parse.quote(name))
            self.send_header("Content-Length", str(os.path.getsize(fpath)))
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            with open(fpath, "rb") as fh:
                shutil.copyfileobj(fh, self.wfile)

        # -------------------------------------------------- static
        def _static(self, path):
            if path in _STATIC:
                fname = _STATIC[path]
            elif path.startswith("/"):
                fname = path.lstrip("/")
            else:
                return self._send_error(404, "not_found", "not found")
            root = os.path.abspath(web_dir)
            fpath = os.path.abspath(os.path.join(root, fname))
            if not fpath.startswith(root + os.sep):
                return self._send_error(403, "forbidden", "forbidden")
            if not os.path.isfile(fpath):
                return self._send_error(404, "not_found", "not found")
            ext = os.path.splitext(fpath)[1]
            with open(fpath, "rb") as fh:
                data = fh.read()
            self.send_response(200)
            self.send_header("Content-Type",
                             _MIME.get(ext, "application/octet-stream"))
            self.send_header("Content-Security-Policy",
                             "default-src 'self'; style-src 'self' "
                             "'unsafe-inline'; script-src 'self'; "
                             "img-src 'self' data:; connect-src 'self'; "
                             "object-src 'none'; base-uri 'none'; "
                             "frame-ancestors 'none'; form-action 'self'")
            self.send_header("X-Content-Type-Options", "nosniff")
            # Revalidate every load, so an updated app.js is never mixed
            # with a cached old one.
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

    return Handler


def create_server(host: str, port: int, db_path: str,
                  web_dir: str) -> ThreadingHTTPServer:
    os.makedirs(os.path.dirname(db_path) or ".", exist_ok=True)
    conn = connect(db_path)
    initialize(conn)
    seed_if_empty(conn)
    ChatStore(conn).purge(load_settings().chat_retention_days)  # 2 weeks
    conn.commit()
    conn.close()
    return ThreadingHTTPServer((host, port), make_handler(db_path, web_dir))
