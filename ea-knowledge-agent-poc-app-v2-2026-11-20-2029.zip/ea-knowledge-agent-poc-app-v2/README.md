# EA — Knowledge Agent POC — version 2 (chat experience)

A runnable, offline, standard-library-only proof of the governed knowledge
journey described in `../requirements_summary.md` and the V2 deck:
**discover → contribute → govern → reuse**, with a grounded, permission-
aware AI experience on top.

This is a POC increment, **not** a production system. Persona switching is
a demo convenience, not authentication. SQLite (with vectors stored in a
table), hybrid keyword + Vertex embedding retrieval and stdlib file
extraction stand in for managed storage, a vector database and production
parsers. Claude and SharePoint/Graph are adapter seams,
inactive by default. **Never load real client data.**

## What's new in version 2

Version 2 replaces the search-style Ask page with a chat, like ChatGPT.
Everything else (sync, versions, permissions, Vertex AI, Discover) works as
in version 1.

| | Version 1 | Version 2 |
|---|---|---|
| Ask page | One question, a list of results | A chat thread; ask follow-up questions about the answer |
| Sources | Up to 4 citations | **One** citation: the top document |
| History | None | **Left sidebar** lists past chats; reopen one to continue it, or click **+ New chat** |
| Follow-ups | Each question stands alone | The chat so far is used to understand follow-ups ("what about Tier 1?") |

How a follow-up is answered:

1. The chat's last 6 questions and answers (12 messages,
   `CHAT_HISTORY_MESSAGES`) are loaded (`chat_messages`). **Context-window
   fallback:** long answers are shortened to 1,500 characters, the oldest
   messages are dropped until the rest fit in `CHAT_HISTORY_CHARS` (24,000),
   and if Gemini still reports its token limit, the question is retried
   once with only the last question and answer.
2. **Standalone question:** Gemini (or Claude) rewrites the follow-up into
   a question that makes sense on its own, for example *"What about Tier
   1?"* becomes *"What is the RTO for Tier 1 systems?"*. Without an LLM,
   the previous question and the follow-up are joined.
3. Search runs on that standalone question, still filtered by permissions.
   The document the chat is already about gets a small bonus (+2), so
   follow-ups stay on it unless a clearly better document matches.
4. The **top document only** goes to the LLM, together with the chat so
   far, and becomes the answer's single citation. The top 4 matches are
   still logged, best first: in the audit row (`top_ids`) and, with
   `RETRIEVAL_DEBUG=1`, in the `top_documents` line of
   `logs/retrieval_debug.log`, where the one used has `answer_source: true`.
5. The question and the answer (with its citation) are saved to the chat.

New tables: `chats` (one row per chat: persona, title = first question,
dates) and `chat_messages` (one row per question or answer, with the
answer's status, provider and citation). New endpoints:
`GET /api/chats?persona=` (the sidebar list) and
`GET /api/chats/<id>?persona=` (a chat's messages). A chat is only visible
to the persona that created it.

**The chat experience:**

- **Chat is the main screen.** On the Ask page the left page rail is
  hidden and the chat fills the window. The chat sidebar has the other
  pages (Discover, and in phase 2 Contribute, Govern, Reports) at the
  bottom. On small screens the page tabs stay at the top instead.
- **Answers stream in** as Gemini (or Claude) writes them
  (`POST /api/agent/query/stream`, newline-delimited JSON: `delta`
  pieces, then one `done` event with the checked answer and its source).
  The `done` answer replaces the draft, so if the draft fails the
  grounding check the user ends up seeing the abstain message. Vertex
  uses `streamGenerateContent?alt=sse`. Without an LLM the answer
  arrives in one piece. `POST /api/agent/query` still returns the whole
  answer at once.
- **Rename or delete a chat** with the ✎ and × buttons on a sidebar row
  (`POST /api/chats/<id>/rename` with `{persona, title}`,
  `POST /api/chats/<id>/delete` with `{persona}`). Renaming keeps the
  chat's place in the list. Deleting removes the chat and its messages
  for good, after a confirmation (the audit log keeps only its
  fingerprint, as before).

**Privacy note:** version 1 never stored question text (the audit log keeps
a fingerprint). Version 2 must store questions and answers to show the
history. Until real sign-in replaces the demo personas, everyone using the
same persona on one server shares the same chat list.

**Chat retention:** a chat not used for 14 days (`CHAT_RETENTION_DAYS`) is
deleted with its messages: when the server starts, when the chat list
loads, and before each question. 2 weeks is for the POC; the project plan
is 6 months (`CHAT_RETENTION_DAYS=180`). `0` keeps chats forever.

**Discover opens as a side panel** over the right of the chat, so the
chat stays where it was. Admins open it with **Discover documents** under
**+ New chat** (or the Discover tab on phones). On wide screens (1200px
and up) the chat makes room and both are visible side by side. A card still opens the document drawer
on top; Esc closes the drawer, then the panel.

**Discover is admin-only (POC, phase 1).** A **User / Admin** switch in the
top bar picks the view; it is a demo switch, not sign-in, and is sent as
the `X-POC-View: admin` header. In Admin view the Ask sidebar shows **Admin
settings** with **Discover visible to users** (off by default;
`DISCOVER_FOR_EVERYONE` in `.env` sets the default until an admin changes
it, and the choice is stored in the `app_settings` table). While it is off,
User view hides the Discover tab and link, and the server refuses
`GET /api/artifacts` and `GET /api/tags` with 403 `admin_only`. A chat's
source link still opens its document for everyone. Endpoints:
`GET /api/app-settings` and `POST /api/app-settings`
(`{discover_for_everyone}`, Admin view only). Phase 2 keeps its persona
rules and doesn't show the switch.

## Architecture

```
web/ (HTML/CSS/JS, no build)  ── same process ──  api.py (http.server)
                                                     │
              ┌──────────────┬───────────────────────┤
        repository.py   retrieval.py           agent.py ── claude_client.py (opt)
        (ACL + audit,   (approved/current      (sanitize → synthesize
         lifecycle)      evidence only)         → cite or abstain)
              │                 │
        database.py ── seed.py ── guardrails.py (injection, validation)
              │
        SQLite data/poc.db   +  seams: auth.py (Entra seam),
        sharepoint_connector.py (Sites.Selected/delta seam),
        file_extraction.py (parser seam)
```

Trust model: every repository/retrieval query applies group ACLs; only
`APPROVED` current versions are agent evidence; Claude output returns
through validation; audit events store hashes/IDs, never raw prompts or
bodies.

## Quick start

```bash
cd ea-knowledge-agent-poc-app
make run          # serves http://127.0.0.1:8765 (seeds data/poc.db once)
make test         # 25 unittest acceptance checks
make reset-demo   # deletes data/poc.db only
make check        # compileall + tests
```

No virtualenv or packages needed — Python 3.10+ standard library only.
Settings can go in a `.env` file in the project folder (copy
`.env.example`); it is read on every request, so edits apply without a
restart. Variables set in the shell override the file.

## Real documents + LLM answers (Phase 1)

Ask answers from **indexed EA documents** and shows numbered sources.

```
documents -> make sync -> SQLite (approved, current, ACL) -> passage retrieval -> Vertex AI -> answer + [1][2] sources
```

1. **Index documents** (TXT, MD, DOCX, PPTX, XLSX; PDF with
   `pip install pypdf`; JPG/PNG via OCR with `pip install rapidocr onnxruntime`;
   files up to `SYNC_MAX_MB`, default 200):
   - SharePoint: set `GRAPH_TENANT_ID`, `GRAPH_CLIENT_ID`, `GRAPH_CLIENT_SECRET`,
     `SHAREPOINT_SITE_ID`, `SHAREPOINT_DRIVE_ID` (Graph app permission to read
     the site, e.g. `Sites.Selected`), then `make sync`.
   - Local folder: `make sync FOLDER=path/to/docs`.
   - Add `RESET=1` the first time to drop the synthetic demo data.
   - Re-running is safe: unchanged files are skipped, changed files become a
     new current version (old one superseded), files removed at the source are
     archived. A partially failed sync never archives anything.
   - Folder names become the domain and tags. Synced files are stored as
     APPROVED (they are approved at the source) and visible to
     `SYNC_ALLOWED_GROUPS`.
2. **Enable the LLM** (Vertex AI): `gcloud auth login`, then set `VERTEX_PROJECT`,
   `VERTEX_LOCATION` and `VERTEX_MODEL` (a Gemini model your project can use)
   before `make run`. The top bar then shows "Vertex AI · <model>" and each
   answer says which engine produced it. If the LLM call fails the app falls
   back to the built-in summary and says so.
3. **Enable semantic search** (optional, recommended): also set
   `VERTEX_EMBED_MODEL` (e.g. `text-embedding-005`). `make sync` then
   embeds every current approved document's passages into the
   `artifact_chunks` table (only new or changed documents are embedded).
   Questions then match on meaning ("how long do we keep files" finds a
   "retention period" passage), not only on shared words. To embed without
   a sync: `python -m ea_knowledge_agent.embeddings`; to see each
   document's score and similarity for a question:
   `python -m ea_knowledge_agent.embeddings --probe "your question"`.
   Without it, or if an embedding call fails, search is keyword-only.
4. **Ask.** Retrieval is limited to documents the viewer may see; the best
   passages of the top documents are sent to the model, which must answer only
   from them and cite `[n]`. No evidence means no LLM call and an explicit
   "could not find" answer.

## Demo walkthrough (mapped to acceptance criteria)

1. **Ask** (AC-007/008): try `Show the latest Insurance technology
   strategy` → grounded answer citing *Insurance Technology Strategy
   v4.2*. Then `What is our policy on quantum computing hardware?` → safe
   abstention.
2. **Permissions** (AC-006/GR): `What is the approved API strategy?` as
   *consumer* answers only from authorized artifacts — the restricted
   *Enterprise API Strategy* never appears in citations or the Discover
   list. Switch persona to *admin* → the answer cites it directly.
3. **Discover** (AC-003/004): tag chips, lifecycle/audience filters, sort
   newest-first; open a card → drawer shows source link, versions,
   lifecycle history (v4.1 superseded under v4.2's family).
4. **Contribute** (AC-001): fill the form (or attach TXT/DOCX/PPTX) →
   artifact created as DRAFT; duplicates and missing metadata are
   rejected with clear errors.
5. **Govern** (AC-009): as contributor submit the draft for review; as
   approver approve it (prior approved version in the family is
   superseded automatically); consumer sees read-only explanation.
6. **Reports** (AC-010): curator/admin see item-level stale, unowned,
   superseded, duplicate and broken-link rows; other personas see counts
   and the permission note.
7. **Audit** (GR): `GET /api/audit/recent?persona=curator` lists sanitized
   events — question hashes, never raw prompts.

## Configuration

| Variable | Purpose |
|---|---|
| `ANTHROPIC_API_KEY`, `CLAUDE_MODEL` | Optional Claude adapter (generation only, after ACL/policy checks; fails closed to local synthesis) |
| `VERTEX_EMBED_MODEL`, `VERTEX_EMBED_MIN_SIM` | Optional semantic retrieval: Vertex embedding model, and the cosine similarity (default 0.60) a passage needs to match on meaning alone |
| `GRAPH_TENANT_ID`, `GRAPH_CLIENT_ID`, `GRAPH_CLIENT_SECRET`, `SHAREPOINT_SITE_ID`, `SHAREPOINT_DRIVE_ID` | SharePoint/Graph seam — **not called** by the demo; `/api/integrations` reports status only |
| `POC_HOST`, `POC_PORT`, `POC_DB`, `POC_WEB_DIR` | Server overrides |

## Security limitations (explicit)

- Persona dropdown is **not authentication** — production requires Entra
  ID SSO/RBAC at the identity seam.
- Retrieval is keyword/metadata ranking plus, when `VERTEX_EMBED_MODEL`
  is set, Vertex embedding similarity. Vectors are compared in Python, one
  document at a time, after the ACL filter: fine for thousands of passages;
  a vector index (MongoDB Atlas Vector Search, AlloyDB/pgvector, Vertex AI
  Vector Search) is the production step. Documents approved through Govern
  are embedded at the next sync; until then they match on keywords only.
- PDF and JPG/PNG extraction need optional packages (`pypdf`; `rapidocr`
  + `onnxruntime`, whose default OCR models ship inside the package); XLSX
  dates appear as Excel serial numbers. Visio, GIF and SVG are pending
  production parsers; such uploads register metadata as `PENDING`, but
  they cannot be approved and are never used as agent evidence until
  extraction succeeds.
- SQLite is single-node demo storage; managed storage/search products
  remain client architecture decisions.
- Audit is append-only JSON rows; production needs immutable/WORM audit.
- Synthetic data only; no PII/PHI and no automated decisions.

## Next increments

Entra adapter behind `auth.py`; SharePoint `Sites.Selected` + delta sync
via `sharepoint_connector.py`; managed vector index behind `retrieval.py`;
contextual follow-up retrieval; production extractors; transcript ingestion;
external-publication workflow; curator bulk operations.
