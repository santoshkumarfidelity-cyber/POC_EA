"""Tests for real-document ingestion (folder / SharePoint), chunk-level
retrieval and Vertex AI answer generation. No network: HTTP is stubbed."""

import io
import json
import os
import tempfile
import unittest
from unittest import mock

from ea_knowledge_agent.agent import KnowledgeAgent
from ea_knowledge_agent.auth import get_persona
from ea_knowledge_agent.claude_client import build_evidence_text
from ea_knowledge_agent import config
from ea_knowledge_agent.config import Settings, read_env_file
from ea_knowledge_agent.database import connect, initialize
from ea_knowledge_agent.ingest import DocumentIngestor, file_uri, \
    local_path, sync_folder, sync_sharepoint
from ea_knowledge_agent.retrieval import PermissionAwareRetriever
from ea_knowledge_agent.vertex_client import VertexClient

from tests.test_acceptance import _docx_bytes, _pptx_bytes

VIEWER = get_persona("consumer")


def _settings(**kw):
    base = dict(vertex_project="proj", vertex_model="gemini-test",
                vertex_access_token="tok")
    base.update(kw)
    return Settings(**base)


class Fresh(unittest.TestCase):
    def setUp(self):
        fd, self.path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        self.conn = connect(self.path)
        initialize(self.conn)
        self.ing = DocumentIngestor(self.conn, Settings())

    def tearDown(self):
        self.conn.close()
        os.unlink(self.path)

    def add(self, title, text, url=None, **kw):
        return self.ing.upsert(
            source_url=url or f"https://sp.example/{title}.txt",
            title=title, data=text.encode(), filename=f"{title}.txt", **kw)


class IngestTests(Fresh):
    def test_added_doc_is_approved_current_and_visible(self):
        self.assertEqual(self.add("Cloud Standard", "Use zone redundancy.")[0],
                         "added")
        row = self.conn.execute(
            "SELECT lifecycle_status, is_current_approved FROM "
            "artifact_versions").fetchone()
        self.assertEqual((row[0], row[1]), ("APPROVED", 1))
        hits = PermissionAwareRetriever(self.conn).search(
            VIEWER, "zone redundancy")
        self.assertEqual(hits[0]["title"], "Cloud Standard")

    def test_resync_unchanged_then_changed_supersedes(self):
        self.add("Std", "version one text about encryption")
        self.assertEqual(self.add("Std", "version one text about encryption")[0],
                         "unchanged")
        self.assertEqual(self.add("Std", "version two about key rotation")[0],
                         "updated")
        st = [r[0] for r in self.conn.execute(
            "SELECT lifecycle_status FROM artifact_versions ORDER BY version")]
        self.assertEqual(st, ["SUPERSEDED", "APPROVED"])
        hits = PermissionAwareRetriever(self.conn).search(VIEWER,
                                                          "key rotation")
        self.assertEqual(len(hits), 1)
        self.assertEqual(hits[0]["version"], "2.0")

    def test_duplicate_content_under_other_url_is_skipped(self):
        self.add("A", "identical body text here", url="https://sp.example/a")
        self.assertEqual(self.add("B", "identical body text here",
                                  url="https://sp.example/b")[0], "duplicate")

    def test_missing_source_file_is_archived(self):
        self.add("Gone", "will be removed from source")
        self.assertEqual(self.ing.archive_missing(set()), 1)
        self.assertEqual(PermissionAwareRetriever(self.conn).search(
            VIEWER, "removed source"), [])

    def test_unsupported_and_empty_files_are_skipped(self):
        self.assertEqual(self.ing.upsert(
            source_url="https://sp/x.vsdx", title="x", data=b"1",
            filename="x.vsdx")[0], "skipped")
        self.assertEqual(self.ing.upsert(
            source_url="https://sp/y.txt", title="y", data=b"  ",
            filename="y.txt")[0], "skipped")

    def test_folder_names_become_domain_and_tags(self):
        self.add("Pattern", "api gateway pattern", folders=("Patterns", "API"))
        d = self.conn.execute("SELECT domain FROM artifact_families"
                              ).fetchone()[0]
        tags = {r[0] for r in self.conn.execute(
            "SELECT tag FROM artifact_tags")}
        self.assertEqual(d, "PATTERNS")
        self.assertTrue({"PATTERNS", "API", "TXT"} <= tags)

    def test_sync_folder_reads_txt_docx_pptx_and_archives_removed(self):
        with tempfile.TemporaryDirectory() as d:
            os.makedirs(os.path.join(d, "Strategy"))
            for rel, data in (
                    ("Strategy/s.txt",
                     b"Platform strategy: adopt event driven integration."),
                    ("p.docx",
                     _docx_bytes("Data retention policy is seven years.")),
                    ("o.pptx",
                     _pptx_bytes("Onboarding roadmap for new architects"))):
                with open(os.path.join(d, rel), "wb") as fh:
                    fh.write(data)
            st = sync_folder(self.ing, d)
            self.assertEqual(st["added"], 3)
            self.assertEqual(sync_folder(self.ing, d)["unchanged"], 3)
            os.remove(os.path.join(d, "p.docx"))
            self.assertEqual(sync_folder(self.ing, d)["archived"], 1)


class FakeSharePoint:
    def __init__(self, files):
        self.files = files            # id -> (name, bytes)
        self.fail = set()

    def list_files(self):
        return [{"id": i, "name": n, "webUrl": f"https://sp.example/{n}",
                 "file": {}, "parentReference": {
                     "driveId": "d", "path": "/drives/d/root:/Standards"},
                 "lastModifiedBy": {"user": {"displayName": "Ana Ng"}},
                 "lastModifiedDateTime": "2026-10-01T00:00:00Z"}
                for i, (n, _) in self.files.items()]

    def download_item(self, drive_id, item_id):
        if item_id in self.fail:
            raise RuntimeError("download failed")
        return self.files[item_id][1]


class SourceFileTests(Fresh):
    """The original file of a synced document opens through the server."""

    def setUp(self):
        super().setUp()
        self.dir = tempfile.mkdtemp()
        with open(os.path.join(self.dir, "Retention Rules.txt"), "wb") as f:
            f.write(b"Claims records are kept for ten years.")
        sync_folder(self.ing, self.dir)
        self.vid = self.conn.execute(
            "SELECT id FROM artifact_versions").fetchone()[0]
        self.conn.commit()
        import threading
        from ea_knowledge_agent.api import create_server
        self.server = create_server("127.0.0.1", 0, self.path,
                                    os.path.join(os.path.dirname(
                                        __file__), os.pardir, "web"))
        threading.Thread(target=self.server.serve_forever,
                         daemon=True).start()
        self.base = f"http://127.0.0.1:{self.server.server_address[1]}"

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()

    def get(self, vid):
        import urllib.error
        import urllib.request
        try:
            with urllib.request.urlopen(
                    f"{self.base}/api/artifacts/{vid}/file?persona=consumer"
                    ) as r:
                return r.status, r.read()
        except urllib.error.HTTPError as e:
            return e.code, b""

    def test_synced_file_is_served(self):
        self.assertEqual(self.get(self.vid),
                         (200, b"Claims records are kept for ten years."))

    def test_non_synced_artifact_is_never_read_from_disk(self):
        # Contributed artifacts carry a user-typed source_url.
        self.conn.execute("UPDATE artifact_families SET contributor='owner'")
        self.conn.commit()
        self.assertEqual(self.get(self.vid)[0], 404)
        self.assertEqual(self.get("missing")[0], 404)

    def post_open(self, vid, ctype="application/json"):
        import urllib.error
        import urllib.request
        req = urllib.request.Request(
            f"{self.base}/api/artifacts/{vid}/open",
            data=b'{"persona": "consumer"}', method="POST",
            headers={"Content-Type": ctype})
        try:
            with urllib.request.urlopen(req) as r:
                return r.status, json.loads(r.read())
        except urllib.error.HTTPError as e:
            return e.code, {}

    def test_open_launches_the_desktop_app(self):
        with mock.patch("ea_knowledge_agent.api.subprocess.Popen") as popen, \
                mock.patch("ea_knowledge_agent.api.os.startfile",
                           create=True) as startfile:
            status, body = self.post_open(self.vid)
        self.assertEqual((status, body),
                         (200, {"opened": "Retention Rules.txt"}))
        launched = startfile.call_args or popen.call_args
        self.assertIn("Retention Rules.txt", str(launched))

    def test_open_refuses_non_json_and_non_synced(self):
        with mock.patch("ea_knowledge_agent.api.subprocess.Popen") as popen:
            self.assertEqual(self.post_open(self.vid, "text/plain")[0], 400)
            self.conn.execute(
                "UPDATE artifact_families SET contributor='owner'")
            self.conn.commit()
            self.assertEqual(self.post_open(self.vid)[0], 404)
        popen.assert_not_called()

    def test_file_uri_round_trip_and_legacy_windows_form(self):
        p = os.path.join(self.dir, "Retention Rules.txt")
        self.assertEqual(local_path(file_uri(p)), os.path.abspath(p))
        self.assertEqual(local_path("file://C%3A%5Cdocs%5Ca%20b.md"),
                         "C:\\docs\\a b.md")
        self.assertIsNone(local_path("https://sp.example/a.docx"))


class EnvFileTests(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.mkdtemp()
        self.path = os.path.join(self.dir, ".env")
        with open(self.path, "w") as f:
            f.write("# comment\n\nVERTEX_PROJECT=proj-1\n"
                    'export VERTEX_MODEL="gemini-x"\n'
                    "VERTEX_LOCATION=europe-west4  # region\n"
                    "ANTHROPIC_API_KEY=\n")

    def tearDown(self):
        os.remove(self.path)

    def test_parses_comments_quotes_export_and_skips_empty(self):
        self.assertEqual(read_env_file(self.path), {
            "VERTEX_PROJECT": "proj-1", "VERTEX_MODEL": "gemini-x",
            "VERTEX_LOCATION": "europe-west4"})
        self.assertEqual(read_env_file(self.path + ".missing"), {})

    def test_shell_variables_win_over_the_file(self):
        with mock.patch.object(config, "_APP_ROOT", self.dir), \
                mock.patch.dict(os.environ, {"VERTEX_MODEL": "from-shell"}):
            s = config.load_settings()
        self.assertEqual((s.vertex_project, s.vertex_model),
                         ("proj-1", "from-shell"))


class SharePointSyncTests(Fresh):
    def test_sync_maps_owner_folders_and_url(self):
        sp = FakeSharePoint({"1": ("Sec.txt", b"zero trust network rules")})
        st = sync_sharepoint(self.ing, sp)
        self.assertEqual(st["added"], 1)
        fam = self.conn.execute(
            "SELECT owner, domain FROM artifact_families").fetchone()
        self.assertEqual((fam[0], fam[1]), ("Ana Ng", "STANDARDS"))
        self.assertEqual(self.conn.execute(
            "SELECT source_url FROM artifact_versions").fetchone()[0],
            "https://sp.example/Sec.txt")

    def test_failed_download_blocks_archiving(self):
        sp = FakeSharePoint({"1": ("A.txt", b"alpha doc body"),
                             "2": ("B.txt", b"beta doc body")})
        sync_sharepoint(self.ing, sp)
        del sp.files["1"]                 # A removed at source
        sp.fail.add("2")                  # B temporarily fails
        st = sync_sharepoint(self.ing, sp)
        self.assertEqual((st["failed"], st["archived"]), (1, 0))
        sp.fail.clear()
        self.assertEqual(sync_sharepoint(self.ing, sp)["archived"], 1)


class ChunkRetrievalTests(Fresh):
    def test_answer_buried_deep_in_long_doc_is_returned_as_passage(self):
        filler = "General background paragraph about nothing. " * 120
        needle = "The disaster recovery RTO for tier one systems is four hours."
        self.add("Big Doc", filler + "\n" + needle + "\n" + filler)
        hit = PermissionAwareRetriever(self.conn).search(
            VIEWER, "What is the disaster recovery RTO for tier one?")[0]
        self.assertTrue(any("four hours" in p for p in hit["passages"]))
        self.assertIn("[1] Big Doc", build_evidence_text([hit]))
        self.assertIn("four hours", build_evidence_text([hit]))


def _vertex_response(text):
    body = json.dumps({"candidates": [{"content": {"parts": [
        {"text": text}]}}]}).encode()
    resp = mock.MagicMock()
    resp.read.return_value = body
    resp.__enter__.return_value = resp
    return resp


class VertexTests(Fresh):
    def setUp(self):
        super().setUp()
        self.add("DR Standard", "The disaster recovery RTO is four hours.")

    def agent(self, vertex):
        return KnowledgeAgent(self.conn, vertex=vertex)

    def test_not_configured_without_project_and_model(self):
        self.assertFalse(VertexClient(Settings()).configured)
        self.assertTrue(VertexClient(_settings()).configured)

    def test_request_shape_and_answer_used(self):
        seen = {}

        def fake(req, timeout=None, **kw):
            seen["url"] = req.full_url
            seen["auth"] = req.get_header("Authorization")
            seen["body"] = json.loads(req.data.decode())
            return _vertex_response("RTO is four hours [1].")
        with mock.patch("urllib.request.urlopen", fake):
            a = self.agent(VertexClient(_settings())).ask(
                VIEWER, "What is the disaster recovery RTO?")
        self.assertEqual((a.provider, a.status), ("vertex", "grounded"))
        self.assertEqual(a.answer, "RTO is four hours [1].")
        self.assertEqual(a.citations[0].title, "DR Standard")
        self.assertEqual(seen["auth"], "Bearer tok")
        self.assertIn("us-central1-aiplatform.googleapis.com/v1/projects/"
                      "proj/locations/us-central1/publishers/google/models/"
                      "gemini-test:generateContent", seen["url"])
        prompt = seen["body"]["contents"][0]["parts"][0]["text"]
        self.assertIn("[1] DR Standard", prompt)
        self.assertIn("four hours", prompt)

    def test_global_location_host(self):
        c = VertexClient(_settings(vertex_location="global"))
        self.assertTrue(c._url().startswith(
            "https://aiplatform.googleapis.com/v1/projects/proj/"
            "locations/global/"))

    def test_bad_project_value_is_rejected(self):
        c = VertexClient(_settings(vertex_project="x/../evil"))
        with self.assertRaises(RuntimeError):
            c._url()

    def test_llm_failure_falls_back_to_local_with_citations(self):
        def boom(req, timeout=None, **kw):
            raise OSError("down")
        with mock.patch("urllib.request.urlopen", boom):
            a = self.agent(VertexClient(_settings())).ask(
                VIEWER, "What is the disaster recovery RTO?")
        self.assertEqual((a.provider, a.status),
                         ("local-fallback", "grounded"))
        self.assertTrue(a.citations)

    def test_no_evidence_never_calls_llm(self):
        with mock.patch("urllib.request.urlopen") as m:
            a = self.agent(VertexClient(_settings())).ask(
                VIEWER, "Policy on quantum teleportation hardware?")
        self.assertEqual(a.status, "insufficient_evidence")
        m.assert_not_called()


if __name__ == "__main__":
    unittest.main()
