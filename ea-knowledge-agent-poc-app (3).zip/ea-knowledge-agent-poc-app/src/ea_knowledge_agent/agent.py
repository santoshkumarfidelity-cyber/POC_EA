"""Knowledge agent: retrieve authorized evidence, sanitize, synthesize,
cite or abstain. Audit events never contain the raw question."""

import hashlib
import json
import logging
import re
import uuid
from datetime import datetime, timezone

from .claude_client import MAX_SOURCES, ClaudeClient
from .guardrails import detect_prompt_injection, sanitize_evidence, \
    validate_answer
from .models import AgentAnswer, Citation, Persona
from .retrieval import _STOP, PermissionAwareRetriever
from .vertex_client import VertexClient

log = logging.getLogger("ea_knowledge_agent")
_SENTENCE_RE = re.compile(r"(?<=[.!?])\s+")
# Every piece of evidence is approved and current, so these words never
# pick out a paragraph (stemmed, as _stems() returns them).
_LIFECYCLE = frozenset({"approv", "curren", "latest", "offici"})


class KnowledgeAgent:
    def __init__(self, conn, claude: ClaudeClient | None = None,
                 vertex: VertexClient | None = None):
        self.conn = conn
        self.retriever = PermissionAwareRetriever(conn)
        self.claude = claude or ClaudeClient()
        self.vertex = vertex or VertexClient()

    def ask(self, persona: Persona, question: str,
            conversation_id: str | None = None) -> AgentAnswer:
        question = (question or "").strip()
        if not question:
            raise ValueError("question must not be empty")
        conv_id = conversation_id or uuid.uuid4().hex
        evidence = self.retriever.search(persona, question,
                                         limit=MAX_SOURCES)
        evidence, warnings = sanitize_evidence(evidence)
        if evidence:   # drop sources far weaker than the best match
            floor = 0.35 * evidence[0]["score"]
            evidence = [e for e in evidence if e["score"] >= floor]
        if not evidence:
            answer = AgentAnswer(
                answer="I could not find current, approved EA content you "
                       "are authorized to see that answers this question. "
                       "Try rephrasing, checking tags, or asking a content "
                       "owner.",
                status="insufficient_evidence", citations=(),
                conversation_id=conv_id, provider="local",
                audit_id=self._audit(persona, question, "local",
                                     "insufficient_evidence", (),
                                     len(warnings)))
            self._persist_conversation(conv_id, persona, question, answer)
            return answer

        provider, text = "local", None
        # LLM preference: Vertex AI, then Claude; fail closed to local.
        for name, client in (("vertex", self.vertex),
                             ("claude", self.claude)):
            if not client.configured:
                continue
            try:
                text = client.synthesize(question, evidence)
                provider = name
                break
            except Exception as exc:
                log.warning("%s synthesis failed: %s", name, exc)
                provider = "local-fallback"
        if text is None:
            text = self._local_synthesis(question, evidence)

        citations = tuple(
            Citation(artifact_id=e["artifact_id"], title=e["title"],
                     version=e["version"], source_url=e["source_url"],
                     excerpt=e["excerpt"])
            for e in evidence[:MAX_SOURCES])
        grounded = validate_answer(text, citations)
        answer = AgentAnswer(
            answer=text if grounded else
            "The retrieved material did not support a defensible cited "
            "answer, so I am abstaining.",
            status="grounded" if grounded else "insufficient_evidence",
            citations=citations if grounded else (),
            conversation_id=conv_id, provider=provider,
            audit_id=self._audit(persona, question, provider,
                                 "grounded" if grounded
                                 else "insufficient_evidence",
                                 citations, len(warnings)))
        self._persist_conversation(conv_id, persona, question, answer)
        return answer

    # ---------------------------------------------------------- internals
    def _local_synthesis(self, question: str,
                         evidence: list[dict]) -> str | None:
        top = evidence[0]
        paras = _paragraphs(top["content_text"])
        # Words in the title match every paragraph, so they don't help pick
        # one; score paragraphs on the rest of the question.
        q_stems = _stems(question) - _stems(top["title"]) - _LIFECYCLE
        scored = sorted(((_para_score(p, q_stems), i) for i, p in
                         enumerate(paras)), key=lambda x: (-x[0], x[1]))
        if scored and scored[0][0] > 0:
            best = scored[0][0]
            # One shared word ("policy") is not an answer: abstain.
            hits = _stems(paras[scored[0][1]]) & q_stems
            if len(hits) < min(2, len(q_stems)):
                return None
            # Rows that tie for best (a list question over a table) all
            # count; otherwise keep a close runner-up.
            idx = [i for s, i in scored if s == best][:4]
            if len(idx) == 1 and len(scored) > 1 \
                    and scored[1][0] >= 0.75 * best:
                idx.append(scored[1][1])
            idx.sort()
            picked = [paras[i] for i in idx]
        else:
            picked = paras[:1]
        body = " ".join(_clip(p) for p in picked)
        others = [f"{e['title']} v{e['version']}" for e in evidence[1:3]
                  if e.get("score", 0) >= 0.6 * top.get("score", 0)]
        related = (f" Related approved material: {'; '.join(others)}."
                   if others else "")
        return (f"Per the governing source {top['title']} v{top['version']}: "
                f"{body}{related}")

    def _persist_conversation(self, conv_id, persona, question, answer):
        cited = json.dumps([c.artifact_id for c in answer.citations])
        now = datetime.now(timezone.utc).isoformat(timespec="seconds")
        self.conn.execute(
            """INSERT INTO conversations
               (id, persona, last_question, last_status, cited_ids_json,
                updated_at) VALUES (?,?,?,?,?,?)
               ON CONFLICT(id) DO UPDATE SET last_question=excluded.
               last_question, last_status=excluded.last_status,
               cited_ids_json=excluded.cited_ids_json,
               updated_at=excluded.updated_at""",
            (conv_id, persona.id, question, answer.status, cited, now))
        self.conn.commit()

    def _audit(self, persona, question, provider, status, citations,
               warning_count):
        aid = uuid.uuid4().hex
        details = {
            "question_hash":
                hashlib.sha256(question.encode()).hexdigest()[:16],
            "provider": provider, "status": status,
            "citation_ids": [c.artifact_id for c in citations],
            "warnings": warning_count,
        }
        self.conn.execute(
            "INSERT INTO audit_events (id, persona, action, resource_id, "
            "details_json, at) VALUES (?,?,?,?,?,?)",
            (aid, persona.id, "agent_query", "",
             json.dumps(details),
             datetime.now(timezone.utc).isoformat(timespec="seconds")))
        self.conn.commit()
        return aid


def _stem(word: str) -> str:
    w = word.lower()
    for suf in ("ing", "ed", "es", "s"):
        if w.endswith(suf) and len(w) - len(suf) >= 3:
            w = w[:-len(suf)]
            break
    return w[:6].rstrip("e") if len(w) > 3 else w   # retire(d) -> retir


def _stems(text: str) -> set[str]:
    return {_stem(t) for t in re.findall(r"[A-Za-z]{3,}|\d+", text)
            if t.lower() not in _STOP}


def _paragraphs(text: str) -> list[str]:
    """Rejoin hard-wrapped lines (PDF), then drop headings: markdown '#'
    lines and short lines without sentence punctuation."""
    paras: list[str] = []
    for ln in (l.strip() for l in text.splitlines()):
        if not ln:
            continue
        if paras and paras[-1][-1] not in ".!?:" and ln[0].islower():
            paras[-1] += " " + ln
        else:
            paras.append(ln)
    out = []
    for p in paras:
        p = re.sub(r"^[-*•]\s+", "", p).replace("**", "")
        if p.startswith("#") or (p[-1] not in ".!?"
                                 and len(p.split()) < 6):
            continue
        out.append(p.strip())
    return out


def _para_score(para: str, q_stems: set[str]) -> float:
    hits = _stems(para) & q_stems
    if not hits:
        return 0.0
    score = float(len(hits))
    label, sep, _ = para.partition(":")   # "Claims records: 10 years…"
    if sep and len(label.split()) <= 5:
        score += len(_stems(label) & q_stems)
    return score + (0.5 if re.search(r"\d", para) else 0)


def _clip(para: str, limit: int = 420) -> str:
    """Whole sentences up to about `limit` characters."""
    out = ""
    for s in _SENTENCE_RE.split(para):
        if out and len(out) + len(s) > limit:
            break
        out += (" " if out else "") + s
    return out if out[-1] in ".!?" else out + "."


# keep injection detector importable for callers/tests
_ = detect_prompt_injection
