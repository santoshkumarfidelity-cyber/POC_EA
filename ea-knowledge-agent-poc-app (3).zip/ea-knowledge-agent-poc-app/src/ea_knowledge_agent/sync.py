"""CLI: index EA documents into the knowledge base.

  python -m ea_knowledge_agent.sync                 # SharePoint (Graph env)
  python -m ea_knowledge_agent.sync --folder docs/  # local folder
"""

import argparse
import os
import sys

from .config import load_settings
from .database import connect, initialize
from .ingest import DocumentIngestor, sync_folder, sync_sharepoint
from .sharepoint_connector import SharePointConnector


def main(argv=None) -> int:
    s = load_settings()
    ap = argparse.ArgumentParser(prog="ea_knowledge_agent.sync")
    ap.add_argument("--db", default=s.db_path)
    ap.add_argument("--reset", action="store_true",
                    help="delete the database first (drops the synthetic "
                         "demo data)")
    ap.add_argument("--folder", help="index a local folder instead of "
                                     "SharePoint")
    args = ap.parse_args(argv)
    if args.reset and os.path.exists(args.db):
        os.remove(args.db)
    conn = connect(args.db)
    initialize(conn)
    ing = DocumentIngestor(conn, s)
    if args.folder:
        stats = sync_folder(ing, args.folder)
    else:
        sp = SharePointConnector(s)
        if not sp.configured:
            print("SharePoint is not configured. Set GRAPH_TENANT_ID, "
                  "GRAPH_CLIENT_ID, GRAPH_CLIENT_SECRET, SHAREPOINT_SITE_ID "
                  "and SHAREPOINT_DRIVE_ID, or pass --folder PATH.",
                  file=sys.stderr)
            return 2
        stats = sync_sharepoint(ing, sp)
    notes = stats.pop("notes")
    print("sync complete: " + ", ".join(f"{k}={v}" for k, v in
                                        stats.items()))
    for n in notes[:20]:
        print("  " + n)
    return 1 if stats["failed"] else 0


if __name__ == "__main__":
    sys.exit(main())
