"""Chat history: one row per chat in `chats`, one row per question or
answer in `chat_messages`. Every read is scoped to the persona that owns
the chat, so one user never sees another's history. Answers keep their
single citation, so a reopened chat shows the same source link."""

import json
import uuid
from datetime import datetime, timezone

TITLE_LEN = 80
HISTORY_MESSAGES = 6        # the last 3 question/answer pairs go to the LLM
_ANSWER_CLIP = 1500         # long answers are shortened in that history


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _title(question: str) -> str:
    q = " ".join(question.split())
    return q if len(q) <= TITLE_LEN else q[:TITLE_LEN - 1].rstrip() + "…"


class ChatStore:
    def __init__(self, conn):
        self.conn = conn

    def create(self, persona_id: str, first_question: str) -> str:
        cid, now = uuid.uuid4().hex, _now()
        self.conn.execute(
            "INSERT INTO chats (id, persona, title, created_at, updated_at) "
            "VALUES (?,?,?,?,?)",
            (cid, persona_id, _title(first_question), now, now))
        return cid

    def get(self, persona_id: str, chat_id: str) -> dict | None:
        """The chat, or None if it doesn't exist or belongs to someone
        else (the two cases look the same to the caller)."""
        row = self.conn.execute(
            "SELECT id, title, created_at, updated_at FROM chats "
            "WHERE id=? AND persona=?", (chat_id or "", persona_id)).fetchone()
        return dict(row) if row else None

    def list_chats(self, persona_id: str, limit: int = 50) -> list[dict]:
        return [dict(r) for r in self.conn.execute(
            "SELECT id, title, updated_at FROM chats WHERE persona=? "
            "ORDER BY updated_at DESC, rowid DESC LIMIT ?",
            (persona_id, limit))]

    def messages(self, chat_id: str) -> list[dict]:
        out = []
        for r in self.conn.execute(
                "SELECT role, content, status, provider, citation_json, "
                "created_at FROM chat_messages WHERE chat_id=? ORDER BY seq",
                (chat_id,)):
            m = dict(r)
            m["citation"] = json.loads(m.pop("citation_json") or "null")
            out.append(m)
        return out

    def history(self, chat_id: str) -> list[dict]:
        """The last few turns for the LLM: [{"role", "content"}]."""
        rows = self.conn.execute(
            "SELECT role, content FROM chat_messages WHERE chat_id=? "
            "ORDER BY seq DESC LIMIT ?",
            (chat_id, HISTORY_MESSAGES)).fetchall()[::-1]
        return [{"role": r["role"],
                 "content": r["content"] if r["role"] == "user"
                 else r["content"][:_ANSWER_CLIP]} for r in rows]

    def last_cited_family(self, chat_id: str) -> str:
        row = self.conn.execute(
            "SELECT citation_json FROM chat_messages WHERE chat_id=? AND "
            "role='assistant' AND citation_json IS NOT NULL "
            "ORDER BY seq DESC LIMIT 1", (chat_id,)).fetchone()
        return (json.loads(row[0]) or {}).get("family_id", "") if row else ""

    def rename(self, persona_id: str, chat_id: str, title: str) -> bool:
        """False if the chat doesn't exist or belongs to someone else.
        The chat keeps its place in the list (updated_at is unchanged)."""
        if not " ".join((title or "").split()):
            raise ValueError("title must not be empty")
        cur = self.conn.execute(
            "UPDATE chats SET title=? WHERE id=? AND persona=?",
            (_title(title), chat_id or "", persona_id))
        return cur.rowcount == 1

    def delete(self, persona_id: str, chat_id: str) -> bool:
        """Removes the chat and all its messages for good. False if the
        chat doesn't exist or belongs to someone else."""
        if not self.get(persona_id, chat_id):
            return False
        self.conn.execute("DELETE FROM chat_messages WHERE chat_id=?",
                          (chat_id,))
        self.conn.execute("DELETE FROM chats WHERE id=?", (chat_id,))
        return True

    def add(self, chat_id: str, role: str, content: str, status: str = None,
            provider: str = None, citation: dict | None = None) -> None:
        now = _now()
        seq = self.conn.execute(
            "SELECT COALESCE(MAX(seq), 0) + 1 FROM chat_messages "
            "WHERE chat_id=?", (chat_id,)).fetchone()[0]
        self.conn.execute(
            "INSERT INTO chat_messages (id, chat_id, seq, role, content, "
            "status, provider, citation_json, created_at) "
            "VALUES (?,?,?,?,?,?,?,?,?)",
            (uuid.uuid4().hex, chat_id, seq, role, content, status,
             provider, json.dumps(citation) if citation else None, now))
        self.conn.execute("UPDATE chats SET updated_at=? WHERE id=?",
                          (now, chat_id))
