"""Version history: how many versions a document keeps, the next version
number, and what changed between two versions (a line diff of the
extracted text). Pruning never removes the current approved version or
working (DRAFT/REVIEW) content."""

import difflib
import re

from .models import LifecycleStatus

_PROTECTED = (LifecycleStatus.DRAFT.value, LifecycleStatus.REVIEW.value)
_MAX_DIFF_LINES = 400       # diff lines returned to the browser
_MAX_INPUT_LINES = 20000    # per side, keeps difflib fast on huge decks


def prune_family(conn, family_id: str, keep: int) -> int:
    """Delete the oldest SUPERSEDED/ARCHIVED versions of a family until at
    most `keep` versions remain. The caller commits. Returns how many
    versions were removed."""
    rows = conn.execute(
        "SELECT id, lifecycle_status, is_current_approved "
        "FROM artifact_versions WHERE family_id=? "
        "ORDER BY uploaded_at DESC, rowid DESC", (family_id,)).fetchall()
    removable = [r["id"] for r in rows
                 if not r["is_current_approved"]
                 and r["lifecycle_status"] not in _PROTECTED]
    excess = len(rows) - max(keep, 1)
    doomed = removable[::-1][:max(excess, 0)]   # oldest first
    for vid in doomed:
        for table in ("artifact_tags", "artifact_acl_groups",
                      "lifecycle_events", "artifact_chunks"):
            conn.execute(f"DELETE FROM {table} WHERE version_id=?", (vid,))
        try:
            conn.execute("DELETE FROM artifact_fts WHERE version_id=?",
                         (vid,))
        except Exception:
            pass
        conn.execute("DELETE FROM artifact_versions WHERE id=?", (vid,))
    return len(doomed)


def next_version(conn, family_id: str) -> str:
    """One more than the highest major version in the family ("4.2" ->
    "5.0"), so numbers are never reused after old versions are pruned."""
    majors = [int(m.group()) for (v,) in conn.execute(
        "SELECT version FROM artifact_versions WHERE family_id=?",
        (family_id,)) if (m := re.match(r"\d+", v or ""))]
    return f"{max(majors, default=0) + 1}.0"


def diff_text(old: str, new: str) -> dict:
    """Line diff of two versions' extracted text.
    lines: [{"op": "add" | "del" | "same" | "gap", "text": ...}]"""
    a = (old or "").splitlines()[:_MAX_INPUT_LINES]
    b = (new or "").splitlines()[:_MAX_INPUT_LINES]
    added = removed = 0
    lines = []
    for group in difflib.SequenceMatcher(None, a, b, autojunk=False) \
            .get_grouped_opcodes(2):
        if lines:
            lines.append({"op": "gap", "text": "…"})
        for tag, i1, i2, j1, j2 in group:
            if tag == "equal":
                lines += [{"op": "same", "text": t} for t in a[i1:i2]]
                continue
            removed += i2 - i1
            added += j2 - j1
            lines += [{"op": "del", "text": t} for t in a[i1:i2]]
            lines += [{"op": "add", "text": t} for t in b[j1:j2]]
    return {"added": added, "removed": removed,
            "identical_text": a == b,
            "truncated": len(lines) > _MAX_DIFF_LINES,
            "lines": lines[:_MAX_DIFF_LINES]}
