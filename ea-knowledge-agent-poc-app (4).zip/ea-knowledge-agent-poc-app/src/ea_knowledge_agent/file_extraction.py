"""Standard-library file text extraction for the POC.

Supported now: TXT/MD (UTF-8), DOCX (word/document.xml), PPTX (ordered
slide XML inside the zip), XLSX (sheet XML). PDF needs the optional
`pypdf` package; JPG/PNG need the optional `rapidocr` + `onnxruntime` OCR
packages. Visio, GIF and SVG return explicit warnings — we do not pretend
content was parsed."""

import io
import re
import xml.etree.ElementTree as ET
import zipfile

_NS_W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
_NS_A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
_NS_S = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
_NS_R = ("{http://schemas.openxmlformats.org/officeDocument/2006/"
         "relationships}id")
_NS_PR = "{http://schemas.openxmlformats.org/package/2006/relationships}"
MAX_SHEET_ROWS = 5000
_ocr_engine = None


def extract_text(filename: str, data: bytes) -> tuple[str, list[str]]:
    """Return (text, warnings). Empty text with warnings = not extracted."""
    name = (filename or "").lower()
    ext = name.rsplit(".", 1)[-1] if "." in name else ""
    if ext in ("txt", "md"):
        return data.decode("utf-8", errors="replace"), []
    if ext == "docx":
        return _docx(data)
    if ext == "pptx":
        return _pptx(data)
    if ext == "pdf":
        return _pdf(data)
    if ext == "xlsx":
        return _xlsx(data)
    if ext in ("jpg", "jpeg", "png"):
        return _image(data)
    if ext in ("vsdx", "vsd", "gif", "svg"):
        return "", [f"{ext.upper()} text extraction is pending a "
                    "production parser; metadata was registered but the "
                    "file body was not indexed."]
    return "", [f"Unsupported file type '.{ext}'; registered metadata "
                "only."]


def _docx(data: bytes) -> tuple[str, list[str]]:
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            xml = z.read("word/document.xml")
    except (zipfile.BadZipFile, KeyError):
        return "", ["DOCX container could not be read."]
    root = ET.fromstring(xml)
    paras = []
    for p in root.iter(_NS_W + "p"):
        text = "".join(t.text or "" for t in p.iter(_NS_W + "t"))
        if text.strip():
            paras.append(text.strip())
    return "\n".join(paras), []


def _pptx(data: bytes) -> tuple[str, list[str]]:
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            slide_names = sorted(
                (n for n in z.namelist()
                 if re.fullmatch(r"ppt/slides/slide\d+\.xml", n)),
                key=lambda n: int(re.search(r"(\d+)", n).group(1)))
            texts = []
            for n in slide_names:
                root = ET.fromstring(z.read(n))
                paras = ["".join(e.text or "" for e in p.iter(_NS_A + "t"))
                         .strip() for p in root.iter(_NS_A + "p")]
                paras = [p for p in paras if p] or [" ".join(
                    e.text or "" for e in root.iter(_NS_A + "t")).strip()]
                paras = [p for p in paras if p]
                # One line per slide: "Title: bullet; bullet."
                if len(paras) > 1:
                    body = "; ".join(paras[1:])
                    texts.append(paras[0] + ": " + body
                                 + ("" if body[-1] in ".!?" else "."))
                elif paras:
                    texts.append(paras[0])
    except (zipfile.BadZipFile, ET.ParseError):
        return "", ["PPTX container could not be read."]
    return "\n".join(texts), []


def _pdf(data: bytes) -> tuple[str, list[str]]:
    """PDF text via the optional `pypdf` package (pip install pypdf)."""
    try:
        from pypdf import PdfReader
    except ImportError:
        return "", ["PDF text extraction needs the optional 'pypdf' "
                    "package (pip install pypdf); metadata registered, "
                    "body not indexed."]
    try:
        reader = PdfReader(io.BytesIO(data))
        pages = [_unwrap((pg.extract_text() or "").strip())
                 for pg in reader.pages]
    except Exception:
        return "", ["PDF could not be read."]
    text = "\n\n".join(t for t in pages if t)
    if not text:
        return "", ["PDF has no extractable text (scanned image?)."]
    return text, []


def _unwrap(page: str) -> str:
    """Rejoin lines the PDF wrapped at the page margin: a line almost as
    long as the page's longest one continues on the next line."""
    lines = [ln.rstrip() for ln in page.splitlines()]
    width = max((len(ln) for ln in lines), default=0)
    out: list[str] = []
    prev = ""
    for ln in lines:
        heading = ln and ln[-1] not in ".!?:" and len(ln.split()) < 6
        if out and prev and ln and not heading and len(prev) >= 0.8 * width:
            out[-1] += " " + ln.strip()
        else:
            out.append(ln)
        prev = ln
    return "\n".join(out)


def _xlsx(data: bytes) -> tuple[str, list[str]]:
    """One line per row, labelled by the sheet's header row:
    "Application: ClaimCenter; Owner: Sofia Marquez." Formulas give their
    last saved value; dates appear as Excel serial numbers."""
    warnings = []
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            names = set(z.namelist())
            shared = []
            if "xl/sharedStrings.xml" in names:
                for si in ET.fromstring(z.read("xl/sharedStrings.xml")
                                        ).iter(_NS_S + "si"):
                    shared.append("".join(t.text or "" for t in
                                          si.iter(_NS_S + "t")))
            rels = {r.get("Id"): r.get("Target") for r in ET.fromstring(
                z.read("xl/_rels/workbook.xml.rels")).iter(
                    _NS_PR + "Relationship")}
            out = []
            for sh in ET.fromstring(z.read("xl/workbook.xml")).iter(
                    _NS_S + "sheet"):
                target = rels.get(sh.get(_NS_R), "").lstrip("/")
                path = target if target.startswith("xl/") else \
                    "xl/" + target
                if path not in names:
                    continue
                rows = _sheet_rows(ET.fromstring(z.read(path)), shared)
                if len(rows) > MAX_SHEET_ROWS:
                    warnings.append(f"Sheet '{sh.get('name')}' truncated "
                                    f"to {MAX_SHEET_ROWS} rows.")
                    rows = rows[:MAX_SHEET_ROWS]
                if not rows:
                    continue
                out.append(f"Sheet {sh.get('name')}.")
                header = rows[0]
                for row in rows[1:] if len(rows) > 1 else rows:
                    cells = [(header.get(c) if len(rows) > 1 else None, v)
                             for c, v in sorted(row.items())]
                    line = "; ".join(f"{h}: {v}" if h else v
                                     for h, v in cells)
                    out.append(line if line[-1] in ".!?" else line + ".")
    except (zipfile.BadZipFile, KeyError, ET.ParseError):
        return "", ["XLSX container could not be read."]
    return "\n".join(out), warnings


def _sheet_rows(root, shared: list[str]) -> list[dict[int, str]]:
    """Non-empty rows as {column index: text}."""
    rows = []
    for r in root.iter(_NS_S + "row"):
        row = {}
        for i, c in enumerate(r.iter(_NS_S + "c")):
            t = c.get("t")
            if t == "inlineStr":
                val = "".join(x.text or "" for x in c.iter(_NS_S + "t"))
            else:
                v = c.find(_NS_S + "v")
                val = v.text if v is not None and v.text else ""
                if t == "s" and val.isdigit() and int(val) < len(shared):
                    val = shared[int(val)]
                elif t == "b":
                    val = "TRUE" if val == "1" else "FALSE"
            val = re.sub(r"\s+", " ", val).strip()
            if val:
                row[_col(c.get("r")) if c.get("r") else i] = val
        if row:
            rows.append(row)
    return rows


def _col(ref: str) -> int:
    """'C12' -> 2"""
    n = 0
    for ch in re.match(r"[A-Z]*", ref.upper()).group(0):
        n = n * 26 + ord(ch) - 64
    return n - 1


def _image(data: bytes) -> tuple[str, list[str]]:
    """OCR via the optional `rapidocr` + `onnxruntime` packages
    (pip install rapidocr onnxruntime)."""
    global _ocr_engine
    try:
        from rapidocr import RapidOCR
    except ImportError:
        return "", ["Image text extraction needs the optional 'rapidocr' "
                    "and 'onnxruntime' packages (pip install rapidocr "
                    "onnxruntime); metadata registered, body not indexed."]
    try:
        if _ocr_engine is None:
            _ocr_engine = RapidOCR(params={"Global.log_level": "warning"})
        lines = [t.strip() for t in (_ocr_engine(data).txts or ())
                 if t.strip()]
    except Exception:
        return "", ["Image could not be read by OCR."]
    if not lines:
        return "", ["No text found in the image."]
    # OCR lines rarely end in punctuation; add it so each line reads as a
    # statement rather than a heading.
    return "\n".join(ln if ln[-1] in ".!?:" else ln + "."
                     for ln in lines), []
