"""Document ingestion for synced content (SharePoint or a local folder).

Phase 1 assumption: documents are approved manually at the source before
they reach this app, so synced items are stored as APPROVED + current with
no in-app review step. Re-syncing is idempotent: unchanged files are
skipped, changed files become a new current version (the previous one is
SUPERSEDED), and files that disappeared from the source are ARCHIVED."""

import hashlib
import mimetypes
import os
import pathlib
import re
import urllib.parse
import urllib.request
import uuid
from datetime import datetime, timezone

from .config import load_settings
from .file_extraction import extract_text
from .models import LifecycleStatus, Persona
from .versions import next_version, prune_family

SYNC_ACTOR = Persona("sync", "Document Sync", "System", ())
SUPPORTED = {"txt", "md", "docx", "pptx", "pdf", "xlsx", "jpg", "jpeg",
             "png"}
CONTRIBUTOR = "document-sync"   # marks families owned by the sync


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _title_from(filename: str) -> str:
    """'ARB_Submission-Template.docx' -> 'ARB Submission Template'
    (underscores would otherwise make the title a single search token)."""
    stem = os.path.splitext(filename)[0]
    return re.sub(r"[\s_]+", " ", stem.replace("-", " ")).strip() or stem


def file_uri(path: str) -> str:
    """'C:\\Docs\\a b.md' -> 'file:///C:/Docs/a%20b.md' (works on any OS)."""
    return pathlib.Path(os.path.abspath(path)).as_uri()


def local_path(url: str) -> str | None:
    """Inverse of file_uri(); also reads the older 'file://' + quoted-path
    form. None for non-file URLs."""
    if url.startswith("file:///"):
        return urllib.request.url2pathname(urllib.parse.urlparse(url).path)
    if url.startswith("file://"):
        return urllib.parse.unquote(url[len("file://"):])
    return None


def _tag(s: str) -> str:
    return re.sub(r"[^A-Z0-9]+", "_", s.upper()).strip("_")[:40]


class DocumentIngestor:
    def __init__(self, conn, settings=None):
        self.conn = conn
        self.s = settings or load_settings()

    # ------------------------------------------------------------ public
    def upsert(self, *, source_url: str, title: str, data: bytes,
               filename: str, owner: str = "", folders: tuple = (),
               modified: str = "") -> tuple[str, str]:
        """Returns (action, detail). action: added | updated | unchanged |
        duplicate | skipped."""
        ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
        if ext not in SUPPORTED:
            return "skipped", f"unsupported type .{ext}"
        if len(data) > self.s.sync_max_mb * 1024 * 1024:
            return "skipped", (f"file larger than {self.s.sync_max_mb} MB "
                               "(raise SYNC_MAX_MB)")
        text, warnings = extract_text(filename, data)
        if not text.strip():
            return "skipped", (warnings or ["no text extracted"])[0]
        chash = hashlib.sha256(data).hexdigest()
        row = self.conn.execute(
            "SELECT v.id, v.family_id, v.content_hash FROM "
            "artifact_versions v WHERE v.source_url=? AND "
            "v.is_current_approved=1", (source_url,)).fetchone()
        if row and row["content_hash"] == chash:
            return "unchanged", ""
        if not row:
            dup = self.conn.execute(
                "SELECT 1 FROM artifact_versions WHERE content_hash=?",
                (chash,)).fetchone()
            if dup:
                return "duplicate", "same content already indexed"
        meta = self._metadata(title, text, ext, folders, owner)
        if row:
            version = next_version(self.conn, row["family_id"])
            self._supersede(row["id"])
            self._insert_version(row["family_id"], version, meta, text,
                                 chash, source_url, modified)
            prune_family(self.conn, row["family_id"], self.s.max_versions)
            self.conn.commit()
            return "updated", f"v{version}"
        fam = uuid.uuid4().hex
        now = _now()
        self.conn.execute(
            """INSERT INTO artifact_families
               (id, title, segment, domain, content_type, audience, owner,
                contributor, created_at, current_version_id)
               VALUES (?,?,?,?,?,?,?,?,?,NULL)""",
            (fam, meta["title"], meta["segment"], meta["domain"],
             meta["content_type"], meta["audience"], meta["owner"],
             CONTRIBUTOR, now))
        self._insert_version(fam, "1.0", meta, text, chash, source_url,
                             modified)
        self.conn.commit()
        return "added", "v1.0"

    def archive_missing(self, seen_urls: set[str]) -> int:
        """Archive synced documents whose source file no longer exists."""
        rows = self.conn.execute(
            """SELECT v.id, v.source_url FROM artifact_versions v
               JOIN artifact_families f ON f.id = v.family_id
               WHERE f.contributor=? AND v.is_current_approved=1""",
            (CONTRIBUTOR,)).fetchall()
        gone = [r for r in rows if r["source_url"] not in seen_urls]
        for r in gone:
            self._supersede(r["id"], LifecycleStatus.ARCHIVED.value,
                            "removed from source")
        self.conn.commit()
        return len(gone)

    # ---------------------------------------------------------- internals
    def _metadata(self, title, text, ext, folders, owner) -> dict:
        folders = [f for f in folders if f]
        desc = re.sub(r"\s+", " ", text).strip()[:220]
        tags = {"SYNCED", ext.upper()} | {_tag(f) for f in folders if _tag(f)}
        return {
            "title": title[:200], "description": desc,
            "segment": self.s.sync_segment.upper(),
            "domain": _tag(folders[0]) if folders else "GENERAL",
            "content_type": "DOCUMENT",
            "audience": self.s.sync_audience.upper(),
            "owner": owner or "unassigned", "tags": sorted(tags),
        }

    def _insert_version(self, fam, version, meta, text, chash, url,
                        modified):
        vid, now = uuid.uuid4().hex, _now()
        self.conn.execute(
            """INSERT INTO artifact_versions
               (id, family_id, version, description, lifecycle_status,
                review_date, uploaded_at, updated_at, source_url,
                content_hash, content_text, extraction_status,
                is_current_approved) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,1)""",
            (vid, fam, version, meta["description"],
             LifecycleStatus.APPROVED.value, None, modified or now, now,
             url, chash, text, "EXTRACTED"))
        for t in meta["tags"]:
            self.conn.execute(
                "INSERT INTO artifact_tags (version_id, tag) VALUES (?,?)",
                (vid, t))
        for g in self.s.sync_allowed_groups:
            self.conn.execute(
                "INSERT INTO artifact_acl_groups (version_id, grp) "
                "VALUES (?,?)", (vid, g))
        self.conn.execute(
            """INSERT INTO lifecycle_events (id, version_id, from_status,
               to_status, actor_persona, note, at) VALUES (?,?,?,?,?,?,?)""",
            (uuid.uuid4().hex, vid, None, LifecycleStatus.APPROVED.value,
             SYNC_ACTOR.id, "approved at source; synced", now))
        self.conn.execute(
            "UPDATE artifact_families SET current_version_id=?, title=? "
            "WHERE id=?", (vid, meta["title"], fam))
        try:
            self.conn.execute(
                "INSERT INTO artifact_fts (version_id, title, description, "
                "content_text, tags_text) VALUES (?,?,?,?,?)",
                (vid, meta["title"], meta["description"], text,
                 " ".join(meta["tags"])))
        except Exception:
            pass

    def _supersede(self, vid, status=None, note="superseded by new version"):
        status = status or LifecycleStatus.SUPERSEDED.value
        now = _now()
        self.conn.execute(
            "UPDATE artifact_versions SET lifecycle_status=?, "
            "is_current_approved=0, updated_at=? WHERE id=?",
            (status, now, vid))
        self.conn.execute(
            """INSERT INTO lifecycle_events (id, version_id, from_status,
               to_status, actor_persona, note, at) VALUES (?,?,?,?,?,?,?)""",
            (uuid.uuid4().hex, vid, LifecycleStatus.APPROVED.value, status,
             SYNC_ACTOR.id, note, now))


# ------------------------------------------------------------- sources
def sync_folder(ingestor: DocumentIngestor, folder: str) -> dict:
    """Index every supported file under a local folder."""
    root = os.path.abspath(folder)
    stats, seen = _stats(), set()
    for dirpath, _, files in os.walk(root):
        for name in sorted(files):
            full = os.path.join(dirpath, name)
            rel = os.path.relpath(full, root)
            url = file_uri(full)
            seen.add(url)
            try:
                with open(full, "rb") as fh:
                    data = fh.read()
                action, detail = ingestor.upsert(
                    source_url=url, title=_title_from(name),
                    data=data, filename=name,
                    folders=tuple(rel.split(os.sep)[:-1]))
            except OSError as exc:
                action, detail = "skipped", str(exc)
            _record(stats, action, rel, detail)
    stats["archived"] = ingestor.archive_missing(seen)
    return stats


def sync_sharepoint(ingestor: DocumentIngestor, connector) -> dict:
    """Index every supported file in the configured SharePoint drive."""
    stats, seen = _stats(), set()
    for item in connector.list_files():
        name = item.get("name", "")
        url = item.get("webUrl", "")
        if not url:
            continue
        seen.add(url)
        ext = name.rsplit(".", 1)[-1].lower() if "." in name else ""
        if ext not in SUPPORTED:
            _record(stats, "skipped", name, f"unsupported type .{ext}")
            continue
        try:
            ref = item.get("parentReference", {})
            data = connector.download_item(
                ref.get("driveId") or ingestor.s.sharepoint_drive_id,
                item["id"])
            path = urllib.parse.unquote(ref.get("path", "")).split(
                "root:", 1)[-1]
            who = (item.get("lastModifiedBy") or item.get("createdBy")
                   or {}).get("user", {}).get("displayName", "")
            action, detail = ingestor.upsert(
                source_url=url, title=_title_from(name),
                data=data, filename=name, owner=who,
                folders=tuple(p for p in path.split("/") if p),
                modified=item.get("lastModifiedDateTime", ""))
        except Exception as exc:
            action, detail = "failed", str(exc)
        _record(stats, action, name, detail)
    if not stats["failed"]:   # never archive on a partially failed sync
        stats["archived"] = ingestor.archive_missing(seen)
    return stats


def _stats() -> dict:
    return {"added": 0, "updated": 0, "unchanged": 0, "duplicate": 0,
            "skipped": 0, "failed": 0, "archived": 0, "notes": []}


def _record(stats, action, name, detail):
    stats[action] += 1
    if action in ("skipped", "duplicate", "failed") and detail:
        stats["notes"].append(f"{action}: {name} - {detail}")
