"""Semantic index: every current approved version is split into the same
passages retrieval uses, each embedded with Vertex AI and stored in
artifact_chunks. Run by `make sync`, or on its own:

  python -m ea_knowledge_agent.embeddings                 # embed what is missing
  python -m ea_knowledge_agent.embeddings --probe "How long do we keep claims data?"
"""

import argparse
import math
import sys
from array import array

from .auth import get_persona
from .config import load_settings
from .database import connect, initialize
from .retrieval import PermissionAwareRetriever, _chunks, unpack
from .vertex_client import VertexEmbedder


def pack(vec) -> bytes:
    """float32 bytes of the vector scaled to unit length, so a dot product
    is the cosine similarity."""
    norm = math.sqrt(sum(x * x for x in vec)) or 1.0
    return array("f", (x / norm for x in vec)).tobytes()


def index_missing(conn, embedder: VertexEmbedder, progress=None) -> dict:
    """Embed current approved versions that have no chunks for the
    configured model, and drop chunks of versions that are no longer
    current (or of another model). Stops at the first Vertex failure."""
    model = embedder.model
    rows = conn.execute(
        """SELECT v.id, f.title, v.content_text
           FROM artifact_versions v
           JOIN artifact_families f ON f.id = v.family_id
           WHERE v.is_current_approved = 1
             AND v.lifecycle_status = 'APPROVED'
             AND NOT EXISTS (SELECT 1 FROM artifact_chunks c
                             WHERE c.version_id = v.id
                               AND c.embed_model = ?)""",
        (model,)).fetchall()
    stats = {"documents": 0, "chunks": 0, "error": ""}
    for r in rows:
        chunks = _chunks(r["content_text"])
        if not chunks:
            continue
        try:
            vecs = embedder.embed(chunks, "RETRIEVAL_DOCUMENT",
                                  title=r["title"])
        except Exception as exc:
            stats["error"] = f"{r['title']}: {exc}"
            break
        conn.executemany(
            "INSERT INTO artifact_chunks (version_id, embed_model, "
            "chunk_index, chunk_text, embedding) VALUES (?,?,?,?,?)",
            [(r["id"], model, i, c, pack(v))
             for i, (c, v) in enumerate(zip(chunks, vecs))])
        conn.commit()
        stats["documents"] += 1
        stats["chunks"] += len(chunks)
        if progress:
            progress(f"  embedded {r['title']} ({len(chunks)} chunks)")
    conn.execute(
        """DELETE FROM artifact_chunks
           WHERE embed_model != ?
              OR version_id NOT IN (SELECT id FROM artifact_versions
                                    WHERE is_current_approved = 1)""",
        (model,))
    conn.commit()
    return stats


def main(argv=None) -> int:
    s = load_settings()
    ap = argparse.ArgumentParser(prog="ea_knowledge_agent.embeddings")
    ap.add_argument("--db", default=s.db_path)
    ap.add_argument("--probe", metavar="QUESTION",
                    help="show each matching document's keyword score and "
                         "similarity instead of indexing")
    ap.add_argument("--persona", default="consumer")
    args = ap.parse_args(argv)
    embedder = VertexEmbedder(s)
    if not embedder.configured:
        print("Embeddings are off: set VERTEX_PROJECT and "
              "VERTEX_EMBED_MODEL (e.g. text-embedding-005).",
              file=sys.stderr)
        return 2
    conn = connect(args.db)
    initialize(conn)
    if args.probe:
        hits = PermissionAwareRetriever(conn, embedder).search(
            get_persona(args.persona), args.probe, limit=10)
        print(f"model={embedder.model} "
              f"min_similarity={embedder.min_similarity}")
        for h in hits:
            print(f"  score={h['score']:<6} similarity="
                  f"{h['similarity']:<6} {h['title']}")
        if not hits:
            print("  no document reaches the score cut-off")
        return 0
    stats = index_missing(conn, embedder, progress=print)
    print(f"embeddings: model={embedder.model}, "
          f"documents={stats['documents']}, chunks={stats['chunks']}")
    if stats["error"]:
        print(f"  stopped: {stats['error']}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
