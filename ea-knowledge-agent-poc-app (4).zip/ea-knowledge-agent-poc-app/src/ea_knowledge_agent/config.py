"""Configuration: environment variables, plus an optional `.env` file in
the project folder. No secrets are stored in code."""

import os
from dataclasses import dataclass

_APP_ROOT = os.path.abspath(os.path.join(
    os.path.dirname(__file__), os.pardir, os.pardir))


@dataclass(frozen=True)
class Settings:
    host: str = "127.0.0.1"
    port: int = 8765
    db_path: str = "data/poc.db"
    web_dir: str = os.path.join(_APP_ROOT, "web")
    # Delivery phase: 1 = internal viewer (Ask + Discover, approved content
    # only); 2 adds audit/quality; 3 adds supporting services.
    phase: int = 1

    anthropic_api_key: str | None = None
    claude_model: str | None = None

    # Google Vertex AI (Gemini) answer generation
    vertex_project: str | None = None
    vertex_location: str = "us-central1"
    vertex_model: str | None = None
    vertex_access_token: str | None = None  # else `gcloud auth print-access-token`
    # Vertex AI embeddings for semantic retrieval (off when unset)
    vertex_embed_model: str | None = None
    vertex_embed_min_sim: float = 0.60  # cosine below this is not a match

    # Defaults applied to documents synced from SharePoint / a folder
    sync_allowed_groups: tuple[str, ...] = ("EA_ALL", "EA_INSURANCE")
    sync_segment: str = "EA"
    sync_audience: str = "INTERNAL"
    sync_max_mb: int = 200   # larger files are skipped by the sync
    max_versions: int = 5    # versions kept per document (oldest dropped)

    graph_tenant_id: str | None = None
    graph_client_id: str | None = None
    graph_client_secret: str | None = None
    sharepoint_site_id: str | None = None
    sharepoint_drive_id: str | None = None


def read_env_file(path: str) -> dict[str, str]:
    """KEY=VALUE lines; blank lines, '#' comments and empty values are
    skipped, an 'export ' prefix and surrounding quotes are removed."""
    values: dict[str, str] = {}
    try:
        with open(path, encoding="utf-8-sig") as fh:
            lines = fh.read().splitlines()
    except OSError:
        return values
    for line in lines:
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, val = line.removeprefix("export ").partition("=")
        key, val = key.strip(), val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in "\"'":
            val = val[1:-1]
        elif " #" in val:                       # inline comment
            val = val.split(" #", 1)[0].rstrip()
        if key and val:
            values[key] = val
    return values


def load_settings() -> Settings:
    # Read on every call, so edits to .env (e.g. a fresh
    # VERTEX_ACCESS_TOKEN) apply without a restart. Variables set in the
    # shell win over the file.
    env = {**read_env_file(os.path.join(_APP_ROOT, ".env")), **os.environ}
    return Settings(
        host=env.get("POC_HOST", "127.0.0.1"),
        port=int(env.get("POC_PORT", "8765")),
        db_path=env.get("POC_DB", "data/poc.db"),
        web_dir=env.get("POC_WEB_DIR") or os.path.join(_APP_ROOT, "web"),
        phase=int(env.get("POC_PHASE", "1")),
        anthropic_api_key=env.get("ANTHROPIC_API_KEY") or None,
        claude_model=env.get("CLAUDE_MODEL") or None,
        vertex_project=env.get("VERTEX_PROJECT") or None,
        vertex_location=env.get("VERTEX_LOCATION") or "us-central1",
        vertex_model=env.get("VERTEX_MODEL") or None,
        vertex_access_token=env.get("VERTEX_ACCESS_TOKEN") or None,
        vertex_embed_model=env.get("VERTEX_EMBED_MODEL") or None,
        vertex_embed_min_sim=float(env.get("VERTEX_EMBED_MIN_SIM", "0.60")),
        sync_allowed_groups=tuple(
            g.strip() for g in env.get(
                "SYNC_ALLOWED_GROUPS", "EA_ALL,EA_INSURANCE").split(",")
            if g.strip()),
        sync_segment=env.get("SYNC_SEGMENT", "EA"),
        sync_audience=env.get("SYNC_AUDIENCE", "INTERNAL"),
        sync_max_mb=int(env.get("SYNC_MAX_MB", "200")),
        max_versions=int(env.get("MAX_VERSIONS", "5")),
        graph_tenant_id=env.get("GRAPH_TENANT_ID") or None,
        graph_client_id=env.get("GRAPH_CLIENT_ID") or None,
        graph_client_secret=env.get("GRAPH_CLIENT_SECRET") or None,
        sharepoint_site_id=env.get("SHAREPOINT_SITE_ID") or None,
        sharepoint_drive_id=env.get("SHAREPOINT_DRIVE_ID") or None,
    )
