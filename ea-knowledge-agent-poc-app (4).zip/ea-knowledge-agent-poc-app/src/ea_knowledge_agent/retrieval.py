"""Permission-aware hybrid retrieval. Only APPROVED current versions of
artifacts the persona's groups can see are eligible evidence. Ranking is
keyword and metadata overlap, plus Vertex AI embedding similarity when
VERTEX_EMBED_MODEL is set and the passages are embedded; without it (or
if the embedding call fails) search is keyword-only and deterministic."""

import logging
from array import array
from operator import mul

from .models import Persona
from .repository import tokenize

log = logging.getLogger("ea_knowledge_agent")

MIN_SCORE = 2.0  # below this the agent abstains
CHUNK_SIZE = 900        # characters per passage
CHUNK_OVERLAP = 150
PASSAGES_PER_DOC = 3
SEMANTIC_WEIGHT = 6.0   # points for a perfect-similarity passage

_STOP = frozenset("""a an and are as at be but by can do does for from had has
have how i if in into is it its me my of on or our that the their them then
there these they this to was we were what when where which who why will with
would you your show find tell give about""".split())


class PermissionAwareRetriever:
    def __init__(self, conn, embedder=None):
        self.conn = conn
        self.embedder = embedder

    def search(self, persona: Persona, question: str,
               limit: int = 4) -> list[dict]:
        groups = ",".join("?" for _ in persona.groups)
        rows = self.conn.execute(
            f"""SELECT v.*, f.title, f.segment, f.domain, f.content_type,
                       f.audience, f.owner
                FROM artifact_versions v
                JOIN artifact_families f ON f.id = v.family_id
                WHERE v.is_current_approved = 1
                  AND v.lifecycle_status = 'APPROVED'
                  AND v.id IN (SELECT version_id FROM artifact_acl_groups
                               WHERE grp IN ({groups}))""",
            list(persona.groups)).fetchall()
        q_tokens = tokenize(question) - _STOP
        q_vec = self._query_vector(question) if rows else None
        min_sim = self.embedder.min_similarity if q_vec else 1.0
        results = []
        for r in rows:
            tags = [t[0] for t in self.conn.execute(
                "SELECT tag FROM artifact_tags WHERE version_id=?",
                (r["id"],))]
            doc_tokens = tokenize(" ".join([
                r["title"], r["description"], r["content_text"],
                r["segment"], r["domain"], " ".join(tags)]))
            overlap = q_tokens & doc_tokens
            chunks = self._chunk_vectors(r["id"]) if q_vec else []
            sims = [sum(map(mul, q_vec, v)) for _, v in chunks]
            best_sim = max(sims, default=0.0)
            if not overlap and best_sim < min_sim:
                continue
            title_tokens = tokenize(r["title"])
            tag_tokens = {t.lower() for t in tags}
            score = float(len(overlap))
            score += 2.0 * len(q_tokens & title_tokens)   # title boost
            score += 1.5 * len(q_tokens & tag_tokens)     # tag boost
            score += 1.0                                  # current approved
            if chunks:
                passages, best = _hybrid_passages(
                    [c for c, _ in chunks], sims, q_tokens, min_sim)
            else:
                passages, best = _best_passages(r["content_text"], q_tokens)
            score += 0.5 * min(best, 6)                   # best passage match
            score += SEMANTIC_WEIGHT * _strength(best_sim, min_sim)
            results.append({
                "artifact_id": r["id"],
                "family_id": r["family_id"],
                "title": r["title"],
                "version": r["version"],
                "lifecycle_status": r["lifecycle_status"],
                "audience": r["audience"],
                "owner": r["owner"],
                "segment": r["segment"],
                "domain": r["domain"],
                "source_url": r["source_url"],
                "tags": tags,
                "score": round(score, 2),
                "similarity": round(best_sim, 3),
                "excerpt": _excerpt(
                    r["content_text"] if overlap or not passages
                    else passages[0], q_tokens),
                "passages": passages,
                "content_text": r["content_text"],
            })
        results.sort(key=lambda e: (-e["score"], e["title"]))
        return [e for e in results if e["score"] >= MIN_SCORE][:limit]

    def _query_vector(self, question: str) -> array | None:
        """Unit-length question embedding, or None for keyword-only."""
        e = self.embedder
        if not (e and e.configured):
            return None
        try:
            vec = e.embed([question], "RETRIEVAL_QUERY")[0]
        except Exception as exc:
            log.warning("query embedding failed, keyword search only: %s",
                        exc)
            return None
        norm = sum(x * x for x in vec) ** 0.5 or 1.0
        return array("f", (x / norm for x in vec))

    def _chunk_vectors(self, version_id: str) -> list[tuple[str, array]]:
        return [(r[0], unpack(r[1])) for r in self.conn.execute(
            "SELECT chunk_text, embedding FROM artifact_chunks "
            "WHERE version_id=? AND embed_model=? ORDER BY chunk_index",
            (version_id, self.embedder.model))]


def unpack(blob: bytes) -> array:
    vec = array("f")
    vec.frombytes(blob)
    return vec


def _strength(sim: float, min_sim: float) -> float:
    """0 at or below the similarity floor, 1 at a perfect match."""
    return max(0.0, (sim - min_sim) / (1.0 - min_sim)) if min_sim < 1 \
        else 0.0


def _excerpt(text: str, q_tokens: set[str], width: int = 260) -> str:
    """Return a snippet around the first sentence containing a query term."""
    sentences = [s.strip() for s in text.replace("\n", " ").split(". ")
                 if s.strip()]
    for s in sentences:
        if tokenize(s) & q_tokens:
            return (s[:width] + "…") if len(s) > width else s
    return text[:width] + ("…" if len(text) > width else "")


def _chunks(text: str) -> list[str]:
    text = (text or "").strip()
    if len(text) <= CHUNK_SIZE:
        return [text] if text else []
    out, step = [], CHUNK_SIZE - CHUNK_OVERLAP
    for start in range(0, len(text), step):
        piece = text[start:start + CHUNK_SIZE]
        if start and (nl := piece.find("\n", 0, 120)) != -1:
            piece = piece[nl + 1:]          # start on a line boundary
        if piece.strip():
            out.append(piece.strip())
        if start + CHUNK_SIZE >= len(text):
            break
    return out


def _best_passages(text: str, q_tokens: set[str]) -> tuple[list[str], int]:
    """Top-scoring passages of one document (kept in document order) and
    the best passage's overlap count."""
    scored = []
    for i, c in enumerate(_chunks(text)):
        overlap = len(tokenize(c) & q_tokens)
        if overlap:
            scored.append((overlap, i, c))
    if not scored:
        return [], 0
    top = sorted(scored, key=lambda t: (-t[0], t[1]))[:PASSAGES_PER_DOC]
    return [c for _, _, c in sorted(top, key=lambda t: t[1])], top[0][0]


def _hybrid_passages(chunks: list[str], sims: list[float],
                     q_tokens: set[str], min_sim: float
                     ) -> tuple[list[str], int]:
    """Like _best_passages, but a passage also counts when it matches the
    question's meaning, and similarity adds to its keyword overlap."""
    scored = []
    for i, (c, sim) in enumerate(zip(chunks, sims)):
        overlap = len(tokenize(c) & q_tokens)
        if overlap or sim >= min_sim:
            scored.append((overlap + SEMANTIC_WEIGHT *
                           _strength(sim, min_sim), overlap, i, c))
    if not scored:
        return [], 0
    top = sorted(scored, key=lambda t: (-t[0], t[2]))[:PASSAGES_PER_DOC]
    return ([c for *_, c in sorted(top, key=lambda t: t[2])],
            max(t[1] for t in scored))
