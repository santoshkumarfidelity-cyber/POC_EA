# EA — Knowledge Agent POC (first vertical slice)

A runnable, offline, standard-library-only proof of the governed knowledge
journey described in `../requirements_summary.md` and the V2 deck:
**discover → contribute → govern → reuse**, with a grounded, permission-
aware AI experience on top.

This is a POC increment, **not** a production system. Persona switching is
a demo convenience, not authentication. SQLite (with vectors stored in a
table), hybrid keyword + Vertex embedding retrieval and stdlib file
extraction stand in for managed storage, a vector database and production
parsers. Claude and SharePoint/Graph are adapter seams,
inactive by default. **Never load real client data.**

## Architecture

```
web/ (HTML/CSS/JS, no build)  ── same process ──  api.py (http.server)
                                                     │
              ┌──────────────┬───────────────────────┤
        repository.py   retrieval.py           agent.py ── claude_client.py (opt)
        (ACL + audit,   (approved/current      (sanitize → synthesize
         lifecycle)      evidence only)         → cite or abstain)
              │                 │
        database.py ── seed.py ── guardrails.py (injection, validation)
              │
        SQLite data/poc.db   +  seams: auth.py (Entra seam),
        sharepoint_connector.py (Sites.Selected/delta seam),
        file_extraction.py (parser seam)
```

Trust model: every repository/retrieval query applies group ACLs; only
`APPROVED` current versions are agent evidence; Claude output returns
through validation; audit events store hashes/IDs, never raw prompts or
bodies.

## Quick start

```bash
cd ea-knowledge-agent-poc-app
make run          # serves http://127.0.0.1:8765 (seeds data/poc.db once)
make test         # 25 unittest acceptance checks
make reset-demo   # deletes data/poc.db only
make check        # compileall + tests
```

No virtualenv or packages needed — Python 3.10+ standard library only.
Settings can go in a `.env` file in the project folder (copy
`.env.example`); it is read on every request, so edits apply without a
restart. Variables set in the shell override the file.

## Real documents + LLM answers (Phase 1)

Ask answers from **indexed EA documents** and shows numbered sources.

```
documents -> make sync -> SQLite (approved, current, ACL) -> passage retrieval -> Vertex AI -> answer + [1][2] sources
```

1. **Index documents** (TXT, MD, DOCX, PPTX, XLSX; PDF with
   `pip install pypdf`; JPG/PNG via OCR with `pip install rapidocr onnxruntime`;
   files up to `SYNC_MAX_MB`, default 200):
   - SharePoint: set `GRAPH_TENANT_ID`, `GRAPH_CLIENT_ID`, `GRAPH_CLIENT_SECRET`,
     `SHAREPOINT_SITE_ID`, `SHAREPOINT_DRIVE_ID` (Graph app permission to read
     the site, e.g. `Sites.Selected`), then `make sync`.
   - Local folder: `make sync FOLDER=path/to/docs`.
   - Add `RESET=1` the first time to drop the synthetic demo data.
   - Re-running is safe: unchanged files are skipped, changed files become a
     new current version (old one superseded), files removed at the source are
     archived. A partially failed sync never archives anything.
   - Folder names become the domain and tags. Synced files are stored as
     APPROVED (they are approved at the source) and visible to
     `SYNC_ALLOWED_GROUPS`.
2. **Enable the LLM** (Vertex AI): `gcloud auth login`, then set `VERTEX_PROJECT`,
   `VERTEX_LOCATION` and `VERTEX_MODEL` (a Gemini model your project can use)
   before `make run`. The top bar then shows "Vertex AI · <model>" and each
   answer says which engine produced it. If the LLM call fails the app falls
   back to the built-in summary and says so.
3. **Enable semantic search** (optional, recommended): also set
   `VERTEX_EMBED_MODEL` (e.g. `text-embedding-005`). `make sync` then
   embeds every current approved document's passages into the
   `artifact_chunks` table (only new or changed documents are embedded).
   Questions then match on meaning ("how long do we keep files" finds a
   "retention period" passage), not only on shared words. To embed without
   a sync: `python -m ea_knowledge_agent.embeddings`; to see each
   document's score and similarity for a question:
   `python -m ea_knowledge_agent.embeddings --probe "your question"`.
   Without it, or if an embedding call fails, search is keyword-only.
4. **Ask.** Retrieval is limited to documents the viewer may see; the best
   passages of the top documents are sent to the model, which must answer only
   from them and cite `[n]`. No evidence means no LLM call and an explicit
   "could not find" answer.

## Demo walkthrough (mapped to acceptance criteria)

1. **Ask** (AC-007/008): try `Show the latest Insurance technology
   strategy` → grounded answer citing *Insurance Technology Strategy
   v4.2*. Then `What is our policy on quantum computing hardware?` → safe
   abstention.
2. **Permissions** (AC-006/GR): `What is the approved API strategy?` as
   *consumer* answers only from authorized artifacts — the restricted
   *Enterprise API Strategy* never appears in citations or the Discover
   list. Switch persona to *admin* → the answer cites it directly.
3. **Discover** (AC-003/004): tag chips, lifecycle/audience filters, sort
   newest-first; open a card → drawer shows source link, versions,
   lifecycle history (v4.1 superseded under v4.2's family).
4. **Contribute** (AC-001): fill the form (or attach TXT/DOCX/PPTX) →
   artifact created as DRAFT; duplicates and missing metadata are
   rejected with clear errors.
5. **Govern** (AC-009): as contributor submit the draft for review; as
   approver approve it (prior approved version in the family is
   superseded automatically); consumer sees read-only explanation.
6. **Reports** (AC-010): curator/admin see item-level stale, unowned,
   superseded, duplicate and broken-link rows; other personas see counts
   and the permission note.
7. **Audit** (GR): `GET /api/audit/recent?persona=curator` lists sanitized
   events — question hashes, never raw prompts.

## Configuration

| Variable | Purpose |
|---|---|
| `ANTHROPIC_API_KEY`, `CLAUDE_MODEL` | Optional Claude adapter (generation only, after ACL/policy checks; fails closed to local synthesis) |
| `VERTEX_EMBED_MODEL`, `VERTEX_EMBED_MIN_SIM` | Optional semantic retrieval: Vertex embedding model, and the cosine similarity (default 0.60) a passage needs to match on meaning alone |
| `GRAPH_TENANT_ID`, `GRAPH_CLIENT_ID`, `GRAPH_CLIENT_SECRET`, `SHAREPOINT_SITE_ID`, `SHAREPOINT_DRIVE_ID` | SharePoint/Graph seam — **not called** by the demo; `/api/integrations` reports status only |
| `POC_HOST`, `POC_PORT`, `POC_DB`, `POC_WEB_DIR` | Server overrides |

## Security limitations (explicit)

- Persona dropdown is **not authentication** — production requires Entra
  ID SSO/RBAC at the identity seam.
- Retrieval is keyword/metadata ranking plus, when `VERTEX_EMBED_MODEL`
  is set, Vertex embedding similarity. Vectors are compared in Python, one
  document at a time, after the ACL filter: fine for thousands of passages;
  a vector index (MongoDB Atlas Vector Search, AlloyDB/pgvector, Vertex AI
  Vector Search) is the production step. Documents approved through Govern
  are embedded at the next sync; until then they match on keywords only.
- PDF and JPG/PNG extraction need optional packages (`pypdf`; `rapidocr`
  + `onnxruntime`, whose default OCR models ship inside the package); XLSX
  dates appear as Excel serial numbers. Visio, GIF and SVG are pending
  production parsers; such uploads register metadata as `PENDING`, but
  they cannot be approved and are never used as agent evidence until
  extraction succeeds.
- SQLite is single-node demo storage; managed storage/search products
  remain client architecture decisions.
- Audit is append-only JSON rows; production needs immutable/WORM audit.
- Synthetic data only; no PII/PHI and no automated decisions.

## Next increments

Entra adapter behind `auth.py`; SharePoint `Sites.Selected` + delta sync
via `sharepoint_connector.py`; managed vector index behind `retrieval.py`;
contextual follow-up retrieval; production extractors; transcript ingestion;
external-publication workflow; curator bulk operations.
