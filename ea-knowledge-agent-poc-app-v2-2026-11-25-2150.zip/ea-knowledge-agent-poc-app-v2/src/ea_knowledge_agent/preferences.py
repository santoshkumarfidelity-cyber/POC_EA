"""v2 "Customise": each user's own custom instructions (tone, format,
what to focus on), like Copilot's. They are added to the LLM's system
prompt as preferences only: they never change which documents a user may
see, the one cited source or the grounding rules."""

from datetime import datetime, timezone

MAX_CHARS = 1500


def get_instructions(conn, persona_id: str) -> str:
    row = conn.execute("SELECT instructions FROM user_preferences "
                       "WHERE persona=?", (persona_id,)).fetchone()
    return row[0] if row else ""


def set_instructions(conn, persona_id: str, text: str) -> str:
    """Saves the user's instructions (empty text clears them) and returns
    what was saved. Raises ValueError if they are too long."""
    text = (text or "").strip()
    if len(text) > MAX_CHARS:
        raise ValueError(f"instructions must be at most {MAX_CHARS} "
                         "characters")
    if not text:
        conn.execute("DELETE FROM user_preferences WHERE persona=?",
                     (persona_id,))
    else:
        conn.execute(
            "INSERT INTO user_preferences (persona, instructions, "
            "updated_at) VALUES (?,?,?) ON CONFLICT(persona) DO UPDATE SET "
            "instructions=excluded.instructions, "
            "updated_at=excluded.updated_at",
            (persona_id, text,
             datetime.now(timezone.utc).isoformat(timespec="seconds")))
    conn.commit()
    return text
