"""Configuration: environment variables, plus an optional `.env` file in
the project folder. No secrets are stored in code."""

import os
from dataclasses import dataclass

_APP_ROOT = os.path.abspath(os.path.join(
    os.path.dirname(__file__), os.pardir, os.pardir))


def app_path(path: str) -> str:
    """Relative paths (data/poc.db, logs/...) mean the project folder, not
    the folder the command was started from, so the server, sync and
    embeddings commands always open the same database."""
    return path if os.path.isabs(path) else os.path.join(_APP_ROOT, path)


@dataclass(frozen=True)
class Settings:
    host: str = "127.0.0.1"
    port: int = 8765
    db_path: str = "data/poc.db"
    web_dir: str = os.path.join(_APP_ROOT, "web")
    # Delivery phase: 1 = internal viewer (Ask + Discover, approved content
    # only); 2 adds audit/quality; 3 adds supporting services.
    phase: int = 1

    anthropic_api_key: str | None = None
    claude_model: str | None = None

    # Google Vertex AI (Gemini) answer generation
    vertex_project: str | None = None
    vertex_location: str = "us-central1"
    vertex_model: str | None = None
    vertex_access_token: str | None = None  # else `gcloud auth print-access-token`
    # Vertex AI embeddings for semantic retrieval (off when unset)
    vertex_embed_model: str | None = None
    vertex_embed_min_sim: float = 0.60  # cosine below this is not a match

    # Defaults applied to documents synced from SharePoint / a folder
    sync_allowed_groups: tuple[str, ...] = ("EA_ALL", "EA_INSURANCE")
    sync_segment: str = "EA"
    sync_audience: str = "INTERNAL"
    sync_max_mb: int = 200   # larger files are skipped by the sync
    max_versions: int = 5    # versions kept per document (oldest dropped)
    # Debug log of each question's SQL, scores and LLM status (raw question
    # included, so off by default)
    retrieval_debug: bool = False
    retrieval_debug_log: str = "logs/retrieval_debug.log"
    # v2 chat: earlier messages sent with each question (12 = the last 6
    # question/answer pairs), cut to this many characters, oldest first
    chat_history_messages: int = 12
    chat_history_chars: int = 24000
    # chats untouched for this many days are deleted (POC: 2 weeks; the
    # project plan is 6 months)
    chat_retention_days: int = 14
    # v2: a deleted chat is only hidden; it is removed from the database
    # this many days after it was deleted
    chat_deleted_keep_days: int = 10
    # Discover: every user with access sees it; an admin can switch it off
    # for non-admins (this is the default until an admin changes it)
    discover_for_everyone: bool = True

    graph_tenant_id: str | None = None
    graph_client_id: str | None = None
    graph_client_secret: str | None = None
    sharepoint_site_id: str | None = None
    sharepoint_drive_id: str | None = None
    # v2: name the site by URL instead of IDs, e.g.
    # https://contoso.sharepoint.com/sites/EA ; library = its drive name
    # ("Documents"); folder = only sync files under this folder path
    sharepoint_site_url: str | None = None
    sharepoint_library: str = "Documents"
    sharepoint_folder: str = ""

    # v2 sign-in: "demo" = persona / User-Admin switch (no sign-in);
    # "entra" = Microsoft Entra ID sign-in, groups decide access
    auth_mode: str = "demo"
    entra_tenant_id: str | None = None      # falls back to GRAPH_TENANT_ID
    entra_client_id: str | None = None      # falls back to GRAPH_CLIENT_ID
    entra_client_secret: str | None = None  # falls back to GRAPH_CLIENT_SECRET
    entra_redirect_uri: str = ""            # default http://localhost:<port>/auth/callback
    # Entra group object IDs (or app role values) -> app groups, e.g.
    # (("1b2c...", "EA_ALL"), ("9f8e...", "EA_ADMINS"))
    entra_group_map: tuple[tuple[str, str], ...] = ()
    entra_default_groups: tuple[str, ...] = ()   # for every signed-in user
    session_hours: int = 8


def read_env_file(path: str) -> dict[str, str]:
    """KEY=VALUE lines; blank lines, '#' comments and empty values are
    skipped, an 'export ' prefix and surrounding quotes are removed."""
    values: dict[str, str] = {}
    try:
        with open(path, encoding="utf-8-sig") as fh:
            lines = fh.read().splitlines()
    except OSError:
        return values
    for line in lines:
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, val = line.removeprefix("export ").partition("=")
        key, val = key.strip(), val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in "\"'":
            val = val[1:-1]
        elif " #" in val:                       # inline comment
            val = val.split(" #", 1)[0].rstrip()
        if key and val:
            values[key] = val
    return values


def load_settings() -> Settings:
    # Read on every call, so edits to .env (e.g. a fresh
    # VERTEX_ACCESS_TOKEN) apply without a restart. Variables set in the
    # shell win over the file.
    env = {**read_env_file(os.path.join(_APP_ROOT, ".env")), **os.environ}
    return Settings(
        host=env.get("POC_HOST", "127.0.0.1"),
        port=int(env.get("POC_PORT", "8765")),
        db_path=app_path(env.get("POC_DB") or "data/poc.db"),
        web_dir=env.get("POC_WEB_DIR") or os.path.join(_APP_ROOT, "web"),
        phase=int(env.get("POC_PHASE", "1")),
        anthropic_api_key=env.get("ANTHROPIC_API_KEY") or None,
        claude_model=env.get("CLAUDE_MODEL") or None,
        vertex_project=env.get("VERTEX_PROJECT") or None,
        vertex_location=env.get("VERTEX_LOCATION") or "us-central1",
        vertex_model=env.get("VERTEX_MODEL") or None,
        vertex_access_token=env.get("VERTEX_ACCESS_TOKEN") or None,
        vertex_embed_model=env.get("VERTEX_EMBED_MODEL") or None,
        vertex_embed_min_sim=float(env.get("VERTEX_EMBED_MIN_SIM", "0.60")),
        sync_allowed_groups=tuple(
            g.strip() for g in env.get(
                "SYNC_ALLOWED_GROUPS", "EA_ALL,EA_INSURANCE").split(",")
            if g.strip()),
        sync_segment=env.get("SYNC_SEGMENT", "EA"),
        sync_audience=env.get("SYNC_AUDIENCE", "INTERNAL"),
        sync_max_mb=int(env.get("SYNC_MAX_MB", "200")),
        max_versions=int(env.get("MAX_VERSIONS", "5")),
        retrieval_debug=env.get("RETRIEVAL_DEBUG", "0").lower()
        in ("1", "true", "yes", "on"),
        retrieval_debug_log=env.get("RETRIEVAL_DEBUG_LOG")
        or "logs/retrieval_debug.log",
        chat_history_messages=int(env.get("CHAT_HISTORY_MESSAGES", "12")),
        chat_history_chars=int(env.get("CHAT_HISTORY_CHARS", "24000")),
        chat_retention_days=int(env.get("CHAT_RETENTION_DAYS", "14")),
        chat_deleted_keep_days=int(env.get("CHAT_DELETED_KEEP_DAYS", "10")),
        discover_for_everyone=env.get("DISCOVER_FOR_EVERYONE", "1").lower()
        in ("1", "true", "yes", "on"),
        graph_tenant_id=env.get("GRAPH_TENANT_ID") or None,
        graph_client_id=env.get("GRAPH_CLIENT_ID") or None,
        graph_client_secret=env.get("GRAPH_CLIENT_SECRET") or None,
        sharepoint_site_id=env.get("SHAREPOINT_SITE_ID") or None,
        sharepoint_drive_id=env.get("SHAREPOINT_DRIVE_ID") or None,
        sharepoint_site_url=env.get("SHAREPOINT_SITE_URL") or None,
        sharepoint_library=env.get("SHAREPOINT_LIBRARY") or "Documents",
        sharepoint_folder=(env.get("SHAREPOINT_FOLDER") or "").strip("/"),
        auth_mode=(env.get("AUTH_MODE") or "demo").lower(),
        entra_tenant_id=env.get("ENTRA_TENANT_ID")
        or env.get("GRAPH_TENANT_ID") or None,
        entra_client_id=env.get("ENTRA_CLIENT_ID")
        or env.get("GRAPH_CLIENT_ID") or None,
        entra_client_secret=env.get("ENTRA_CLIENT_SECRET")
        or env.get("GRAPH_CLIENT_SECRET") or None,
        entra_redirect_uri=env.get("ENTRA_REDIRECT_URI") or "",
        entra_group_map=_pairs(env.get("ENTRA_GROUP_MAP", "")),
        entra_default_groups=tuple(
            g.strip() for g in env.get("ENTRA_DEFAULT_GROUPS", "").split(",")
            if g.strip()),
        session_hours=int(env.get("SESSION_HOURS", "8")),
    )


def _pairs(text: str) -> tuple[tuple[str, str], ...]:
    """"id1=EA_ALL; id2=EA_ADMINS" -> (("id1", "EA_ALL"), ("id2", ...)).
    Separators: ';' or ','; one Entra group may map to several app groups
    by listing it more than once."""
    out = []
    for part in text.replace(",", ";").split(";"):
        key, _, val = part.partition("=")
        if key.strip() and val.strip():
            out.append((key.strip(), val.strip()))
    return tuple(out)
