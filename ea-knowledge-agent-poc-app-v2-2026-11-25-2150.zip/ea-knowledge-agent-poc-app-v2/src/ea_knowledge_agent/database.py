"""SQLite schema for the POC. One row per artifact version; history is
never overwritten."""

import os
import sqlite3

SCHEMA = """
CREATE TABLE IF NOT EXISTS artifact_families (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    segment TEXT NOT NULL,
    domain TEXT NOT NULL,
    content_type TEXT NOT NULL,
    audience TEXT NOT NULL,
    owner TEXT NOT NULL,
    contributor TEXT NOT NULL,
    created_at TEXT NOT NULL,
    current_version_id TEXT
);

CREATE TABLE IF NOT EXISTS artifact_versions (
    id TEXT PRIMARY KEY,
    family_id TEXT NOT NULL REFERENCES artifact_families(id),
    version TEXT NOT NULL,
    description TEXT NOT NULL,
    lifecycle_status TEXT NOT NULL,
    review_date TEXT,
    uploaded_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    source_url TEXT NOT NULL,
    content_hash TEXT NOT NULL,
    content_text TEXT NOT NULL,
    extraction_status TEXT NOT NULL DEFAULT 'TEXT',
    is_current_approved INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS ix_versions_family
    ON artifact_versions(family_id);
CREATE INDEX IF NOT EXISTS ix_versions_status
    ON artifact_versions(lifecycle_status);

CREATE TABLE IF NOT EXISTS artifact_tags (
    version_id TEXT NOT NULL REFERENCES artifact_versions(id),
    tag TEXT NOT NULL,
    PRIMARY KEY (version_id, tag)
);

CREATE TABLE IF NOT EXISTS artifact_acl_groups (
    version_id TEXT NOT NULL REFERENCES artifact_versions(id),
    grp TEXT NOT NULL,
    PRIMARY KEY (version_id, grp)
);

-- Passages of current approved versions with their embedding (float32,
-- unit length), one set per embedding model.
CREATE TABLE IF NOT EXISTS artifact_chunks (
    version_id TEXT NOT NULL REFERENCES artifact_versions(id),
    embed_model TEXT NOT NULL,
    chunk_index INTEGER NOT NULL,
    chunk_text TEXT NOT NULL,
    embedding BLOB NOT NULL,
    PRIMARY KEY (version_id, embed_model, chunk_index)
);

CREATE TABLE IF NOT EXISTS lifecycle_events (
    id TEXT PRIMARY KEY,
    version_id TEXT NOT NULL REFERENCES artifact_versions(id),
    from_status TEXT,
    to_status TEXT NOT NULL,
    actor_persona TEXT NOT NULL,
    note TEXT,
    at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS registered_links (
    id TEXT PRIMARY KEY,
    family_id TEXT,
    url TEXT NOT NULL,
    title TEXT NOT NULL,
    link_status TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS registered_link_acl_groups (
    link_id TEXT NOT NULL REFERENCES registered_links(id),
    grp TEXT NOT NULL,
    PRIMARY KEY (link_id, grp)
);

CREATE TABLE IF NOT EXISTS audit_events (
    id TEXT PRIMARY KEY,
    persona TEXT NOT NULL,
    action TEXT NOT NULL,
    resource_id TEXT,
    details_json TEXT NOT NULL,
    at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_audit_at ON audit_events(at);

CREATE TABLE IF NOT EXISTS conversations (
    id TEXT PRIMARY KEY,
    persona TEXT NOT NULL,
    last_question TEXT,
    last_status TEXT,
    cited_ids_json TEXT NOT NULL DEFAULT '[]',
    updated_at TEXT NOT NULL
);

-- v2 chat history (one row per chat, one row per question or answer)
CREATE TABLE IF NOT EXISTS chats (
    id TEXT PRIMARY KEY,
    persona TEXT NOT NULL,
    title TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    deleted_at TEXT                -- soft delete: hidden, removed later
);
CREATE INDEX IF NOT EXISTS ix_chats_persona ON chats(persona, updated_at);

CREATE TABLE IF NOT EXISTS chat_messages (
    id TEXT PRIMARY KEY,
    chat_id TEXT NOT NULL REFERENCES chats(id),
    seq INTEGER NOT NULL,
    role TEXT NOT NULL,            -- user | assistant
    content TEXT NOT NULL,
    status TEXT,                   -- assistant: grounded | insufficient_evidence
    provider TEXT,                 -- assistant: vertex | claude | local
    citation_json TEXT,            -- assistant: the one cited document
    duration_ms INTEGER,           -- assistant: how long the answer took
    source_ids_json TEXT,          -- assistant: top documents, best first
    created_at TEXT NOT NULL,
    UNIQUE (chat_id, seq)
);

CREATE TABLE IF NOT EXISTS user_preferences (  -- v2: "Customise"
    persona TEXT PRIMARY KEY,      -- the user (persona id)
    instructions TEXT NOT NULL,    -- their custom instructions
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS app_settings (   -- v2: admin choices (POC)
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

-- v2: Entra ID sign-in (AUTH_MODE=entra); see entra.py
CREATE TABLE IF NOT EXISTS auth_pending (     -- sign-ins in progress
    state TEXT PRIMARY KEY,
    nonce TEXT NOT NULL,
    verifier TEXT NOT NULL,
    redirect_uri TEXT NOT NULL,
    created_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS auth_sessions (    -- signed-in users
    id_hash TEXT PRIMARY KEY,                 -- SHA-256 of the cookie
    user_id TEXT NOT NULL,                    -- Entra object id (oid)
    name TEXT NOT NULL,
    username TEXT NOT NULL,
    groups_json TEXT NOT NULL,                -- mapped app groups
    created_at REAL NOT NULL,
    expires_at REAL NOT NULL
);
"""

FTS_SCHEMA = """
CREATE VIRTUAL TABLE IF NOT EXISTS artifact_fts USING fts5(
    version_id UNINDEXED, title, description, content_text, tags_text);
"""


def connect(path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def describe_db(path: str) -> str:
    """Short summary printed at startup, so a wrong database is obvious."""
    if not os.path.exists(path):
        return "new, empty"
    try:
        conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
        try:
            n = conn.execute("SELECT COUNT(*) FROM artifact_versions "
                             "WHERE is_current_approved=1").fetchone()[0]
        finally:
            conn.close()
    except sqlite3.Error:
        return "not initialized yet"
    return f"{n} current approved documents"


def fts_available(conn: sqlite3.Connection) -> bool:
    try:
        conn.execute(
            "SELECT * FROM artifact_fts LIMIT 0")
        return True
    except sqlite3.Error:
        return False


def initialize(conn: sqlite3.Connection) -> bool:
    """Create schema. Returns True if FTS5 is usable."""
    conn.executescript(SCHEMA)
    # v2 databases made before these columns existed get them added.
    cols = {r[1] for r in conn.execute("PRAGMA table_info(chat_messages)")}
    for col, kind in (("duration_ms", "INTEGER"),
                      ("source_ids_json", "TEXT")):
        if col not in cols:
            conn.execute(f"ALTER TABLE chat_messages ADD COLUMN {col} "
                         f"{kind}")
    if "deleted_at" not in {r[1] for r in
                            conn.execute("PRAGMA table_info(chats)")}:
        conn.execute("ALTER TABLE chats ADD COLUMN deleted_at TEXT")
    try:
        conn.executescript(FTS_SCHEMA)
        ok = True
    except sqlite3.Error:
        ok = False
    conn.commit()
    return ok
