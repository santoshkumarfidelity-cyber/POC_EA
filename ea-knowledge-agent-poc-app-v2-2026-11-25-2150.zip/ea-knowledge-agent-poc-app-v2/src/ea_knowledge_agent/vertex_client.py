"""Google Vertex AI: Gemini answer generation and text embeddings. Same contract as
ClaudeClient: disabled unless VERTEX_PROJECT and VERTEX_MODEL are set, and
any failure raises so the caller falls back to local synthesis. Auth uses
VERTEX_ACCESS_TOKEN if set, otherwise the developer's gcloud login
(`gcloud auth print-access-token`). Tokens and error bodies are never
returned to the browser."""

import json
import re
import ssl
import subprocess
import time
import urllib.error
import urllib.request

from .claude_client import CONDENSE_PROMPT, answer_turn, system_prompt, \
    condense_input
from .config import load_settings

_TIMEOUT = 30
_TOKEN_TTL = 45 * 60
_SAFE = re.compile(r"[A-Za-z0-9_.-]+")


def _ssl_context() -> ssl.SSLContext | None:
    """Verify HTTPS with the operating system's own certificate checks when
    the optional `truststore` package is installed (pip install truststore).
    Behind a company proxy that inspects HTTPS this is what makes the
    company's certificate trusted, as Windows itself trusts it. Without
    truststore, Python's default checks apply. Verification is never off."""
    try:
        import truststore
    except ImportError:
        return None
    return truststore.SSLContext(ssl.PROTOCOL_TLS_CLIENT)


class VertexClient:
    _token_cache: tuple[str, float] | None = None  # shared across requests

    def __init__(self, settings=None):
        self._s = settings or load_settings()

    @property
    def configured(self) -> bool:
        s = self._s
        return bool(s.vertex_project and s.vertex_model)

    @property
    def model(self) -> str:
        return self._s.vertex_model or ""

    def _access_token(self) -> str:
        if self._s.vertex_access_token:
            return self._s.vertex_access_token
        cached = VertexClient._token_cache
        if cached and cached[1] > time.time():
            return cached[0]
        try:
            out = subprocess.run(
                ["gcloud", "auth", "print-access-token"],
                capture_output=True, text=True, timeout=20, check=True)
        except (OSError, subprocess.SubprocessError) as exc:
            raise RuntimeError(
                "no Vertex credentials: run `gcloud auth login` or set "
                "VERTEX_ACCESS_TOKEN") from exc
        token = out.stdout.strip()
        if not token:
            raise RuntimeError("gcloud returned an empty access token")
        VertexClient._token_cache = (token, time.time() + _TOKEN_TTL)
        return token

    def _url(self, model: str | None = None,
             method: str = "generateContent") -> str:
        s = self._s
        model = model or s.vertex_model
        for v in (s.vertex_project, s.vertex_location, model):
            if not _SAFE.fullmatch(v or ""):
                raise RuntimeError("invalid Vertex project/location/model")
        host = ("aiplatform.googleapis.com" if s.vertex_location == "global"
                else f"{s.vertex_location}-aiplatform.googleapis.com")
        return (f"https://{host}/v1/projects/{s.vertex_project}/locations/"
                f"{s.vertex_location}/publishers/google/models/"
                f"{model}:{method}")

    def synthesize(self, question: str, evidence: list[dict],
                   history: list[dict] | None = None,
                   instructions: str = "") -> str:
        return self._generate(system_prompt(instructions),
                              _answer_contents(question, evidence, history),
                              0.2)

    def stream(self, question: str, evidence: list[dict],
               history: list[dict] | None = None, instructions: str = ""):
        """v2: the same answer as synthesize(), yielded piece by piece as
        Gemini writes it (streamGenerateContent, server-sent events)."""
        if not self.configured:
            raise RuntimeError("Vertex adapter not configured")
        payload = _payload(system_prompt(instructions),
                           _answer_contents(question, evidence, history), 0.2)
        resp = self._open(self._url(method="streamGenerateContent")
                          + "?alt=sse", payload)
        try:
            with resp:
                for raw in resp:
                    line = raw.decode("utf-8").strip()
                    if not line.startswith("data:"):
                        continue
                    for c in json.loads(line[5:]).get("candidates") or []:
                        for p in c.get("content", {}).get("parts", []):
                            if p.get("text") and not p.get("thought"):
                                yield p["text"]
        except (OSError, ValueError) as exc:
            raise RuntimeError(f"Vertex stream failed: "
                               f"{type(exc).__name__}: {exc}") from exc

    def condense(self, history: list[dict], question: str) -> str:
        """A follow-up such as "and for Tier 2?" as a standalone question,
        so search finds the right document."""
        return self._generate(CONDENSE_PROMPT, [{"role": "user", "parts": [
            {"text": condense_input(history, question)}]}], 0.0)

    def _generate(self, system: str, contents: list[dict],
                  temperature: float) -> str:
        if not self.configured:
            raise RuntimeError("Vertex adapter not configured")
        body = self._post(self._url(),
                          _payload(system, contents, temperature))
        cands = body.get("candidates") or []
        parts = (cands[0].get("content", {}).get("parts", [])
                 if cands else [])
        text = "".join(p.get("text", "") for p in parts).strip()
        if not text:
            raise RuntimeError("Vertex returned empty content")
        return text

    def _open(self, url: str, payload: dict):
        """The open HTTPS response (the caller reads and closes it)."""
        req = urllib.request.Request(
            url, data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json",
                     "Authorization": f"Bearer {self._access_token()}"},
            method="POST")
        try:
            ctx = _ssl_context()
            return urllib.request.urlopen(
                req, timeout=_TIMEOUT, **({"context": ctx} if ctx else {}))
        except urllib.error.HTTPError as exc:
            raise RuntimeError(f"Vertex request failed: HTTP {exc.code} "
                               f"{_google_error(exc)}") from exc
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            # Server-log only: says whether DNS, proxy, firewall or SSL
            # stopped the call (never contains the token).
            reason = getattr(exc, "reason", exc)
            raise RuntimeError(f"Vertex request failed: "
                               f"{type(reason).__name__}: {reason}") from exc

    def _post(self, url: str, payload: dict) -> dict:
        with self._open(url, payload) as resp:
            try:
                return json.loads(resp.read().decode("utf-8"))
            except (OSError, ValueError) as exc:
                raise RuntimeError(f"Vertex request failed: "
                                   f"{type(exc).__name__}: {exc}") from exc


class VertexEmbedder(VertexClient):
    """Vertex AI text embeddings (`:predict`) for semantic retrieval.
    Disabled unless VERTEX_PROJECT and VERTEX_EMBED_MODEL are set; any
    failure raises so the caller falls back to keyword search."""

    @property
    def configured(self) -> bool:
        s = self._s
        return bool(s.vertex_project and s.vertex_embed_model)

    @property
    def model(self) -> str:
        return self._s.vertex_embed_model or ""

    @property
    def min_similarity(self) -> float:
        return self._s.vertex_embed_min_sim

    def embed(self, texts: list[str], task: str,
              title: str = "") -> list[list[float]]:
        """task: RETRIEVAL_DOCUMENT (passages) or RETRIEVAL_QUERY."""
        if not self.configured:
            raise RuntimeError("Vertex embeddings not configured")
        # gemini-embedding models take one text per request.
        batch = 1 if self.model.startswith("gemini-embedding") else 16
        url, out = self._url(self.model, "predict"), []
        for i in range(0, len(texts), batch):
            instances = []
            for t in texts[i:i + batch]:
                inst = {"content": t, "task_type": task}
                if title and task == "RETRIEVAL_DOCUMENT":
                    inst["title"] = title
                instances.append(inst)
            body = self._post(url, {"instances": instances,
                                    "parameters": {"autoTruncate": True}})
            preds = body.get("predictions") or []
            if len(preds) != len(instances):
                raise RuntimeError("Vertex returned the wrong number of "
                                   "embeddings")
            out.extend(p["embeddings"]["values"] for p in preds)
        return out


def _answer_contents(question: str, evidence: list[dict],
                     history: list[dict] | None) -> list[dict]:
    """Earlier turns as alternating user/model messages, then the source
    and the latest question."""
    contents = [{"role": "user" if m["role"] == "user" else "model",
                 "parts": [{"text": m["content"]}]}
                for m in history or []]
    contents.append({"role": "user", "parts": [
        {"text": answer_turn(question, evidence)}]})
    return contents


def _payload(system: str, contents: list[dict], temperature: float) -> dict:
    return {
        "systemInstruction": {"parts": [{"text": system}]},
        "contents": contents,
        # Gemini 2.5 "thinking" spends part of this budget before it
        # writes, so 1024 could cut answers short.
        "generationConfig": {"temperature": temperature,
                             "maxOutputTokens": 4096},
    }


def _google_error(exc) -> str:
    """Google's own error message (e.g. 'Permission denied on resource
    project …'), for the server log only."""
    try:
        err = json.loads(exc.read().decode("utf-8")).get("error", {})
        return f"{err.get('status', '')}: {err.get('message', '')}"[:300]
    except Exception:
        return ""
