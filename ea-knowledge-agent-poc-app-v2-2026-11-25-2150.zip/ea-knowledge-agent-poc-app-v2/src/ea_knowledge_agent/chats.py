"""Chat history: one row per chat in `chats`, one row per question or
answer in `chat_messages`. Every read is scoped to the persona that owns
the chat, so one user never sees another's history. Answers keep their
single citation, so a reopened chat shows the same source link."""

import json
import uuid
from datetime import datetime, timedelta, timezone

TITLE_LEN = 80
HISTORY_MESSAGES = 12       # the last 6 question/answer pairs go to the LLM
HISTORY_CHARS = 24000       # ...cut to this size, oldest messages first
_ANSWER_CLIP = 1500         # long answers are shortened in that history
DELETED_KEEP_DAYS = 10      # deleted chats stay in the database this long


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _title(question: str) -> str:
    q = " ".join(question.split())
    return q if len(q) <= TITLE_LEN else q[:TITLE_LEN - 1].rstrip() + "…"


class ChatStore:
    def __init__(self, conn):
        self.conn = conn

    def create(self, persona_id: str, first_question: str) -> str:
        cid, now = uuid.uuid4().hex, _now()
        self.conn.execute(
            "INSERT INTO chats (id, persona, title, created_at, updated_at) "
            "VALUES (?,?,?,?,?)",
            (cid, persona_id, _title(first_question), now, now))
        return cid

    def get(self, persona_id: str, chat_id: str) -> dict | None:
        """The chat, or None if it doesn't exist or belongs to someone
        else (the two cases look the same to the caller)."""
        row = self.conn.execute(
            "SELECT id, title, created_at, updated_at FROM chats "
            "WHERE id=? AND persona=? AND deleted_at IS NULL",
            (chat_id or "", persona_id)).fetchone()
        return dict(row) if row else None

    def list_chats(self, persona_id: str, limit: int = 50) -> list[dict]:
        return [dict(r) for r in self.conn.execute(
            "SELECT id, title, updated_at FROM chats WHERE persona=? "
            "AND deleted_at IS NULL ORDER BY updated_at DESC, rowid DESC LIMIT ?",
            (persona_id, limit))]

    def messages(self, chat_id: str) -> list[dict]:
        out = []
        for r in self.conn.execute(
                "SELECT id, role, content, status, provider, citation_json, "
                "duration_ms, source_ids_json, created_at FROM chat_messages "
                "WHERE chat_id=? ORDER BY seq",
                (chat_id,)):
            m = dict(r)
            m["citation"] = json.loads(m.pop("citation_json") or "null")
            m["source_count"] = len(_source_ids(m.pop("source_ids_json"),
                                                m["citation"]))
            out.append(m)
        return out

    def source_ids(self, chat_id: str, message_id: str) -> list[str] | None:
        """The answer's top documents, best first (the cited one first);
        None if the chat has no such answer. Answers saved before sources
        were recorded fall back to their one citation."""
        row = self.conn.execute(
            "SELECT citation_json, source_ids_json FROM chat_messages "
            "WHERE chat_id=? AND id=? AND role='assistant'",
            (chat_id, message_id or "")).fetchone()
        if not row:
            return None
        return _source_ids(row[1], json.loads(row[0] or "null"))

    def history(self, chat_id: str, max_messages: int = HISTORY_MESSAGES,
                max_chars: int = HISTORY_CHARS) -> list[dict]:
        """The last few turns for the LLM: [{"role", "content"}].

        Context-window fallback: long answers are shortened, then the
        oldest messages are dropped until the rest fit in max_chars. The
        latest question/answer pair is always kept, and the history always
        starts with a question (Claude requires that)."""
        rows = self.conn.execute(
            "SELECT role, content FROM chat_messages WHERE chat_id=? "
            "ORDER BY seq DESC LIMIT ?",
            (chat_id, max(max_messages, 0))).fetchall()[::-1]
        out = [{"role": r["role"],
                "content": r["content"] if r["role"] == "user"
                else r["content"][:_ANSWER_CLIP]} for r in rows]
        while len(out) > 2 and sum(len(m["content"]) for m in out) \
                > max_chars:
            out.pop(0)
        while out and out[0]["role"] != "user":
            out.pop(0)
        return out

    def purge(self, days: int,
              deleted_days: int = DELETED_KEEP_DAYS) -> int:
        """Removes from the database, for all personas, every chat (and
        its messages) not used for `days` days, and every chat deleted
        more than `deleted_days` days ago. Returns how many were removed.
        0 turns either rule off."""
        def cutoff(n):
            return (datetime.now(timezone.utc) - timedelta(days=n)
                    ).isoformat(timespec="seconds")
        old = []
        if days > 0:
            old += [r[0] for r in self.conn.execute(
                "SELECT id FROM chats WHERE deleted_at IS NULL AND "
                "updated_at < ?", (cutoff(days),))]
        if deleted_days > 0:
            old += [r[0] for r in self.conn.execute(
                "SELECT id FROM chats WHERE deleted_at < ?",
                (cutoff(deleted_days),))]
        for cid in old:
            self.conn.execute("DELETE FROM chat_messages WHERE chat_id=?",
                              (cid,))
            self.conn.execute("DELETE FROM chats WHERE id=?", (cid,))
        return len(old)

    def last_cited_family(self, chat_id: str) -> str:
        row = self.conn.execute(
            "SELECT citation_json FROM chat_messages WHERE chat_id=? AND "
            "role='assistant' AND citation_json IS NOT NULL "
            "ORDER BY seq DESC LIMIT 1", (chat_id,)).fetchone()
        return (json.loads(row[0]) or {}).get("family_id", "") if row else ""

    def rename(self, persona_id: str, chat_id: str, title: str) -> bool:
        """False if the chat doesn't exist or belongs to someone else.
        The chat keeps its place in the list (updated_at is unchanged)."""
        if not " ".join((title or "").split()):
            raise ValueError("title must not be empty")
        cur = self.conn.execute(
            "UPDATE chats SET title=? WHERE id=? AND persona=? AND "
            "deleted_at IS NULL",
            (_title(title), chat_id or "", persona_id))
        return cur.rowcount == 1

    def delete(self, persona_id: str, chat_id: str) -> bool:
        """Soft delete: the chat disappears for the user at once but
        stays in the database until purge() removes it, DELETED_KEEP_DAYS
        later. False if the chat doesn't exist or belongs to someone
        else."""
        if not self.get(persona_id, chat_id):
            return False
        self.conn.execute("UPDATE chats SET deleted_at=? WHERE id=?",
                          (_now(), chat_id))
        return True

    def add(self, chat_id: str, role: str, content: str, status: str = None,
            provider: str = None, citation: dict | None = None,
            duration_ms: int | None = None,
            source_ids: list[str] | None = None) -> str:
        """Saves one message and returns its id."""
        now, mid = _now(), uuid.uuid4().hex
        seq = self.conn.execute(
            "SELECT COALESCE(MAX(seq), 0) + 1 FROM chat_messages "
            "WHERE chat_id=?", (chat_id,)).fetchone()[0]
        self.conn.execute(
            "INSERT INTO chat_messages (id, chat_id, seq, role, content, "
            "status, provider, citation_json, duration_ms, source_ids_json, "
            "created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            (mid, chat_id, seq, role, content, status,
             provider, json.dumps(citation) if citation else None,
             duration_ms, json.dumps(source_ids) if source_ids else None,
             now))
        self.conn.execute("UPDATE chats SET updated_at=? WHERE id=?",
                          (now, chat_id))
        return mid


def _source_ids(source_ids_json, citation) -> list[str]:
    """Only answers with a citation have sources to download."""
    if not citation:
        return []
    ids = json.loads(source_ids_json or "null") or [citation["artifact_id"]]
    return list(dict.fromkeys(ids))
