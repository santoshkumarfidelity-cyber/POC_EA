"""Knowledge agent: retrieve authorized evidence, sanitize, synthesize,
cite or abstain. Audit events never contain the raw question."""

import hashlib
import json
import logging
import re
import time
import uuid
from datetime import datetime, timezone

from .chats import ChatStore
from .claude_client import MAX_SOURCES, ClaudeClient
from .config import load_settings
from .debug_log import Trace
from .guardrails import detect_prompt_injection, sanitize_evidence, \
    validate_answer
from .models import AgentAnswer, Citation, Persona
from .preferences import get_instructions
from .retrieval import _STOP, PermissionAwareRetriever
from .vertex_client import VertexClient, VertexEmbedder

log = logging.getLogger("ea_knowledge_agent")
_SENTENCE_RE = re.compile(r"(?<=[.!?])\s+")
# Every piece of evidence is approved and current, so these words never
# pick out a paragraph (stemmed, as _stems() returns them).
_LIFECYCLE = frozenset({"approv", "curren", "latest", "offici"})
# An LLM error that means "the prompt is too big" (Gemini / Claude wording)
_CONTEXT_LIMIT = re.compile(
    r"input token count|too many tokens|exceeds the maximum|"
    r"context (window|length)|prompt is too long", re.I)


class KnowledgeAgent:
    def __init__(self, conn, claude: ClaudeClient | None = None,
                 vertex: VertexClient | None = None,
                 embedder: VertexEmbedder | None = None):
        self.conn = conn
        self.retriever = PermissionAwareRetriever(
            conn, embedder or VertexEmbedder())
        self.claude = claude or ClaudeClient()
        self.vertex = vertex or VertexClient()

    def ask(self, persona: Persona, question: str,
            conversation_id: str | None = None,
            on_delta=None) -> AgentAnswer:
        """One chat turn. A follow-up is first rewritten into a standalone
        question (using the chat so far) so search finds the right
        document; the answer comes from the single best document.
        on_delta(text), if given, receives the LLM's answer piece by piece
        as it is written (None means "discard what you have": that
        provider failed half-way); the returned answer is the final one."""
        started = time.monotonic()
        question = (question or "").strip()
        if not question:
            raise ValueError("question must not be empty")
        settings = load_settings()
        chats = ChatStore(self.conn)
        chats.purge(settings.chat_retention_days,   # v2: 2-week retention
                    settings.chat_deleted_keep_days)
        # Someone else's (or an unknown) chat id silently starts a new chat.
        chat = chats.get(persona.id, conversation_id) \
            if conversation_id else None
        history = chats.history(chat["id"], settings.chat_history_messages,
                                settings.chat_history_chars) if chat else []
        prev_family = chats.last_cited_family(chat["id"]) if chat else ""
        instructions = get_instructions(self.conn, persona.id)  # Customise
        trace = Trace.start()
        trace.event("request", database=self._db_path(), question=question,
                    persona=persona.id, groups=list(persona.groups),
                    conversation_id=chat["id"] if chat else "new chat",
                    turn=len(history) // 2 + 1,
                    custom_instructions=bool(instructions))
        search_q = self._standalone(question, history, trace)
        found = self.retriever.search(persona, search_q, limit=MAX_SOURCES,
                                      trace=trace,
                                      prefer_family=prev_family)
        evidence, warnings = sanitize_evidence(found)
        for e in found:
            if e not in evidence:
                trace.event("excluded", id=e["artifact_id"],
                            title=e["title"],
                            reason="prompt-injection pattern in the text")
        # v2: the top MAX_SOURCES are logged (debug trace and audit), but
        # the answer comes from the single best document, cited once.
        top = [{"rank": i, "id": e["artifact_id"], "title": e["title"],
                "version": e["version"], "score": e["score"],
                "answer_source": i == 1}
               for i, e in enumerate(evidence, 1)]
        trace.event("top_documents", documents=top)
        evidence = evidence[:1]
        trace.event("final_documents", documents=[
            {"rank": 1, "id": e["artifact_id"], "title": e["title"],
             "version": e["version"], "score": e["score"]}
            for e in evidence])

        provider, text = "local", None
        if not evidence:
            trace.event("llm", provider="none",
                        status="not called: no evidence")
        else:
            # LLM preference: Vertex AI, then Claude; fail closed to local.
            for name, client in (("vertex", self.vertex),
                                 ("claude", self.claude)):
                if not client.configured:
                    trace.event("llm", provider=name,
                                status="not configured")
                    continue
                state = {"streamed": False}
                try:
                    try:
                        text = self._write(client, name, question, evidence,
                                           history, on_delta, state,
                                           instructions)
                    except Exception as exc:
                        # Context-window fallback: if the LLM says the
                        # prompt is too big, retry once with only the last
                        # question/answer pair.
                        if state["streamed"] or len(history) <= 2 or \
                                not _CONTEXT_LIMIT.search(str(exc)):
                            raise
                        trace.event("history_trimmed", provider=name,
                                    kept=2, dropped=len(history) - 2,
                                    reason="LLM context limit")
                        text = self._write(client, name, question, evidence,
                                           history[-2:], on_delta, state,
                                           instructions)
                    provider = name
                    trace.event("llm", provider=name, status="ok",
                                model=getattr(client, "model", ""))
                    break
                except Exception as exc:
                    log.warning("%s synthesis failed: %s", name, exc)
                    text = None
                    if state["streamed"]:
                        on_delta(None)
                    provider = "local-fallback"
                    trace.event("llm", provider=name, status="failed",
                                error=str(exc))
            if text is None:
                # The follow-up's own words pick the paragraph first
                # ("Tier 1"); the joined question is the fallback.
                text = self._local_synthesis(question, evidence) or (
                    self._local_synthesis(search_q, evidence)
                    if search_q != question else None)
                trace.event("llm", provider="local", status=(
                    "extractive answer" if text else
                    "no paragraph matched: abstaining"))

        citations = tuple(
            Citation(artifact_id=e["artifact_id"], title=e["title"],
                     version=e["version"], source_url=e["source_url"],
                     excerpt=e["excerpt"], family_id=e["family_id"])
            for e in evidence)
        grounded = bool(evidence) and validate_answer(text, citations)
        if not evidence:
            text = ("I could not find current, approved EA content you are "
                    "authorized to see that answers this question. Try "
                    "rephrasing, or ask a content owner.")
        elif not grounded:
            text = ("The retrieved material did not support a defensible "
                    "cited answer, so I am abstaining.")
        status = "grounded" if grounded else "insufficient_evidence"
        citations = citations if grounded else ()
        audit_id = self._audit(persona, question, provider, status,
                               citations, len(warnings),
                               [t["id"] for t in top])
        chat_id = chat["id"] if chat else chats.create(persona.id, question)
        duration_ms = int((time.monotonic() - started) * 1000)
        chats.add(chat_id, "user", question)
        # v2: the top documents (cited one first) are kept with the answer
        # for "Download all sources"; only grounded answers have any.
        source_ids = [t["id"] for t in top] if citations else []
        message_id = chats.add(
            chat_id, "assistant", text, status=status, provider=provider,
            citation=citations[0].__dict__ if citations else None,
            duration_ms=duration_ms, source_ids=source_ids)
        self.conn.commit()
        trace.event("answer", status=status, provider=provider,
                    grounded=grounded, conversation_id=chat_id,
                    citations=[c.artifact_id for c in citations],
                    duration_ms=duration_ms)
        return AgentAnswer(answer=text, status=status, citations=citations,
                           conversation_id=chat_id, provider=provider,
                           audit_id=audit_id,
                           title=chats.get(persona.id, chat_id)["title"],
                           duration_ms=duration_ms, message_id=message_id,
                           source_count=len(source_ids))

    @staticmethod
    def _write(client, name, question, evidence, history, on_delta, state,
               instructions=""):
        """One LLM answer: streamed piece by piece when on_delta is given
        (state["streamed"] turns True once a piece was passed on). The
        user's custom instructions are passed only when they have some."""
        extra = {"instructions": instructions} if instructions else {}
        if not (on_delta and hasattr(client, "stream")):
            return client.synthesize(question, evidence, history, **extra)
        pieces = []
        for piece in client.stream(question, evidence, history, **extra):
            pieces.append(piece)
            state["streamed"] = True
            on_delta(piece)
        text = "".join(pieces).strip()
        if not text:
            raise RuntimeError(f"{name} returned empty content")
        return text

    def _standalone(self, question: str, history: list[dict],
                    trace) -> str:
        """The search question for this turn. The first question is used
        as asked; a follow-up ("and for Tier 2?") is rewritten by the LLM
        with the chat so far, or, without an LLM, joined to the previous
        question."""
        if not history:
            return question
        for name, client in (("vertex", self.vertex),
                             ("claude", self.claude)):
            if not client.configured:
                continue
            try:
                q = " ".join(client.condense(history, question).split())
                q = q.strip('"').strip()[:500]
                if q:
                    trace.event("standalone_question", provider=name,
                                question=q)
                    return q
            except Exception as exc:
                log.warning("%s condense failed: %s", name, exc)
                trace.event("standalone_question", provider=name,
                            status="failed", error=str(exc))
        prev = next((m["content"] for m in reversed(history)
                     if m["role"] == "user"), "")
        q = f"{prev} {question}".strip()
        trace.event("standalone_question", provider="local", question=q,
                    how="previous question + follow-up")
        return q

    # ---------------------------------------------------------- internals
    def _db_path(self) -> str:
        """File behind this connection, so the log shows which database
        answered."""
        try:
            return self.conn.execute(
                "PRAGMA database_list").fetchone()[2] or ":memory:"
        except Exception:
            return "unknown"

    def _local_synthesis(self, question: str,
                         evidence: list[dict]) -> str | None:
        top = evidence[0]
        paras = _paragraphs(top["content_text"])
        # Words in the title match every paragraph, so they don't help pick
        # one; score paragraphs on the rest of the question.
        q_stems = _stems(question) - _stems(top["title"]) - _LIFECYCLE
        scored = sorted(((_para_score(p, q_stems), i) for i, p in
                         enumerate(paras)), key=lambda x: (-x[0], x[1]))
        if scored and scored[0][0] > 0:
            best = scored[0][0]
            # One shared word ("policy") is not an answer: abstain.
            hits = _stems(paras[scored[0][1]]) & q_stems
            if len(hits) < min(2, len(q_stems)):
                return None
            # Rows that tie for best (a list question over a table) all
            # count; otherwise keep a close runner-up.
            idx = [i for s, i in scored if s == best][:4]
            if len(idx) == 1 and len(scored) > 1 \
                    and scored[1][0] >= 0.75 * best:
                idx.append(scored[1][1])
            idx.sort()
            picked = [paras[i] for i in idx]
        else:
            picked = paras[:1]
        body = " ".join(_clip(p) for p in picked)
        others = [f"{e['title']} v{e['version']}" for e in evidence[1:3]
                  if e.get("score", 0) >= 0.6 * top.get("score", 0)]
        related = (f" Related approved material: {'; '.join(others)}."
                   if others else "")
        return (f"Per the governing source {top['title']} v{top['version']}: "
                f"{body}{related}")

    def _audit(self, persona, question, provider, status, citations,
               warning_count, top_ids=()):
        aid = uuid.uuid4().hex
        details = {
            "question_hash":
                hashlib.sha256(question.encode()).hexdigest()[:16],
            "provider": provider, "status": status,
            "citation_ids": [c.artifact_id for c in citations],
            # v2: the top documents retrieved (best first); only the
            # first is used for the answer and cited.
            "top_ids": list(top_ids),
            "warnings": warning_count,
        }
        self.conn.execute(
            "INSERT INTO audit_events (id, persona, action, resource_id, "
            "details_json, at) VALUES (?,?,?,?,?,?)",
            (aid, persona.id, "agent_query", "",
             json.dumps(details),
             datetime.now(timezone.utc).isoformat(timespec="seconds")))
        self.conn.commit()
        return aid


def _stem(word: str) -> str:
    w = word.lower()
    for suf in ("ing", "ed", "es", "s"):
        if w.endswith(suf) and len(w) - len(suf) >= 3:
            w = w[:-len(suf)]
            break
    return w[:6].rstrip("e") if len(w) > 3 else w   # retire(d) -> retir


def _stems(text: str) -> set[str]:
    return {_stem(t) for t in re.findall(r"[A-Za-z]{3,}|\d+", text)
            if t.lower() not in _STOP}


def _paragraphs(text: str) -> list[str]:
    """Rejoin hard-wrapped lines (PDF), then drop headings: markdown '#'
    lines and short lines without sentence punctuation."""
    paras: list[str] = []
    for ln in (l.strip() for l in text.splitlines()):
        if not ln:
            continue
        if paras and paras[-1][-1] not in ".!?:" and ln[0].islower():
            paras[-1] += " " + ln
        else:
            paras.append(ln)
    out = []
    for p in paras:
        p = re.sub(r"^[-*•]\s+", "", p).replace("**", "")
        if p.startswith("#") or (p[-1] not in ".!?"
                                 and len(p.split()) < 6):
            continue
        out.append(p.strip())
    return out


def _para_score(para: str, q_stems: set[str]) -> float:
    hits = _stems(para) & q_stems
    if not hits:
        return 0.0
    score = float(len(hits))
    label, sep, _ = para.partition(":")   # "Claims records: 10 years…"
    if sep and len(label.split()) <= 5:
        score += len(_stems(label) & q_stems)
    return score + (0.5 if re.search(r"\d", para) else 0)


def _clip(para: str, limit: int = 420) -> str:
    """Whole sentences up to about `limit` characters."""
    out = ""
    for s in _SENTENCE_RE.split(para):
        if out and len(out) + len(s) > limit:
            break
        out += (" " if out else "") + s
    return out if out[-1] in ".!?" else out + "."


# keep injection detector importable for callers/tests
_ = detect_prompt_injection
