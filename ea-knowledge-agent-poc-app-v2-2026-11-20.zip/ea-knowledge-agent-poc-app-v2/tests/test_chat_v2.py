"""v2: chat history, follow-up questions in context, one citation."""

import json
import os
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from unittest import mock

from ea_knowledge_agent.agent import KnowledgeAgent
from ea_knowledge_agent.auth import get_persona
from ea_knowledge_agent.chats import ChatStore
from ea_knowledge_agent.config import Settings
from ea_knowledge_agent.database import connect, initialize
from ea_knowledge_agent.ingest import DocumentIngestor
from ea_knowledge_agent.retrieval import CONTEXT_BONUS, \
    PermissionAwareRetriever

VIEWER = get_persona("consumer")
OWNER = get_persona("owner")

RETENTION = ("Data Retention Guidelines.\n"
             "Claims records are kept for 10 years after the claim closes.\n"
             "Bodily injury claims are kept for 25 years.\n")
RECOVERY = ("Disaster Recovery Tiers.\n"
            "Tier 0 systems have an RTO of 1 hour.\n"
            "Tier 1 systems have an RTO of 4 hours.\n")
ARCHIVE = ("Archive Platform.\n"
           "Closed claims records move to the archive platform nightly.\n")


class Off:
    """An LLM client that isn't configured (local answers only)."""
    configured = False


class FakeLLM:
    """Records what the agent sends to the LLM."""
    configured = True
    model = "fake"

    def __init__(self, standalone=""):
        self.standalone = standalone
        self.condensed, self.calls = [], []

    def condense(self, history, question):
        self.condensed.append((list(history), question))
        return self.standalone or question

    def synthesize(self, question, evidence, history=None):
        self.calls.append((question, [e["title"] for e in evidence],
                           list(history or [])))
        return f"From the source: {evidence[0]['title']} [1]."


class StreamLLM(FakeLLM):
    """Streams the answer in pieces; fail_after stops half-way."""
    def __init__(self, pieces, fail_after=None):
        super().__init__()
        self.pieces, self.fail_after = pieces, fail_after

    def stream(self, question, evidence, history=None):
        for i, p in enumerate(self.pieces):
            if i == self.fail_after:
                raise RuntimeError("connection dropped")
            yield p


class ChatBase(unittest.TestCase):
    def setUp(self):
        fd, self.path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        self.conn = connect(self.path)
        initialize(self.conn)
        ing = DocumentIngestor(self.conn, Settings())
        for title, text in (("Data Retention Guidelines", RETENTION),
                            ("Disaster Recovery Tiers", RECOVERY),
                            ("Archive Platform", ARCHIVE)):
            ing.upsert(source_url=f"https://sp.example/{title}.txt",
                       title=title, data=text.encode(),
                       filename=f"{title}.txt")
        self.conn.commit()

    def tearDown(self):
        self.conn.close()
        os.unlink(self.path)

    def agent(self, llm=None):
        return KnowledgeAgent(self.conn, claude=Off(), vertex=llm or Off(),
                              embedder=Off())


class ChatFlowTests(ChatBase):
    def test_first_question_creates_a_chat_with_one_citation(self):
        a = self.agent().ask(VIEWER, "How long are claims records kept?")
        self.assertEqual(a.status, "grounded")
        # Archive Platform also matches; only the top one is cited.
        self.assertEqual([c.title for c in a.citations],
                         ["Data Retention Guidelines"])
        self.assertEqual(a.title, "How long are claims records kept?")
        store = ChatStore(self.conn)
        self.assertEqual([c["id"] for c in store.list_chats(VIEWER.id)],
                         [a.conversation_id])
        msgs = store.messages(a.conversation_id)
        self.assertEqual([m["role"] for m in msgs], ["user", "assistant"])
        self.assertEqual(msgs[1]["citation"]["title"],
                         "Data Retention Guidelines")
        self.assertTrue(msgs[1]["citation"]["family_id"])

    def test_follow_up_is_rewritten_and_answered_with_history(self):
        llm = FakeLLM(standalone="How long are bodily injury claims kept?")
        agent = self.agent(llm)
        first = agent.ask(VIEWER, "How long are claims records kept?")
        with mock.patch.object(agent.retriever, "search",
                               wraps=agent.retriever.search) as search:
            second = agent.ask(VIEWER, "And for bodily injury?",
                               first.conversation_id)
        self.assertEqual(second.conversation_id, first.conversation_id)
        # search used the standalone question, not "And for bodily injury?"
        self.assertEqual(search.call_args.args[1],
                         "How long are bodily injury claims kept?")
        history, q = llm.condensed[0]
        self.assertEqual(q, "And for bodily injury?")
        self.assertEqual([m["role"] for m in history],
                         ["user", "assistant"])
        # the answer call gets the original question plus the chat so far
        question, titles, hist = llm.calls[-1]
        self.assertEqual(question, "And for bodily injury?")
        self.assertEqual(titles, ["Data Retention Guidelines"])
        self.assertEqual(hist[0]["content"],
                         "How long are claims records kept?")
        self.assertEqual(len(ChatStore(self.conn).messages(
            first.conversation_id)), 4)

    def test_follow_up_without_an_llm_joins_the_previous_question(self):
        agent = self.agent()
        first = agent.ask(VIEWER, "What is the RTO for Tier 0 systems?")
        self.assertEqual(first.citations[0].title, "Disaster Recovery Tiers")
        # "What about Tier 1?" alone has no word that finds the document.
        second = agent.ask(VIEWER, "What about Tier 1?",
                           first.conversation_id)
        self.assertEqual(second.status, "grounded")
        self.assertEqual(second.citations[0].title,
                         "Disaster Recovery Tiers")
        self.assertIn("4 hours", second.answer)

    def test_new_chat_starts_without_history(self):
        llm = FakeLLM()
        agent = self.agent(llm)
        first = agent.ask(VIEWER, "How long are claims records kept?")
        other = agent.ask(VIEWER, "What is the RTO for Tier 0 systems?")
        self.assertNotEqual(first.conversation_id, other.conversation_id)
        self.assertEqual(llm.condensed, [])      # nothing to rewrite
        self.assertEqual(llm.calls[-1][2], [])   # no history sent
        self.assertEqual(len(ChatStore(self.conn).list_chats(VIEWER.id)), 2)

    def test_chats_are_private_to_their_persona(self):
        mine = self.agent().ask(VIEWER, "How long are claims records kept?")
        store = ChatStore(self.conn)
        self.assertIsNone(store.get(OWNER.id, mine.conversation_id))
        self.assertEqual(store.list_chats(OWNER.id), [])
        # Using someone else's chat id starts a fresh chat instead.
        theirs = self.agent().ask(OWNER, "What is the RTO for Tier 0?",
                                  mine.conversation_id)
        self.assertNotEqual(theirs.conversation_id, mine.conversation_id)
        self.assertEqual(len(store.messages(mine.conversation_id)), 2)

    def test_unanswerable_question_is_saved_without_a_citation(self):
        a = self.agent().ask(VIEWER, "Quantum hardware procurement?")
        self.assertEqual(a.status, "insufficient_evidence")
        self.assertEqual(a.citations, ())
        msgs = ChatStore(self.conn).messages(a.conversation_id)
        self.assertIsNone(msgs[1]["citation"])
        self.assertEqual(msgs[1]["status"], "insufficient_evidence")

    def test_context_bonus_goes_to_the_chats_document(self):
        r = PermissionAwareRetriever(self.conn)
        fam = self.conn.execute(
            "SELECT family_id FROM artifact_versions v JOIN "
            "artifact_families f ON f.id=v.family_id WHERE f.title="
            "'Archive Platform'").fetchone()[0]
        plain = {h["title"]: h["score"] for h in
                 r.search(VIEWER, "claims records")}
        boosted = {h["title"]: h["score"] for h in
                   r.search(VIEWER, "claims records", prefer_family=fam)}
        self.assertEqual(boosted["Archive Platform"],
                         plain["Archive Platform"] + CONTEXT_BONUS)
        self.assertEqual(boosted["Data Retention Guidelines"],
                         plain["Data Retention Guidelines"])


class TopDocumentsTests(ChatBase):
    def test_top_documents_are_logged_but_only_the_first_is_cited(self):
        events = []

        class Rec:
            def event(self, name, **kw):
                events.append((name, kw))
        with mock.patch("ea_knowledge_agent.agent.Trace.start",
                        return_value=Rec()):
            a = self.agent().ask(VIEWER, "How long are claims records kept?")
        # one citation for the UI, from the top document
        self.assertEqual([c.title for c in a.citations],
                         ["Data Retention Guidelines"])
        # the debug trace lists every top document, best first
        top = [kw for name, kw in events if name == "top_documents"][0]
        titles = [d["title"] for d in top["documents"]]
        self.assertEqual(titles[:2], ["Data Retention Guidelines",
                                      "Archive Platform"])
        self.assertEqual([d["answer_source"] for d in top["documents"]],
                         [True] + [False] * (len(titles) - 1))
        # so does the audit row
        row = self.conn.execute(
            "SELECT details_json FROM audit_events WHERE id=?",
            (a.audit_id,)).fetchone()
        details = json.loads(row[0])
        self.assertEqual(details["citation_ids"],
                         [a.citations[0].artifact_id])
        self.assertEqual(len(details["top_ids"]), len(titles))
        self.assertEqual(details["top_ids"][0], a.citations[0].artifact_id)


class HistoryTests(ChatBase):
    def _chat(self, pairs, answer="ok"):
        store = ChatStore(self.conn)
        cid = store.create(VIEWER.id, "q0")
        for i in range(pairs):
            store.add(cid, "user", f"q{i}")
            store.add(cid, "assistant", answer)
        return store, cid

    def test_the_last_six_pairs_are_used(self):
        store, cid = self._chat(8)
        h = store.history(cid)
        self.assertEqual(len(h), 12)
        self.assertEqual(h[0], {"role": "user", "content": "q2"})

    def test_oldest_messages_are_dropped_to_fit_the_budget(self):
        store, cid = self._chat(6, answer="x" * 1000)
        h = store.history(cid, max_messages=12, max_chars=2500)
        self.assertEqual([m["content"] for m in h if m["role"] == "user"],
                         ["q4", "q5"])
        self.assertEqual(h[0]["role"], "user")      # starts with a question
        # the latest pair is kept even if it alone is too big
        h = store.history(cid, max_messages=12, max_chars=10)
        self.assertEqual([m["content"] for m in h], ["q5", "x" * 1000])

    def test_context_limit_error_retries_with_the_last_pair(self):
        class TooLong(FakeLLM):
            def synthesize(self, question, evidence, history=None):
                if len(history or []) > 2:
                    raise RuntimeError("Vertex request failed: HTTP 400 "
                                       "INVALID_ARGUMENT: The input token "
                                       "count exceeds the maximum")
                return super().synthesize(question, evidence, history)
        llm = TooLong()
        a = self.agent(llm).ask(VIEWER, "How long are claims records kept?")
        for q in ("And bodily injury claims?", "And closed claims?"):
            a = self.agent(llm).ask(VIEWER, q, a.conversation_id)
        self.assertEqual((a.provider, a.status), ("vertex", "grounded"))
        self.assertEqual(len(llm.calls[-1][2]), 2)    # retried, last pair

    def test_other_errors_are_not_retried(self):
        class Down(FakeLLM):
            def synthesize(self, question, evidence, history=None):
                self.calls.append(len(history or []))
                raise RuntimeError("Vertex request failed: OSError: down")
        llm = Down()
        a = self.agent(llm).ask(VIEWER, "How long are claims records kept?")
        a = self.agent(llm).ask(VIEWER, "And bodily injury claims?",
                                a.conversation_id)
        self.assertEqual(llm.calls, [0, 2])
        self.assertEqual(a.provider, "local-fallback")


class RetentionTests(ChatBase):
    def test_chats_older_than_the_limit_are_deleted(self):
        old = self.agent().ask(VIEWER, "How long are claims records kept?")
        new = self.agent().ask(VIEWER, "What is the RTO for Tier 0?")
        self.conn.execute("UPDATE chats SET updated_at=? WHERE id=?",
                          ("2020-01-01T00:00:00+00:00", old.conversation_id))
        store = ChatStore(self.conn)
        self.assertEqual(store.purge(14), 1)
        self.assertEqual([c["id"] for c in store.list_chats(VIEWER.id)],
                         [new.conversation_id])
        self.assertEqual(store.messages(old.conversation_id), [])
        self.assertEqual(store.purge(0), 0)          # 0 = keep forever

    def test_asking_purges_expired_chats(self):
        old = self.agent().ask(VIEWER, "How long are claims records kept?")
        self.conn.execute("UPDATE chats SET updated_at=? WHERE id=?",
                          ("2020-01-01T00:00:00+00:00", old.conversation_id))
        a = self.agent().ask(VIEWER, "And bodily injury claims?",
                             old.conversation_id)
        self.assertNotEqual(a.conversation_id, old.conversation_id)
        self.assertIsNone(ChatStore(self.conn).get(VIEWER.id,
                                                   old.conversation_id))


class RenameDeleteTests(ChatBase):
    def test_rename_keeps_order_and_is_private(self):
        a = self.agent().ask(VIEWER, "How long are claims records kept?")
        b = self.agent().ask(VIEWER, "What is the RTO for Tier 0?")
        store = ChatStore(self.conn)
        self.assertTrue(store.rename(VIEWER.id, a.conversation_id,
                                     "  Claims   retention "))
        chats = store.list_chats(VIEWER.id)
        self.assertEqual([c["id"] for c in chats],
                         [b.conversation_id, a.conversation_id])
        self.assertEqual(chats[1]["title"], "Claims retention")
        self.assertFalse(store.rename(OWNER.id, a.conversation_id, "x"))
        self.assertFalse(store.rename(VIEWER.id, "nope", "x"))
        with self.assertRaises(ValueError):
            store.rename(VIEWER.id, a.conversation_id, "   ")

    def test_delete_removes_the_chat_and_its_messages(self):
        a = self.agent().ask(VIEWER, "How long are claims records kept?")
        store = ChatStore(self.conn)
        self.assertFalse(store.delete(OWNER.id, a.conversation_id))
        self.assertTrue(store.delete(VIEWER.id, a.conversation_id))
        self.assertEqual(store.list_chats(VIEWER.id), [])
        self.assertEqual(store.messages(a.conversation_id), [])
        self.assertFalse(store.delete(VIEWER.id, a.conversation_id))


class StreamingTests(ChatBase):
    def test_pieces_are_passed_on_and_joined_into_the_answer(self):
        llm, seen = StreamLLM(["Claims records are kept ",
                               "for 10 years [1]."]), []
        a = self.agent(llm).ask(VIEWER, "How long are claims records kept?",
                                on_delta=seen.append)
        self.assertEqual(seen, ["Claims records are kept ",
                                "for 10 years [1]."])
        self.assertEqual((a.provider, a.status), ("vertex", "grounded"))
        self.assertEqual(a.answer, "Claims records are kept for 10 years [1].")
        saved = ChatStore(self.conn).messages(a.conversation_id)[1]
        self.assertEqual(saved["content"], a.answer)

    def test_failure_half_way_resets_the_draft_and_falls_back(self):
        llm, seen = StreamLLM(["Claims records ", "are kept"],
                              fail_after=1), []
        a = self.agent(llm).ask(VIEWER, "How long are claims records kept?",
                                on_delta=seen.append)
        self.assertEqual(seen, ["Claims records ", None])
        self.assertEqual((a.provider, a.status),
                         ("local-fallback", "grounded"))
        self.assertIn("10 years", a.answer)

    def test_without_on_delta_synthesize_is_used(self):
        llm = StreamLLM(["never used"])
        a = self.agent(llm).ask(VIEWER, "How long are claims records kept?")
        self.assertEqual(a.answer,
                         "From the source: Data Retention Guidelines [1].")


class ChatApiTests(ChatBase):
    def setUp(self):
        super().setUp()
        from ea_knowledge_agent.api import create_server
        self.server = create_server("127.0.0.1", 0, self.path,
                                    os.path.join(os.path.dirname(__file__),
                                                 os.pardir, "web"))
        threading.Thread(target=self.server.serve_forever,
                         daemon=True).start()
        self.base = f"http://127.0.0.1:{self.server.server_address[1]}"
        self.env = mock.patch.dict(os.environ, {
            "VERTEX_PROJECT": "", "VERTEX_MODEL": "", "ANTHROPIC_API_KEY": "",
            "VERTEX_EMBED_MODEL": "", "POC_PHASE": "1",
            "DISCOVER_FOR_EVERYONE": "", "CHAT_RETENTION_DAYS": "14"})
        self.env.start()

    def tearDown(self):
        self.env.stop()
        self.server.shutdown()
        self.server.server_close()
        super().tearDown()

    def call(self, path, body=None, admin=False):
        headers = {"Content-Type": "application/json"}
        if admin:
            headers["X-POC-View"] = "admin"
        req = urllib.request.Request(
            self.base + path, method="POST" if body else "GET",
            data=json.dumps(body).encode() if body else None,
            headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=10) as r:
                return r.status, json.loads(r.read())
        except urllib.error.HTTPError as e:
            with e:
                return e.code, json.loads(e.read())

    def test_ask_then_list_and_reopen_a_chat(self):
        st, a = self.call("/api/agent/query", {
            "persona": "consumer",
            "question": "How long are claims records kept?"})
        self.assertEqual(st, 200)
        self.assertEqual(len(a["citations"]), 1)
        self.assertEqual(a["title"], "How long are claims records kept?")
        st, b = self.call("/api/agent/query", {
            "persona": "consumer", "question": "And bodily injury claims?",
            "conversation_id": a["conversation_id"]})
        self.assertEqual(b["conversation_id"], a["conversation_id"])
        st, lst = self.call("/api/chats?persona=consumer")
        self.assertEqual([c["id"] for c in lst["chats"]],
                         [a["conversation_id"]])
        st, chat = self.call(f"/api/chats/{a['conversation_id']}"
                             "?persona=consumer")
        self.assertEqual(st, 200)
        self.assertEqual([m["role"] for m in chat["messages"]],
                         ["user", "assistant", "user", "assistant"])
        self.assertEqual(chat["messages"][1]["citation"]["title"],
                         "Data Retention Guidelines")

    def test_rename_and_delete_endpoints(self):
        st, a = self.call("/api/agent/query", {
            "persona": "consumer",
            "question": "How long are claims records kept?"})
        cid = a["conversation_id"]
        st, r = self.call(f"/api/chats/{cid}/rename",
                          {"persona": "consumer", "title": "Retention"})
        self.assertEqual((st, r["chat"]["title"]), (200, "Retention"))
        st, r = self.call(f"/api/chats/{cid}/rename",
                          {"persona": "consumer", "title": " "})
        self.assertEqual(st, 400)
        st, r = self.call("/api/chats/nope/delete", {"persona": "consumer"})
        self.assertEqual(st, 404)
        st, r = self.call(f"/api/chats/{cid}/delete",
                          {"persona": "consumer"})
        self.assertEqual(st, 200)
        st, lst = self.call("/api/chats?persona=consumer")
        self.assertEqual(lst["chats"], [])
        st, r = self.call(f"/api/chats/{cid}?persona=consumer")
        self.assertEqual(st, 404)

    def test_stream_endpoint_ends_with_the_saved_answer(self):
        req = urllib.request.Request(
            self.base + "/api/agent/query/stream", method="POST",
            data=json.dumps({"persona": "consumer", "question":
                             "How long are claims records kept?"}).encode(),
            headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=10) as r:
            self.assertEqual(r.headers["Content-Type"],
                             "application/x-ndjson")
            events = [json.loads(line) for line in r.read().splitlines()]
        done = events[-1]
        self.assertEqual(done["type"], "done")
        self.assertEqual(done["status"], "grounded")
        self.assertEqual(done["citations"][0]["title"],
                         "Data Retention Guidelines")
        st, lst = self.call("/api/chats?persona=consumer")
        self.assertEqual([c["id"] for c in lst["chats"]],
                         [done["conversation_id"]])

    def test_stream_endpoint_rejects_an_empty_question(self):
        st, body = self.call("/api/agent/query/stream",
                             {"persona": "consumer", "question": " "})
        self.assertEqual(st, 400)

    def test_discover_is_admin_only_until_an_admin_opens_it(self):
        for path in ("/api/artifacts?persona=consumer",
                     "/api/tags?persona=consumer"):
            st, body = self.call(path)
            self.assertEqual((st, body["error"]["code"]), (403, "admin_only"))
            st, _ = self.call(path, admin=True)
            self.assertEqual(st, 200)
        st, s = self.call("/api/app-settings")
        self.assertEqual(s, {"admin_view": False,
                             "discover_for_everyone": False})
        # only an admin can change the setting
        st, _ = self.call("/api/app-settings",
                          {"discover_for_everyone": True})
        self.assertEqual(st, 403)
        st, s = self.call("/api/app-settings",
                          {"discover_for_everyone": True}, admin=True)
        self.assertEqual((st, s["discover_for_everyone"]), (200, True))
        st, _ = self.call("/api/artifacts?persona=consumer")
        self.assertEqual(st, 200)
        # chat source links still open for everyone
        st, a = self.call("/api/agent/query", {
            "persona": "consumer",
            "question": "How long are claims records kept?"})
        self.call("/api/app-settings", {"discover_for_everyone": False},
                  admin=True)
        st, _ = self.call("/api/artifacts/"
                          f"{a['citations'][0]['artifact_id']}"
                          "?persona=consumer")
        self.assertEqual(st, 200)

    def test_unknown_chat_is_404(self):
        st, body = self.call("/api/chats/nope?persona=consumer")
        self.assertEqual(st, 404)
        self.assertEqual(body["error"]["code"], "not_found")


if __name__ == "__main__":
    unittest.main()
